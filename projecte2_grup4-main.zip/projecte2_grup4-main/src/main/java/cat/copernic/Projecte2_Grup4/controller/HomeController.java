package cat.copernic.Projecte2_Grup4.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controlador web.
 */

@Controller
public class HomeController {

/**
 * Executa l'operació.
 * 
 * @return resultat
 */

    @GetMapping({"/", "/home"})
    public String home() {
        return "home/home";
    }
}
