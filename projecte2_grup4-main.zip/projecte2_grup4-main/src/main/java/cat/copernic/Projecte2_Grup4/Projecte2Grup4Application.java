package cat.copernic.Projecte2_Grup4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling; // Import necessari

/**
 * Classe principal de l'aplicació Spring Boot del projecte d'alquiler de
 * cotxes.
 *
 * <p>
 * Aquesta classe actua com a punt d'entrada del sistema i és la responsable de:
 * <ul>
 * <li>Arrencar el contenidor Spring (IoC) i inicialitzar l'aplicació.</li>
 * <li>Activar la planificació de tasques (scheduling) per a processos periòdics
 * (p. ex. comprovacions d'estat, expiracions de reserves, manteniment,
 * etc.).</li>
 * <li>Definir l'escaneig de components dins del paquet base del projecte.</li>
 * </ul>
 *
 * <p>
 * De cara a la defensa del projecte, aquesta classe justifica l'arquitectura
 * basada en Spring Boot i centralitza la configuració d'inicialització.</p>
 */
@SpringBootApplication
@EnableScheduling
@ComponentScan("cat.copernic.Projecte2_Grup4")
public class Projecte2Grup4Application {

    /**
     * Punt d'entrada (main) de l'aplicació.
     *
     * <p>
     * Inicialitza Spring Boot i posa en marxa tot el context de l'aplicació:
     * controladors, serveis, repositoris, configuracions de seguretat, etc.</p>
     *
     * @param args arguments de línia de comandes (habitualment buits en
     * execució normal)
     */
    public static void main(String[] args) {
        //ApplicationContext context = SpringApplication.run(Main.class, args);
        SpringApplication.run(Projecte2Grup4Application.class, args);
        //var passwordEncoder = context.getBean(PasswordEncoder.class);

        /* List<User> user = List.off(
                new user("83783383D", "joel", passwordEncoder.encode("1234"), ADMIN)
        );
        
        List<Agent> agent = List.off(
                new agent("83783383D", "joel", passwordEncoder.encode("1234"), ADMIN)
        ); 
         */
    }
}
