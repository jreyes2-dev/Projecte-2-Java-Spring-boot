package cat.copernic.Projecte2_Grup4.repository;

import cat.copernic.Projecte2_Grup4.model.Client;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ClientRepository extends JpaRepository<Client, String> {

    // Per login: buscar client pel nom d'usuari
    Optional<Client> findByNomUser(String nomUser);

    // RF25: buscar client per email (exacte)
    /**
     * Cerca un client pel seu correu electrònic, ignorant majúscules i
     * minúscules.
     *
     * @param email correu electrònic
     * @return {@link Optional} amb el client si existeix, o buit en cas
     * contrari
     */
    Optional<Client> findByEmailIgnoreCase(String email);

    // RF26: filtrar clients per nacionalitat, cognom i telèfon (combinables)
    /**
     * Filtra clients per nacionalitat, cognoms i/o telèfon de manera
     * combinable.
     *
     * <p>
     * Quan un paràmetre és {@code null} o buit, no s'aplica com a criteri de
     * filtratge. La cerca es fa amb coincidència parcial i sense distinció
     * entre majúscules i minúscules.</p>
     *
     * @param nacionalitat text de nacionalitat a cercar (opcional)
     * @param cognom text dels cognoms a cercar (opcional)
     * @param telefon text del telèfon a cercar (opcional)
     * @return llista de clients que compleixen els criteris
     */
    @Query("""
        SELECT c
        FROM Client c
        WHERE (:nacionalitat IS NULL OR :nacionalitat = '' 
               OR LOWER(c.nacionalitat) LIKE LOWER(CONCAT('%', :nacionalitat, '%')))
          AND (:telefon IS NULL OR :telefon = '' 
               OR LOWER(c.telefon) LIKE LOWER(CONCAT('%', :telefon, '%')))
          AND (:cognom IS NULL OR :cognom = '' OR
                LOWER(CONCAT(c.cognom1, ' ', c.cognom2)) LIKE LOWER(CONCAT('%', :cognom, '%'))
              )
        """)
    List<Client> filtrarClients(
            @Param("nacionalitat") String nacionalitat,
            @Param("cognom") String cognom,
            @Param("telefon") String telefon
    );
}
