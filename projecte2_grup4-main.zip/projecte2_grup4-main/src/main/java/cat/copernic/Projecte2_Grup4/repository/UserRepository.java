package cat.copernic.Projecte2_Grup4.repository;

import cat.copernic.Projecte2_Grup4.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Repositori JPA per gestionar la persistència d'entitats {@link User}.
 *
 * <p>
 * Inclou consultes derivades per recuperar usuaris per nom d'usuari o correu i
 * per validar la unicitat d'aquests camps.</p>
 */
public interface UserRepository extends JpaRepository<User, String> {

    /**
     * Cerca un usuari pel seu nom d'usuari.
     *
     * @param nomUser nom d'usuari
     * @return {@link Optional} amb l'usuari si existeix, o buit en cas contrari
     */
    Optional<User> findByNomUser(String nomUser);

    /**
     * Cerca un usuari pel seu correu electrònic.
     *
     * @param email correu electrònic
     * @return {@link Optional} amb l'usuari si existeix, o buit en cas contrari
     */
    Optional<User> findByEmail(String email);

    /**
     * Comprova si ja existeix un usuari amb el nom d'usuari indicat.
     *
     * @param nomUser nom d'usuari
     * @return {@code true} si existeix; {@code false} en cas contrari
     */
    boolean existsByNomUser(String nomUser);

    /**
     * Comprova si ja existeix un usuari amb el correu electrònic indicat.
     *
     * @param email correu electrònic
     * @return {@code true} si existeix; {@code false} en cas contrari
     */
    boolean existsByEmail(String email);
}
