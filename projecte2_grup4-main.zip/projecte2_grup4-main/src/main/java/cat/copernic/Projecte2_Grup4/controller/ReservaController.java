package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.model.Reserva;
import cat.copernic.Projecte2_Grup4.model.User;
import cat.copernic.Projecte2_Grup4.model.Vehicle;
import cat.copernic.Projecte2_Grup4.model.enums.Rol;
import cat.copernic.Projecte2_Grup4.repository.UserRepository;
import cat.copernic.Projecte2_Grup4.service.ReservaService;

import java.time.LocalDate;
import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/web/reserves")
/**
 * Controlador web per a la gestió de reserves de vehicles.
 *
 * <p>
 * Gestiona:</p>
 * <ul>
 * <li>Creació de reserves amb selecció de dates i consulta de disponibilitat de
 * vehicles.</li>
 * <li>Confirmació i guardat de la reserva.</li>
 * <li>Llistat de reserves amb control d'accés segons rol (client o
 * agent/admin).</li>
 * <li>Anul·lació de reserves amb validació d'usuari.</li>
 * </ul>
 *
 * <p>
 * Les operacions i validacions principals es deleguen al servei
 * {@link ReservaService}.</p>
 */
public class ReservaController {

    private final ReservaService reservaService;
    private final UserRepository userRepository;

    /**
     * Constructor amb injecció de dependències.
     *
     * @param reservaService servei de reserves
     * @param userRepository repositori d'usuaris per recuperar l'usuari
     * autenticat
     */
    public ReservaController(ReservaService reservaService, UserRepository userRepository) {
        this.reservaService = reservaService;
        this.userRepository = userRepository;
    }

    /**
     * Recupera l'usuari autenticat a partir del context de seguretat.
     *
     * @return l'usuari actual si existeix i està autenticat; en cas contrari
     * {@code null}
     */
    private User currentUserOrNull() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getName() == null) {
            return null;
        }
        return userRepository.findByNomUser(auth.getName()).orElse(null);
    }

    /**
     * Indica si l'usuari té rol de client.
     *
     * @param u usuari a validar
     * @return {@code true} si el rol és {@link Rol#CLIENT}; en cas contrari
     * {@code false}
     */
    private boolean isClient(User u) {
        return u != null && u.getRol() == Rol.CLIENT;
    }

    /**
     * Indica si l'usuari té rol d'agent o d'administrador.
     *
     * @param u usuari a validar
     * @return {@code true} si el rol és {@link Rol#AGENT} o {@link Rol#ADMIN};
     * en cas contrari {@code false}
     */
    private boolean isAgentOrAdmin(User u) {
        return u != null && (u.getRol() == Rol.AGENT || u.getRol() == Rol.ADMIN);
    }

    // RF50: formulari + cerca de vehicles disponibles
    /**
     * Mostra el formulari de creació de reserva i, opcionalment, consulta
     * vehicles disponibles.
     *
     * <p>
     * Si l'usuari és client, s'utilitza el seu DNI de manera efectiva
     * independentment del valor rebut per paràmetre. Si s'informen les dates,
     * es consulta la disponibilitat de vehicles per al rang indicat.</p>
     *
     * @param dniClient DNI del client (opcional; en rol client es força el
     * propi DNI)
     * @param dataIniciStr data d'inici en format ISO (opcional)
     * @param dataFiStr data de fi en format ISO (opcional)
     * @param model model de Spring per exposar dades a la vista
     * @return vista del formulari de creació de reserves o redirecció a login
     * si no hi ha sessió
     */
    @GetMapping("/crear")
    public String crearReserva(
            @RequestParam(value = "dniClient", required = false) String dniClient,
            @RequestParam(value = "dataInici", required = false) String dataIniciStr,
            @RequestParam(value = "dataFi", required = false) String dataFiStr,
            Model model
    ) {
        User u = currentUserOrNull();
        if (u == null) {
            return "redirect:/web/login";
        }

        // ✅ CLIENT: força el seu DNI
        String dniEfectiu = isClient(u) ? u.getDni() : dniClient;

        model.addAttribute("dniClient", dniEfectiu);
        model.addAttribute("dataInici", dataIniciStr);
        model.addAttribute("dataFi", dataFiStr);

        if (dataIniciStr != null && dataFiStr != null
                && !dataIniciStr.isBlank() && !dataFiStr.isBlank()) {

            LocalDate dataInici = LocalDate.parse(dataIniciStr);
            LocalDate dataFi = LocalDate.parse(dataFiStr);

            List<Vehicle> disponibles = reservaService.vehiclesDisponibles(dataInici, dataFi);
            model.addAttribute("vehiclesDisponibles", disponibles);
        }

        return "reserva/crear-reserves";
    }

    // RF50: confirmar i guardar reserva
    /**
     * Confirma i desa una reserva amb les dades del formulari.
     *
     * <p>
     * Aplica control d'accés per rol:</p>
     * <ul>
     * <li>Client: el DNI efectiu és sempre el del propi usuari.</li>
     * <li>Agent/Admin: el DNI del client és obligatori.</li>
     * </ul>
     *
     * <p>
     * També valida l'acceptació de la confirmació de documentació
     * ({@code confirmDoc}).</p>
     *
     * @param dniClient DNI del client (opcional segons rol)
     * @param matricula matrícula del vehicle
     * @param dataIniciStr data d'inici en format ISO
     * @param dataFiStr data de fi en format ISO
     * @param confirmDoc indicador de confirmació de documentació (obligatori
     * per continuar)
     * @param redirect atributs flash per informar del resultat
     * @return redirecció al llistat si es crea correctament; en cas d'error,
     * retorna al formulari amb paràmetres
     */
    @PostMapping("/guardar")
    public String guardarReserva(
            @RequestParam(value = "dniClient", required = false) String dniClient,
            @RequestParam("matricula") String matricula,
            @RequestParam("dataInici") String dataIniciStr,
            @RequestParam("dataFi") String dataFiStr,
            @RequestParam(value = "confirmDoc", required = false) String confirmDoc,
            RedirectAttributes redirect
    ) {
        User u = currentUserOrNull();
        if (u == null) {
            return "redirect:/web/login";
        }

        // ✅ Determinar DNI efectiu segons rol
        String dniEfectiu;
        if (isClient(u)) {
            dniEfectiu = u.getDni(); // ignora el que vingui del formulari
        } else if (isAgentOrAdmin(u)) {
            if (dniClient == null || dniClient.isBlank()) {
                redirect.addFlashAttribute("missatge", "DNI client obligatori.");
                redirect.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/reserves/crear";
            }
            dniEfectiu = dniClient;
        } else {
            return "redirect:/web/access-denied";
        }

        if (confirmDoc == null) {
            redirect.addFlashAttribute("missatge",
                    "Has de confirmar que has entès el tema de documentació.");
            redirect.addFlashAttribute("tipusMissatge", "danger");

            return "redirect:/web/reserves/crear"
                    + "?dniClient=" + dniEfectiu
                    + "&dataInici=" + dataIniciStr
                    + "&dataFi=" + dataFiStr;
        }

        try {
            LocalDate dataInici = LocalDate.parse(dataIniciStr);
            LocalDate dataFi = LocalDate.parse(dataFiStr);

            Reserva r = reservaService.crearReserva(dniEfectiu, matricula, dataInici, dataFi);

            redirect.addFlashAttribute("missatge",
                    "Reserva creada correctament. Codi: " + r.getCodiReserva());
            redirect.addFlashAttribute("tipusMissatge", "success");

            return "redirect:/web/reserves/llistar";

        } catch (Exception e) {
            redirect.addFlashAttribute("missatge", "Error creant reserva: " + e.getMessage());
            redirect.addFlashAttribute("tipusMissatge", "danger");

            return "redirect:/web/reserves/crear"
                    + "?dniClient=" + dniEfectiu
                    + "&dataInici=" + dataIniciStr
                    + "&dataFi=" + dataFiStr;
        }
    }

    // RF53: llistar reserves amb seguretat
    /**
     * Llista les reserves disponibles segons el rol de l'usuari autenticat.
     *
     * <ul>
     * <li>Client: només veu les seves reserves.</li>
     * <li>Agent/Admin: pot veure totes les reserves.</li>
     * </ul>
     *
     * @param model model de Spring per exposar la llista de reserves a la vista
     * @return vista de llistat de reserves o redirecció a login/accés denegat
     * segons correspongui
     */
    @GetMapping("/llistar")
    public String llistarReserves(Model model) {
        User u = currentUserOrNull();
        if (u == null) {
            return "redirect:/web/login";
        }

        List<Reserva> reserves;

        if (isClient(u)) {
            reserves = reservaService.reservesClient(u.getDni());
        } else if (isAgentOrAdmin(u)) {
            reserves = reservaService.totesLesReserves();
        } else {
            return "redirect:/web/access-denied";
        }

        model.addAttribute("reserves", reserves);
        return "reserva/llistar-reserves";
    }

    /**
     * Anul·la una reserva identificada pel seu id.
     *
     * <p>
     * La validació de permisos i condicions d'anul·lació es delega al
     * servei.</p>
     *
     * @param id identificador intern de la reserva
     * @param redirect atributs flash per informar del resultat
     * @return redirecció al llistat de reserves
     */
    @PostMapping("/anullar/{id}")
    public String anularReserva(@PathVariable("id") Long id,
            RedirectAttributes redirect) {

        User u = currentUserOrNull();
        if (u == null) {
            return "redirect:/web/login";
        }

        try {
            reservaService.anularReserva(id, u);
            redirect.addFlashAttribute("missatge", "Reserva anul·lada correctament");
            redirect.addFlashAttribute("tipusMissatge", "success");
        } catch (Exception e) {
            redirect.addFlashAttribute("missatge", "Error anul·lant reserva: " + e.getMessage());
            redirect.addFlashAttribute("tipusMissatge", "danger");
        }

        return "redirect:/web/reserves/llistar";
    }
}
