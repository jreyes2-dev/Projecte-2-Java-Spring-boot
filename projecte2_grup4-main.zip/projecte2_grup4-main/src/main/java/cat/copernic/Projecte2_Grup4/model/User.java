package cat.copernic.Projecte2_Grup4.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.*;
import java.time.LocalDate;
import cat.copernic.Projecte2_Grup4.model.enums.Rol;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tipus_usuari")
/**
 * Classe base abstracta que representa un usuari del sistema.
 *
 * <p>
 * Implementa una jerarquia d'herència JPA amb estratègia {@code SINGLE_TABLE},
 * on tots els tipus d'usuari es persisteixen en una única taula i es
 * diferencien mitjançant el discriminador {@code tipus_usuari}.</p>
 *
 * <p>
 * Conté les dades comunes d'identificació i autenticació, així com informació
 * relacionada amb la documentació i el pagament.</p>
 */
public abstract class User {

    @Id
    @Column(length = 20)
    public String dni;

    @Column(length = 100)
    public String nom;

    @Column(length = 100)
    public String cognom1;

    @Column(length = 100)
    public String cognom2;

    @Column(columnDefinition = "TEXT")
    public String adreca;

    @Column(length = 100)
    public String nomUser;

    @Column(length = 100)
    public String email;

    @Column(length = 255)
    public String contrasenya;

    @Column(length = 50)
    public String tipusLlicenciaConduir;

    @Column(length = 30)
    public String numeroTargetaCredit;

    @Column
    public LocalDate dataCaducitatIdentificacio;

    @Column
    public LocalDate dataCaducitatLlicencia;

    @Enumerated(EnumType.STRING)
    public Rol rol;

    public User() {
    }

    /**
     * Constructor complet amb totes les dades d'usuari i rol.
     *
     * @param dni DNI de l'usuari
     * @param nom nom
     * @param cognom1 primer cognom
     * @param cognom2 segon cognom
     * @param adreca adreça
     * @param nomUser nom d'usuari
     * @param email correu electrònic
     * @param contrasenya contrasenya
     * @param tipusLlicenciaConduir tipus de llicència de conduir
     * @param numeroTargetaCredit número de targeta de crèdit
     * @param dataCaducitatIdentificacio data de caducitat del document
     * d'identificació
     * @param dataCaducitatLlicencia data de caducitat de la llicència de
     * conduir
     * @param rol rol de l'usuari
     */
    public User(String dni, String nom, String cognom1, String cognom2, String adreca, String nomUser, String email, String contrasenya, String tipusLlicenciaConduir, String numeroTargetaCredit, LocalDate dataCaducitatIdentificacio, LocalDate dataCaducitatLlicencia, Rol rol) {
        this.dni = dni;
        this.nom = nom;
        this.cognom1 = cognom1;
        this.cognom2 = cognom2;
        this.adreca = adreca;
        this.nomUser = nomUser;
        this.email = email;
        this.contrasenya = contrasenya;
        this.tipusLlicenciaConduir = tipusLlicenciaConduir;
        this.numeroTargetaCredit = numeroTargetaCredit;
        this.dataCaducitatIdentificacio = dataCaducitatIdentificacio;
        this.dataCaducitatLlicencia = dataCaducitatLlicencia;
        this.rol = rol;
    }

    /**
     * Constructor amb dades d'usuari (sense rol explícit).
     *
     * @param dni DNI de l'usuari
     * @param nom nom
     * @param cognom1 primer cognom
     * @param cognom2 segon cognom
     * @param adreca adreça
     * @param nomUser nom d'usuari
     * @param email correu electrònic
     * @param contrasenya contrasenya
     * @param tipusLlicenciaConduir tipus de llicència de conduir
     * @param numeroTargetaCredit número de targeta de crèdit
     * @param dataCaducitatIdentificacio data de caducitat del document
     * d'identificació
     * @param dataCaducitatLlicencia data de caducitat de la llicència de
     * conduir
     */
    public User(String dni, String nom, String cognom1, String cognom2, String adreca, String nomUser, String email, String contrasenya, String tipusLlicenciaConduir, String numeroTargetaCredit, LocalDate dataCaducitatIdentificacio, LocalDate dataCaducitatLlicencia) {
        this.dni = dni;
        this.nom = nom;
        this.cognom1 = cognom1;
        this.cognom2 = cognom2;
        this.adreca = adreca;
        this.nomUser = nomUser;
        this.email = email;
        this.contrasenya = contrasenya;
        this.tipusLlicenciaConduir = tipusLlicenciaConduir;
        this.numeroTargetaCredit = numeroTargetaCredit;
        this.dataCaducitatIdentificacio = dataCaducitatIdentificacio;
        this.dataCaducitatLlicencia = dataCaducitatLlicencia;
    }

    /**
     * Constructor mínim per a credencials i rol.
     *
     * @param dni DNI de l'usuari
     * @param nomUser nom d'usuari
     * @param contrasenya contrasenya
     * @param rol rol de l'usuari
     */
    public User(String dni, String nomUser, String contrasenya, Rol rol) {
        this.dni = dni;
        this.nomUser = nomUser;
        this.contrasenya = contrasenya;
        this.rol = rol;
    }

    /**
     * Retorna el DNI de l'usuari.
     *
     * @return DNI
     */
    public String getDni() {
        return dni;
    }

    /**
     * Assigna el DNI de l'usuari.
     *
     * @param dni DNI
     */
    public void setDni(String dni) {
        this.dni = dni;
    }

    /**
     * Retorna el nom de l'usuari.
     *
     * @return nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * Assigna el nom de l'usuari.
     *
     * @param nom nom
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Retorna el primer cognom de l'usuari.
     *
     * @return primer cognom
     */
    public String getCognom1() {
        return cognom1;
    }

    /**
     * Assigna el primer cognom de l'usuari.
     *
     * @param cognom1 primer cognom
     */
    public void setCognom1(String cognom1) {
        this.cognom1 = cognom1;
    }

    /**
     * Retorna el segon cognom de l'usuari.
     *
     * @return segon cognom
     */
    public String getCognom2() {
        return cognom2;
    }

    /**
     * Assigna el segon cognom de l'usuari.
     *
     * @param cognom2 segon cognom
     */
    public void setCognom2(String cognom2) {
        this.cognom2 = cognom2;
    }

    /**
     * Retorna l'adreça de l'usuari.
     *
     * @return adreça
     */
    public String getAdreca() {
        return adreca;
    }

    /**
     * Assigna l'adreça de l'usuari.
     *
     * @param adreca adreça
     */
    public void setAdreca(String adreca) {
        this.adreca = adreca;
    }

    /**
     * Retorna el nom d'usuari.
     *
     * @return nom d'usuari
     */
    public String getNomUser() {
        return nomUser;
    }

    /**
     * Assigna el nom d'usuari.
     *
     * @param nomUser nom d'usuari
     */
    public void setNomUser(String nomUser) {
        this.nomUser = nomUser;
    }

    /**
     * Retorna el correu electrònic de l'usuari.
     *
     * @return correu electrònic
     */
    public String getEmail() {
        return email;
    }

    /**
     * Assigna el correu electrònic de l'usuari.
     *
     * @param email correu electrònic
     */
    public void setEmail(String email) {
        this.email = email;
    }

    // camp nou per poder filtrar per nacionalitat
    @Column(length = 80)
    public String nacionalitat;

    // >>> RF26: getter/setter
    /**
     * Retorna la nacionalitat de l'usuari.
     *
     * @return nacionalitat
     */
    public String getNacionalitat() {
        return nacionalitat;
    }

    /**
     * Assigna la nacionalitat de l'usuari.
     *
     * @param nacionalitat nacionalitat
     */
    public void setNacionalitat(String nacionalitat) {
        this.nacionalitat = nacionalitat;
    }

    /**
     * Retorna la contrasenya de l'usuari.
     *
     * @return contrasenya
     */
    public String getContrasenya() {
        return contrasenya;
    }

    /**
     * Assigna la contrasenya de l'usuari.
     *
     * @param contrasenya contrasenya
     */
    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }

    /**
     * Retorna el tipus de llicència de conduir.
     *
     * @return tipus de llicència
     */
    public String getTipusLlicenciaConduir() {
        return tipusLlicenciaConduir;
    }

    /**
     * Assigna el tipus de llicència de conduir.
     *
     * @param tipusLlicenciaConduir tipus de llicència
     */
    public void setTipusLlicenciaConduir(String tipusLlicenciaConduir) {
        this.tipusLlicenciaConduir = tipusLlicenciaConduir;
    }

    /**
     * Retorna el número de targeta de crèdit.
     *
     * @return número de targeta
     */
    public String getNumeroTargetaCredit() {
        return numeroTargetaCredit;
    }

    /**
     * Assigna el número de targeta de crèdit.
     *
     * @param numeroTargetaCredit número de targeta
     */
    public void setNumeroTargetaCredit(String numeroTargetaCredit) {
        this.numeroTargetaCredit = numeroTargetaCredit;
    }

    /**
     * Retorna la data de caducitat del document d'identificació.
     *
     * @return data de caducitat del document d'identificació
     */
    public LocalDate getDataCaducitatIdentificacio() {
        return dataCaducitatIdentificacio;
    }

    /**
     * Assigna la data de caducitat del document d'identificació.
     *
     * @param dataCaducitatIdentificacio data de caducitat del document
     * d'identificació
     */
    public void setDataCaducitatIdentificacio(LocalDate dataCaducitatIdentificacio) {
        this.dataCaducitatIdentificacio = dataCaducitatIdentificacio;
    }

    /**
     * Retorna la data de caducitat de la llicència de conduir.
     *
     * @return data de caducitat de la llicència
     */
    public LocalDate getDataCaducitatLlicencia() {
        return dataCaducitatLlicencia;
    }

    /**
     * Assigna la data de caducitat de la llicència de conduir.
     *
     * @param dataCaducitatLlicencia data de caducitat de la llicència
     */
    public void setDataCaducitatLlicencia(LocalDate dataCaducitatLlicencia) {
        this.dataCaducitatLlicencia = dataCaducitatLlicencia;
    }

    /**
     * Retorna el rol de l'usuari.
     *
     * @return rol
     */
    public Rol getRol() {
        return rol;
    }

    /**
     * Assigna el rol de l'usuari.
     *
     * @param rol rol
     */
    public void setRol(Rol rol) {
        this.rol = rol;
    }
}
