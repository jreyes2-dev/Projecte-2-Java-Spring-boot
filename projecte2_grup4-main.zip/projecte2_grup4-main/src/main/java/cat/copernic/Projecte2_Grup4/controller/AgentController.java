package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.model.Agent;
import cat.copernic.Projecte2_Grup4.model.Localitzacio;
import cat.copernic.Projecte2_Grup4.model.enums.Rol;
import cat.copernic.Projecte2_Grup4.model.enums.Estat;
import cat.copernic.Projecte2_Grup4.model.enums.EstatAgent;
import cat.copernic.Projecte2_Grup4.service.AgentService;
import cat.copernic.Projecte2_Grup4.service.IncidenciaService;
import cat.copernic.Projecte2_Grup4.service.LocalitzacioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;

/**
 * Controlador MVC per a la gestió d'agents dins la part web del sistema.
 *
 * <p>
 * <b>Responsabilitats principals:</b>
 * <ul>
 * <li>Llistar i cercar agents (principalment per DNI).</li>
 * <li>Crear agents amb validació de camps i assignació de rol/estat.</li>
 * <li>Editar i actualitzar agents existents.</li>
 * <li>Consultar el detall d'un agent.</li>
 * <li>Activar/desactivar agents, aplicant regles de negoci associades a
 * incidències.</li>
 * <li>Endpoints AJAX de verificació (email, username, DNI) per evitar
 * duplicats.</li>
 * </ul>
 *
 * <p>
 * Aquest controlador demostra separació de capes (MVC -> Service ->
 * Repository), validació en servidor i control d'estats (ACTIU/INACTIU) amb
 * impacte directe en la gestió d'incidències.</p>
 */
/**
 * Controlador web.
 */
@Controller
@RequestMapping("/web/agents")
public class AgentController {

    /**
     * Servei d'agents: encapsula la lògica de negoci i les validacions.
     */
    private final AgentService agentService;

    /**
     * Servei de localitzacions: permet obtenir i assignar localitzacions a
     * agents.
     */
    private final LocalitzacioService localitzacioService;

    /**
     * Servei d'incidències: utilitzat per reassignar/restaurar incidències quan
     * es canvia l'estat d'un agent.
     */
    private final IncidenciaService incidenciaService;

    /**
     * Constructor amb injecció de dependències.
     *
     * @param agentService servei d'agents
     * @param localitzacioService servei de localitzacions
     * @param incidenciaService servei d'incidències
     */
    public AgentController(AgentService agentService, LocalitzacioService localitzacioService, IncidenciaService incidenciaService) {
        this.agentService = agentService;
        this.localitzacioService = localitzacioService;
        this.incidenciaService = incidenciaService;
    }

    /**
     * Llista tots els agents o bé filtra per DNI (si es proporciona el
     * paràmetre).
     *
     * <p>
     * També calcula mètriques útils per a la vista (agents
     * actius/inactius).</p>
     *
     * @param cercarDni DNI a cercar (opcional)
     * @param model model MVC per passar dades a la vista
     * @return nom de la vista de llistat d'agents
     */
    @GetMapping("/llistar")
    public String llistarAgents(@RequestParam(name = "cercarDni", required = false) String cercarDni,
            Model model) {
        List<Agent> agents = cercarDni != null && !cercarDni.trim().isEmpty()
                ? cercarPerDni(cercarDni)
                : agentService.llistarTotsAgents();

        long agentsActius = agents.stream()
                .filter(a -> a.getEstatAgent() == EstatAgent.ACTIU)
                .count();

        afegirAtributsModel(model, "ADMIN", agents, agentsActius, cercarDni);
        return "agent/llistar-agents";
    }

    /**
     * Mostra el formulari de creació d'un agent.
     *
     * @param model model MVC
     * @return vista amb el formulari de creació
     */
    /**
     * Executa l'operació.
     *
     * @param model paràmetre
     * @return resultat
     */
    @GetMapping("/crear")
    public String mostrarFormulariCreacio(Model model) {
        model.addAllAttributes(prepararModelCreacio("ADMIN"));
        return "agent/crear-agents";
    }

    /**
     * Processa la creació d'un agent a partir dels paràmetres del formulari.
     *
     * <p>
     * Flux:</p>
     * <ol>
     * <li>Construeix l'agent a partir de {@code params}.</li>
     * <li>Processa dates (caducitat identificació i llicència).</li>
     * <li>Assigna localització si hi ha codi postal.</li>
     * <li>Valida la creació via
     * {@link AgentService#validarAgentCreacio(Agent)}.</li>
     * <li>Si hi ha errors: retorna al formulari amb missatges.</li>
     * <li>Si no: desa l'agent i mostra missatge d'èxit.</li>
     * </ol>
     *
     * @param params paràmetres rebuts del formulari
     * @param redirectAttributes atributs flash per informar a la vista després
     * del redirect
     * @return redirecció a llistat o a formulari de creació en cas d'error
     */
    @PostMapping("/guardar")
    public String guardarAgent(@RequestParam Map<String, String> params,
            RedirectAttributes redirectAttributes) {

        try {
            Agent agent = crearAgentDesdeParams(params);
            procesarFechas(params, agent, redirectAttributes);
            assignarLocalitzacio(params, agent);

            Map<String, String> errors = agentService.validarAgentCreacio(agent);
            if (!errors.isEmpty()) {
                afegirErrorsRedireccio(errors, params, redirectAttributes);
                return "redirect:/web/agents/crear";
            }

            agentService.guardarAgent(agent);
            afegirMissatgeExit(redirectAttributes, "✅ Agent creat correctament!");

        } catch (DateTimeParseException e) {
            afegirMissatgeError(redirectAttributes, "❌ Error en les dates: format incorrecte. Use yyyy-MM-dd");
        } catch (Exception e) {
            afegirMissatgeError(redirectAttributes, "❌ Error: " + e.getMessage());
        }

        return "redirect:/web/agents/llistar";
    }

    /**
     * Mostra el formulari d'edició d'un agent identificat pel seu DNI.
     *
     * @param dni DNI de l'agent a editar
     * @param model model MVC
     * @return vista d'edició o redirecció al llistat si no existeix
     */
    @GetMapping("/editar/{dni}")
    public String mostrarFormulariEdicio(
            @PathVariable("dni") String dni, Model model) {
        Agent agent = agentService.obtenirAgentPerDni(dni);
        if (agent == null) {
            return "redirect:/web/agents/llistar";
        }

        model.addAllAttributes(prepararModelEdicio(agent, "ADMIN"));
        return "agent/modificar-agents";
    }

    /**
     * Processa l'actualització d'un agent existent.
     *
     * <p>
     * Recupera l'agent per DNI, aplica canvis, valida i desa.</p>
     *
     * @param params paràmetres rebuts del formulari d'edició
     * @param redirectAttributes atributs flash per missatges d'error/èxit
     * @return redirecció al llistat o al formulari d'edició en cas d'errors
     */
    @PostMapping("/actualitzar")
    public String actualitzarAgent(@RequestParam Map<String, String> params,
            RedirectAttributes redirectAttributes) {

        try {
            String dni = params.get("dni");
            Agent agent = agentService.obtenirAgentPerDni(dni);

            if (agent == null) {
                afegirMissatgeError(redirectAttributes, "❌ L'agent no existeix");
                return "redirect:/web/agents/llistar";
            }

            actualitzarAgentDesdeParams(agent, params);
            procesarFechas(params, agent, redirectAttributes);
            assignarLocalitzacio(params, agent);

            Map<String, String> errors = agentService.validarAgentEdicio(agent, dni);
            if (!errors.isEmpty()) {
                afegirErrorsRedireccio(errors, params, redirectAttributes);
                return "redirect:/web/agents/editar/" + dni;
            }

            agentService.guardarAgent(agent);
            afegirMissatgeExit(redirectAttributes, "✅ Agent actualitzat correctament!");

        } catch (DateTimeParseException e) {
            afegirMissatgeError(redirectAttributes, "❌ Error en les dates: format incorrecte. Use yyyy-MM-dd");
        } catch (Exception e) {
            afegirMissatgeError(redirectAttributes, "❌ Error: " + e.getMessage());
        }

        return "redirect:/web/agents/llistar";
    }

    /**
     * Mostra la vista de consulta (només lectura) d'un agent.
     *
     * @param dni DNI de l'agent
     * @param model model MVC
     * @return vista de consulta o redirecció al llistat si no existeix
     */
    @GetMapping("/consultar/{dni}")
    public String consultarAgent(
            @PathVariable("dni") String dni, Model model) {
        Agent agent = agentService.obtenirAgentPerDni(dni);
        if (agent == null) {
            return "redirect:/web/agents/llistar";
        }

        model.addAttribute("agent", agent);
        model.addAttribute("esAdmin", true);
        model.addAttribute("rolActual", "ADMIN");

        return "agent/consultar-agents";
    }

    /**
     * Activa o desactiva un agent (segons paràmetre rebut o bé fent toggle).
     *
     * <p>
     * <b>Regla de negoci destacada:</b> quan un agent passa a INACTIU, les
     * incidències que tenia assignades es reassignen a ADMIN. Quan es
     * re-activa, es poden restaurar les incidències segons la política definida
     * al servei.</p>
     *
     * @param dni DNI de l'agent
     * @param estatAgent estat indicat (opcional). Si no ve informat, es fa
     * toggle.
     * @param redirectAttributes missatges flash
     * @return redirecció al llistat d'agents
     */
    @PostMapping("/desactivar/{dni}")
    public String desactivarAgent(
            @PathVariable("dni") String dni,
            @RequestParam(name = "estatAgent", required = false) String estatAgent, RedirectAttributes redirectAttributes) {

        try {
            Agent agent = agentService.obtenirAgentPerDni(dni);
            if (agent == null) {
                afegirMissatgeError(redirectAttributes, "❌ L'agent no existeix");
            } else {
                EstatAgent nouEstat = determinarNouEstat(estatAgent, agent.getEstatAgent());
                agent.setEstatAgent(nouEstat);
                agentService.guardarAgent(agent);

                if (nouEstat == EstatAgent.INACTIU) {
                    // Coherència operativa: si l'agent queda inactiu, ADMIN assumeix les incidències pendents.
                    incidenciaService.reassignarIncidenciesAssignadesDeAgentAAdmin(agent.getNomUser());
                }

                if (nouEstat == EstatAgent.ACTIU) {
                    // Restauració de càrrega de treball quan l'agent torna a estar actiu.
                    incidenciaService.restaurarIncidenciesDeAgentQuanReactivat(agent.getNomUser());
                }

                String missatge = nouEstat == EstatAgent.ACTIU
                        ? "✅ Agent activat correctament"
                        : "✅ Agent desactivat correctament";
                afegirMissatgeExit(redirectAttributes, missatge);
            }
        } catch (Exception e) {
            afegirMissatgeError(redirectAttributes, "❌ Error: " + e.getMessage());
        }

        return "redirect:/web/agents/llistar";
    }

    /**
     * Endpoint AJAX per verificar si un email ja existeix, tenint en compte una
     * edició (dniActual).
     *
     * @param email email a verificar
     * @param dniActual DNI actual (opcional) per permetre mantenir el mateix
     * email en edició
     * @return mapa amb clau "existe" indicant si l'email està en ús
     */
    @GetMapping("/verificar-email")
    @ResponseBody
    public Map<String, Boolean> verificarEmail(
            @RequestParam String email,
            @RequestParam(required = false) String dniActual) {
        return Collections.singletonMap("existe", agentService.existeixEmail(email, dniActual));
    }

    /**
     * Endpoint AJAX per verificar si el nom d'usuari ja existeix, amb suport
     * d'edició.
     *
     * @param username nom d'usuari a verificar
     * @param dniActual DNI actual (opcional) per permetre mantenir el mateix
     * username en edició
     * @return mapa amb clau "existe" indicant si el username està en ús
     */
    @GetMapping("/verificar-username")
    @ResponseBody
    public Map<String, Boolean> verificarUsername(
            @RequestParam String username,
            @RequestParam(required = false) String dniActual) {
        return Collections.singletonMap("existe", agentService.existeixNomUser(username, dniActual));
    }

    /**
     * Endpoint AJAX per verificar si un DNI ja existeix al sistema.
     *
     * @param dni DNI a verificar
     * @return mapa amb clau "existe" indicant si el DNI està en ús
     */
    /**
     * Executa l'operació.
     *
     * @param dni paràmetre
     * @return resultat
     */
    @GetMapping("/verificar-dni")
    @ResponseBody
    public Map<String, Boolean> verificarDni(@RequestParam String dni) {
        return Collections.singletonMap("existe", agentService.existeixDni(dni));
    }

    /**
     * Cerca un agent concret pel DNI i el retorna en forma de llista (0 o 1
     * elements), per reutilitzar el mateix component de llistat.
     *
     * @param cercarDni DNI introduït al filtre
     * @return llista amb l'agent trobat o buida si no existeix
     */
    private List<Agent> cercarPerDni(String cercarDni) {
        Agent agent = agentService.obtenirAgentPerDni(cercarDni.trim());
        return agent != null ? Arrays.asList(agent) : new ArrayList<>();
    }

    /**
     * Afegeix al model els atributs comuns per a la pantalla de llistat: llista
     * d'agents, totals, actius/inactius i mapa de localitzacions per agent.
     *
     * @param model model MVC
     * @param rol rol actual (informatiu per a la vista)
     * @param agents llista d'agents a mostrar
     * @param agentsActius nombre d'agents en estat ACTIU
     * @param cercarDni valor del filtre de DNI (si existeix)
     */
    private void afegirAtributsModel(Model model, String rol, List<Agent> agents, long agentsActius, String cercarDni) {
        model.addAttribute("esAdmin", true);
        model.addAttribute("rolActual", "ADMIN");
        model.addAttribute("agents", agents);
        model.addAttribute("totalAgents", agents.size());
        model.addAttribute("agentsActius", agentsActius);
        model.addAttribute("agentsInactius", agents.size() - agentsActius);

        if (cercarDni != null) {
            model.addAttribute("cercarDni", cercarDni);
        }

        Map<String, Localitzacio> localitzacioPerDniAgent = new HashMap<>();
        for (Localitzacio l : localitzacioService.llistarTotesLocalitzacions()) {
            if (l != null && l.getAgent() != null && l.getAgent().getDni() != null) {
                localitzacioPerDniAgent.put(l.getAgent().getDni(), l);
            }
        }
        model.addAttribute("localitzacioPerDniAgent", localitzacioPerDniAgent);
    }

    /**
     * Prepara els atributs necessaris pel formulari de creació.
     *
     * @param rol rol actual (informatiu)
     * @return mapa amb els valors a injectar al model
     */
    private Map<String, Object> prepararModelCreacio(String rol) {
        Map<String, Object> model = new HashMap<>();
        model.put("agent", new Agent());
        model.put("esAdmin", true);
        model.put("rolActual", rol);
        model.put("localitzacions", localitzacioService.llistarTotesLocalitzacions());
        model.put("estatsAgent", EstatAgent.values());
        return model;
    }

    /**
     * Prepara els atributs necessaris pel formulari d'edició.
     *
     * @param agent agent a editar
     * @param rol rol actual (informatiu)
     * @return mapa amb els valors a injectar al model
     */
    private Map<String, Object> prepararModelEdicio(Agent agent, String rol) {
        Map<String, Object> model = new HashMap<>();
        model.put("agent", agent);
        model.put("esAdmin", true);
        model.put("rolActual", rol);
        model.put("localitzacions", localitzacioService.llistarTotesLocalitzacions());
        model.put("estatsAgent", EstatAgent.values());
        return model;
    }

    /**
     * Construeix un {@link Agent} nou a partir dels paràmetres del formulari.
     *
     * <p>
     * Assigna valors per defecte coherents amb l'alta: estat ACCEPTAT i
     * estatAgent ACTIU.</p>
     *
     * @param params mapa de paràmetres del formulari
     * @return agent nou amb camps bàsics assignats
     */
    private Agent crearAgentDesdeParams(Map<String, String> params) {
        Agent agent = new Agent();
        agent.setDni(params.get("dni"));
        agent.setNomUser(params.get("nomUser"));
        agent.setNom(params.get("nom"));
        agent.setCognom1(params.get("cognom1"));
        agent.setCognom2(params.get("cognom2"));
        agent.setEmail(params.get("email"));
        agent.setContrasenya(params.get("contrasenya"));
        agent.setAdreca(params.get("adreca"));
        agent.setTipusLlicenciaConduir(params.getOrDefault("tipusLlicenciaConduir", "B"));
        agent.setEstat(Estat.ACEPTAT);
        agent.setEstatAgent(EstatAgent.ACTIU);

        assignarRol(agent, params.get("rol"));
        return agent;
    }

    /**
     * Actualitza un agent existent amb els nous valors rebuts del formulari.
     *
     * <p>
     * Nota: la contrasenya només s'actualitza si ve informada (no buida).</p>
     *
     * @param agent agent existent a modificar
     * @param params paràmetres del formulari
     */
    private void actualitzarAgentDesdeParams(Agent agent, Map<String, String> params) {
        agent.setNomUser(params.get("nomUser"));
        agent.setNom(params.get("nom"));
        agent.setCognom1(params.get("cognom1"));
        agent.setCognom2(params.get("cognom2"));
        agent.setEmail(params.get("email"));
        agent.setAdreca(params.get("adreca"));

        if (params.get("contrasenya") != null && !params.get("contrasenya").trim().isEmpty()) {
            agent.setContrasenya(params.get("contrasenya"));
        }

        assignarRol(agent, params.get("rol"));
        assignarEstatAgent(agent, params.get("estatAgent"));
        agent.setTipusLlicenciaConduir("B");
    }

    /**
     * Assigna el rol a l'agent a partir d'un text (p. ex. "ADMIN", "AGENT"). Si
     * el valor no és vàlid, s'assigna {@link Rol#AGENT}.
     *
     * @param agent agent a actualitzar
     * @param rol rol rebut del formulari
     */
    private void assignarRol(Agent agent, String rol) {
        if (rol != null && !rol.trim().isEmpty()) {
            try {
                agent.setRol(Rol.valueOf(rol.toUpperCase()));
            } catch (IllegalArgumentException e) {
                agent.setRol(Rol.AGENT);
            }
        } else {
            agent.setRol(Rol.AGENT);
        }
    }

    /**
     * Assigna l'estat d'agent (ACTIU/INACTIU) a partir d'un text. Si el valor
     * no és vàlid, s'assigna {@link EstatAgent#ACTIU}.
     *
     * @param agent agent a actualitzar
     * @param estatAgent valor rebut del formulari
     */
    private void assignarEstatAgent(Agent agent, String estatAgent) {
        if (estatAgent != null && !estatAgent.trim().isEmpty()) {
            try {
                agent.setEstatAgent(EstatAgent.valueOf(estatAgent.toUpperCase()));
            } catch (IllegalArgumentException e) {
                agent.setEstatAgent(EstatAgent.ACTIU);
            }
        } else {
            agent.setEstatAgent(EstatAgent.ACTIU);
        }
    }

    /**
     * Processa i assigna les dates del formulari a l'agent.
     *
     * @param params paràmetres del formulari
     * @param agent agent a actualitzar
     * @param redirectAttributes atributs flash (actualment no s'utilitza aquí,
     * però es manté per coherència de firma)
     * @throws DateTimeParseException si el format de data no és correcte
     */
    private void procesarFechas(Map<String, String> params, Agent agent, RedirectAttributes redirectAttributes) {
        try {
            String dataId = params.get("dataCaducitatIdentificacio");
            String dataLic = params.get("dataCaducitatLlicencia");

            if (dataId != null && !dataId.isEmpty()) {
                agent.setDataCaducitatIdentificacio(LocalDate.parse(dataId));
            }
            if (dataLic != null && !dataLic.isEmpty()) {
                agent.setDataCaducitatLlicencia(LocalDate.parse(dataLic));
            }
        } catch (DateTimeParseException e) {
            throw e;
        }
    }

    /**
     * Assigna una {@link Localitzacio} a l'agent a partir del codi postal. Si
     * no es proporciona, l'agent queda sense localització.
     *
     * @param params paràmetres del formulari
     * @param agent agent a actualitzar
     */
    private void assignarLocalitzacio(Map<String, String> params, Agent agent) {
        String codiPostal = params.get("codiPostal");
        if (codiPostal != null && !codiPostal.trim().isEmpty()) {
            Localitzacio localitzacio = localitzacioService.obtenirLocalitzacioPerCodiPostal(codiPostal);
            agent.setLocalitzacio(localitzacio);
        } else {
            agent.setLocalitzacio(null);
        }
    }

    /**
     * Determina el nou estat d'un agent:
     * <ul>
     * <li>Si ve un estat explícit, intenta parsejar-lo.</li>
     * <li>Si no ve o és invàlid, fa toggle entre ACTIU i INACTIU.</li>
     * </ul>
     *
     * @param estatAgentParam estat rebut per paràmetre
     * @param estatActual estat actual de l'agent
     * @return nou estat a aplicar
     */
    private EstatAgent determinarNouEstat(String estatAgentParam, EstatAgent estatActual) {
        if (estatAgentParam != null && !estatAgentParam.trim().isEmpty()) {
            try {
                return EstatAgent.valueOf(estatAgentParam.toUpperCase());
            } catch (IllegalArgumentException e) {
                // Si el valor no és vàlid, s'aplica el comportament per defecte (toggle).
            }
        }
        return estatActual == EstatAgent.ACTIU ? EstatAgent.INACTIU : EstatAgent.ACTIU;
    }

    /**
     * Afegeix errors i valors del formulari com a atributs flash per poder
     * repintar el formulari.
     *
     * @param errors mapa camp -> missatge d'error
     * @param params valors originalment introduïts
     * @param redirectAttributes atributs flash
     */
    private void afegirErrorsRedireccio(Map<String, String> errors, Map<String, String> params, RedirectAttributes redirectAttributes) {
        params.forEach((key, value) -> redirectAttributes.addFlashAttribute(key + "Value", value));
        errors.forEach((camp, missatge) -> redirectAttributes.addFlashAttribute(camp + "Error", missatge));
    }

    /**
     * Afegeix un missatge d'èxit reutilitzable a l'UI (flash attributes).
     *
     * @param redirectAttributes atributs flash
     * @param missatge text del missatge
     */
    private void afegirMissatgeExit(RedirectAttributes redirectAttributes, String missatge) {
        redirectAttributes.addFlashAttribute("missatge", missatge);
        redirectAttributes.addFlashAttribute("tipusMissatge", "success");
    }

    /**
     * Afegeix un missatge d'error reutilitzable a l'UI (flash attributes).
     *
     * @param redirectAttributes atributs flash
     * @param missatge text del missatge
     */
    private void afegirMissatgeError(RedirectAttributes redirectAttributes, String missatge) {
        redirectAttributes.addFlashAttribute("missatge", missatge);
        redirectAttributes.addFlashAttribute("tipusMissatge", "danger");
    }
}
