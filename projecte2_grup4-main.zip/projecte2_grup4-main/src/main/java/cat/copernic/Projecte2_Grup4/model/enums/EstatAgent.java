package cat.copernic.Projecte2_Grup4.model.enums;

/**
 * Enumeració que representa l'estat d'un agent.
 *
 * <p>
 * Indica si l'agent es troba actiu (pot operar al sistema) o inactiu.</p>
 */
public enum EstatAgent {
    ACTIU,
    INACTIU
}
