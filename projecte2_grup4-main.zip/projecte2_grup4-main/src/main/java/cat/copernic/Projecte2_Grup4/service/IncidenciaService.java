package cat.copernic.Projecte2_Grup4.service;

import cat.copernic.Projecte2_Grup4.model.Incidencia;
import cat.copernic.Projecte2_Grup4.model.enums.Antiguitat;
import cat.copernic.Projecte2_Grup4.model.enums.EstatIncidencia;
import cat.copernic.Projecte2_Grup4.model.enums.AccioIncidenciaNoSQL;
import cat.copernic.Projecte2_Grup4.repository.IncidenciaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Servei de negoci per a la gestió d'incidències del sistema.
 *
 * <p>
 * Centralitza la lògica relacionada amb:
 * <ul>
 * <li>Alta i edició d'incidències.</li>
 * <li>Validacions de camps i regles de coherència.</li>
 * <li>Filtratge i visibilitat segons rol/usuari.</li>
 * <li>Activació, desactivació i eliminació.</li>
 * <li>Actualització automàtica de l'antiguitat (tasca planificada).</li>
 * <li>Traçabilitat mitjançant l'enregistrament de canvis a NoSQL.</li>
 * </ul>
 * </p>
 */
@Service
public class IncidenciaService {

    /**
     * Repositori principal d'accés a dades per a les incidències.
     */
    private final IncidenciaRepository incidenciaRepository;

    /**
     * Servei d'històric NoSQL per enregistrar les accions i canvis
     * d'incidència.
     */
    private final HistoricIncidenciaNoSQLService historicService;

    /**
     * Constructor amb injecció de dependències.
     *
     * @param incidenciaRepository repositori d'incidències
     * @param historicService servei d'històric NoSQL
     */
    @Autowired
    public IncidenciaService(IncidenciaRepository incidenciaRepository, HistoricIncidenciaNoSQLService historicService) {
        this.incidenciaRepository = incidenciaRepository;
        this.historicService = historicService;
    }

    /**
     * Llista totes les incidències del sistema.
     *
     * @return llista completa d'incidències
     */
    public List<Incidencia> llistarTotesIncidencies() {
        return incidenciaRepository.findAll();
    }

    /**
     * Llista les incidències visibles per a un usuari segons el seu rol.
     *
     * <p>
     * Regles:
     * <ul>
     * <li>Si el rol és ADMIN, es retornen totes les incidències.</li>
     * <li>En cas contrari, només es retornen les incidències creades per
     * l'usuari o assignades a l'usuari.</li>
     * <li>Si el nom d'usuari és buit, es retorna una llista buida.</li>
     * </ul>
     * </p>
     *
     * @param rol rol de l'usuari (p. ex. "ADMIN")
     * @param nomUser nom de l'usuari autenticat
     * @return llista d'incidències visibles
     */
    public List<Incidencia> llistarIncidenciesVisibles(String rol, String nomUser) {
        List<Incidencia> totes = incidenciaRepository.findAll();

        if (rol != null && rol.equalsIgnoreCase("ADMIN")) {
            return totes;
        }

        String u = nomUser == null ? "" : nomUser.trim();
        if (u.isEmpty()) {
            return List.of();
        }

        return totes.stream()
                .filter(i -> u.equalsIgnoreCase(i.getCreadoPor()) || u.equalsIgnoreCase(i.getAssignadaA()))
                .toList();
    }

    /**
     * Desa una incidència i retorna l'entitat guardada.
     *
     * <p>
     * Inclou:
     * <ul>
     * <li>Validació de camps abans de persistir.</li>
     * <li>Inicialització de valors en incidències noves (estat, antiguitat i
     * data de creació).</li>
     * <li>Assignació automàtica del responsable si no n'hi ha.</li>
     * <li>Regla de negoci: un vehicle no pot tenir més d'una incidència
     * activa.</li>
     * <li>Actualització de l'antiguitat si supera 24 hores.</li>
     * <li>Enregistrament del canvi a l'històric NoSQL segons el tipus
     * d'operació.</li>
     * </ul>
     * </p>
     *
     * @param incidencia incidència a guardar
     * @return incidència guardada amb els canvis persistits
     * @throws IllegalArgumentException si hi ha errors de validació o si el
     * vehicle ja té una incidència activa
     */
    public Incidencia guardarIncidenciaIRetornar(Incidencia incidencia) {
        validarIncidenciaAbansGuardar(incidencia);

        boolean esNova = incidencia.getIdIncidence() == null;

        EstatIncidencia estatAbans = null;
        if (!esNova) {
            Incidencia existent = obtenirIncidenciaPerld(incidencia.getIdIncidence());
            if (existent != null) {
                estatAbans = existent.getEstat();
            }
        }

        if (esNova && incidencia.getVehicle() != null && incidencia.getVehicle().getMatricule() != null) {
            String mat = incidencia.getVehicle().getMatricule();
            if (!incidenciaRepository.findByVehicleMatriculeAndEstat(mat, EstatIncidencia.Activa).isEmpty()) {
                throw new IllegalArgumentException("Aquest vehicle ja té una incidència activa. Primer cal tancar-la.");
            }
        }

        if (esNova) {
            incidencia.setEstat(EstatIncidencia.Activa);
            incidencia.setAntiguitat(Antiguitat.Nova);
            incidencia.setDataCreacio(LocalDateTime.now());
        }

        if (incidencia.getAssignadaA() == null || incidencia.getAssignadaA().trim().isEmpty()) {
            if (incidencia.getCreadoPor() != null && !incidencia.getCreadoPor().trim().isEmpty()) {
                incidencia.setAssignadaA(incidencia.getCreadoPor().trim());
            } else {
                incidencia.setAssignadaA("ADMIN");
            }
        }

        if (incidencia.getEstat() == EstatIncidencia.Inactiva) {
            incidencia.setAntiguitat(Antiguitat.Antiga);
        }

        marcarAntigaSiTeMesDe24Hores(incidencia);

        Incidencia guardada = incidenciaRepository.save(incidencia);

        String responsable = "ADMIN";

        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.getAuthorities() != null && auth.getAuthorities().stream().noneMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()))) {
                // Si no és admin, utilitzem l'usuari autenticat
                responsable = auth.getName();
            }
        } catch (Exception ignored) {
        }

        if (esNova) {
            historicService.enregistrarCanvi(guardada, AccioIncidenciaNoSQL.CREA, responsable, "Creació d'incidència");
        } else {
            if (estatAbans != null && estatAbans != guardada.getEstat() && guardada.getEstat() == EstatIncidencia.Inactiva) {
                historicService.enregistrarCanvi(guardada, AccioIncidenciaNoSQL.FINALITZA, responsable, "Finalització d'incidència");
            } else {
                historicService.enregistrarCanvi(guardada, AccioIncidenciaNoSQL.MODIFICA, responsable, "Modificació d'incidència");
            }
        }
        return guardada;
    }

    /**
     * Desa una incidència sense retornar-ne el resultat.
     *
     * @param incidencia incidència a guardar
     * @throws IllegalArgumentException si falla la validació
     */
    public void guardarIncidencia(Incidencia incidencia) {
        guardarIncidenciaIRetornar(incidencia);
    }

    /**
     * Marca com a antiga una incidència si han passat 24 hores o més des de la
     * seva creació.
     *
     * <p>
     * Només aplica si la incidència té data de creació i actualment és
     * {@link Antiguitat#Nova}.</p>
     *
     * @param incidencia incidència a revisar/actualitzar
     */
    private void marcarAntigaSiTeMesDe24Hores(Incidencia incidencia) {
        if (incidencia == null) {
            return;
        }
        if (incidencia.getDataCreacio() == null) {
            return;
        }
        if (incidencia.getAntiguitat() != Antiguitat.Nova) {
            return;
        }

        long hores = java.time.Duration.between(incidencia.getDataCreacio(), LocalDateTime.now()).toHours();
        if (hores >= 24) {
            incidencia.setAntiguitat(Antiguitat.Antiga);
        }
    }

    /**
     * Valida una incidència i retorna un mapa amb els errors detectats.
     *
     * <p>
     * Validacions incloses:
     * <ul>
     * <li>Títol obligatori i longitud màxima de 200 caràcters.</li>
     * <li>Cost (si s'informa): no negatiu i no superior a 1.000.000,00 €.</li>
     * <li>Estat obligatori.</li>
     * </ul>
     * </p>
     *
     * @param incidencia incidència a validar
     * @return mapa d'errors (clau = camp, valor = missatge). Buit si no hi ha
     * errors.
     */
    public Map<String, String> validarIncidencia(Incidencia incidencia) {
        Map<String, String> errors = new HashMap<>();

        // Validar títol
        if (incidencia.getTitle() == null || incidencia.getTitle().trim().isEmpty()) {
            errors.put("title", "El títol és obligatori");
        } else if (incidencia.getTitle().length() > 200) {
            errors.put("title", "El títol no pot superar els 200 caràcters");
        }

        // Validar cost
        if (incidencia.getEstimatedCost() != null) {
            BigDecimal cost = incidencia.getEstimatedCost();
            BigDecimal max = new BigDecimal("1000000.00");

            if (cost.compareTo(BigDecimal.ZERO) < 0) {
                errors.put("estimatedCost", "El cost no pot ser negatiu");
            } else if (cost.compareTo(max) > 0) {
                errors.put("estimatedCost", "El cost no pot superar 1.000.000,00 €");
            }
        }

        // Validar estat
        if (incidencia.getEstat() == null) {
            errors.put("estat", "L'estat és obligatori");
        }

        return errors;
    }

    /**
     * Valida una incidència abans de guardar-la i llança una excepció si hi ha
     * errors.
     *
     * @param incidencia incidència a validar
     * @throws IllegalArgumentException si hi ha errors de validació
     */
    private void validarIncidenciaAbansGuardar(Incidencia incidencia) {
        Map<String, String> errors = validarIncidencia(incidencia);
        if (!errors.isEmpty()) {
            throw new IllegalArgumentException("Errors de validació: " + errors);
        }
    }

    /**
     * Obté una incidència pel seu identificador.
     *
     * @param id identificador de la incidència
     * @return incidència trobada o {@code null} si no existeix
     */
    public Incidencia obtenirIncidenciaPerld(Integer id) {
        return incidenciaRepository.findById(id).orElse(null);
    }

    /**
     * Elimina una incidència pel seu identificador.
     *
     * <p>
     * Abans de l'eliminació al repositori, s'enregistra l'acció a l'històric
     * com a {@link AccioIncidenciaNoSQL#DESACTIVA} (borrat lògic).</p>
     *
     * @param id identificador de la incidència
     */
    public void eliminarIncidencia(Integer id) {
        Incidencia incidencia = obtenirIncidenciaPerld(id);
        if (incidencia != null) {
            String responsable = incidencia.getAssignadaA() != null ? incidencia.getAssignadaA() : "ADMIN";
            historicService.enregistrarCanvi(incidencia, AccioIncidenciaNoSQL.DESACTIVA, responsable, "Desactivació (borrat lògic)");
            incidenciaRepository.deleteById(id);
        }
    }

    /**
     * Tasca programada diàriament que actualitza l'antiguitat de les
     * incidències noves.
     *
     * <p>
     * S'executa cada dia a les 00:00 i marca com a {@link Antiguitat#Antiga}
     * les incidències que ja tenen 24 hores o més des de la data de
     * creació.</p>
     */
    @Scheduled(cron = "0 0 0 * * ?")
    public void actualitzarAntiguitatDiaria() {
        List<Incidencia> incidenciesNoves = incidenciaRepository.findByAntiguitat(Antiguitat.Nova);
        LocalDateTime ara = LocalDateTime.now();

        for (Incidencia incidencia : incidenciesNoves) {
            if (incidencia.getDataCreacio() == null) {
                continue;
            }

            long hores = java.time.Duration.between(incidencia.getDataCreacio(), ara).toHours();
            if (hores >= 24) {
                incidencia.setAntiguitat(Antiguitat.Antiga);
                incidenciaRepository.save(incidencia);
            }
        }
    }

    /**
     * Desactiva (tanca) una incidència: la marca com a inactiva i antiga, i en
     * registra la finalització a l'històric.
     *
     * @param id identificador de la incidència
     */
    public void desactivarIncidencia(Integer id) {
        Incidencia incidencia = obtenirIncidenciaPerld(id);
        if (incidencia != null) {
            incidencia.setEstat(EstatIncidencia.Inactiva);
            incidencia.setAntiguitat(Antiguitat.Antiga);
            incidenciaRepository.save(incidencia);

            String responsable = incidencia.getAssignadaA() != null ? incidencia.getAssignadaA() : "ADMIN";
            historicService.enregistrarCanvi(incidencia, AccioIncidenciaNoSQL.FINALITZA, responsable, "Finalització d'incidència");
        }
    }

    /**
     * Reactiva una incidència: la marca com a activa i en registra la
     * reactivació a l'històric.
     *
     * @param id identificador de la incidència
     */
    public void activarIncidencia(Integer id) {
        Incidencia incidencia = obtenirIncidenciaPerld(id);
        if (incidencia != null) {
            incidencia.setEstat(EstatIncidencia.Activa);
            incidenciaRepository.save(incidencia);

            String responsable = incidencia.getAssignadaA() != null ? incidencia.getAssignadaA() : "ADMIN";
            historicService.enregistrarCanvi(incidencia, AccioIncidenciaNoSQL.REACTIVA, responsable, "Reactivació d'incidència");
        }
    }

    /**
     * Reassigna a ADMIN totes les incidències que estaven assignades a un agent
     * concret.
     *
     * <p>
     * És útil quan un agent deixa d'estar disponible i es vol retornar la
     * càrrega al rol administrador.</p>
     *
     * @param nomUserAgent nom d'usuari de l'agent
     * @return nombre d'incidències reassignades
     */
    public int reassignarIncidenciesAssignadesDeAgentAAdmin(String nomUserAgent) {
        if (nomUserAgent == null || nomUserAgent.trim().isEmpty()) {
            return 0;
        }

        List<Incidencia> incidencies = incidenciaRepository.findByAssignadaA(nomUserAgent.trim());
        int count = 0;

        for (Incidencia i : incidencies) {
            i.setAssignadaA("ADMIN");
            incidenciaRepository.save(i);
            count++;
        }
        return count;
    }

    /**
     * Restaura l'assignació d'incidències a un agent quan torna a estar actiu.
     *
     * <p>
     * Recupera incidències creades per l'agent que havien quedat assignades
     * temporalment a ADMIN.</p>
     *
     * @param nomUserAgent nom d'usuari de l'agent
     * @return nombre d'incidències restaurades
     */
    public int restaurarIncidenciesDeAgentQuanReactivat(String nomUserAgent) {
        if (nomUserAgent == null || nomUserAgent.trim().isEmpty()) {
            return 0;
        }

        String agent = nomUserAgent.trim();
        List<Incidencia> incidencies = incidenciaRepository.findByCreadoPorAndAssignadaA(agent, "ADMIN");
        int count = 0;

        for (Incidencia i : incidencies) {
            i.setAssignadaA(agent);
            incidenciaRepository.save(i);
            count++;
        }
        return count;
    }

    /**
     * Filtra incidències per estat.
     *
     * @param estat estat a filtrar
     * @return llista d'incidències amb l'estat indicat
     */
    public List<Incidencia> filtrarPerEstat(EstatIncidencia estat) {
        return incidenciaRepository.findByEstat(estat);
    }

    /**
     * Filtra incidències per antiguitat.
     *
     * @param antiguitat antiguitat a filtrar
     * @return llista d'incidències amb l'antiguitat indicada
     */
    public List<Incidencia> filtrarPerAntiguitat(Antiguitat antiguitat) {
        return incidenciaRepository.findByAntiguitat(antiguitat);
    }

    /**
     * Filtra incidències per matrícula del vehicle.
     *
     * @param matricule matrícula del vehicle
     * @return llista d'incidències associades al vehicle indicat
     */
    public List<Incidencia> filtrarPerVehicle(String matricule) {
        return incidenciaRepository.findByVehicleMatricule(matricule);
    }
}
