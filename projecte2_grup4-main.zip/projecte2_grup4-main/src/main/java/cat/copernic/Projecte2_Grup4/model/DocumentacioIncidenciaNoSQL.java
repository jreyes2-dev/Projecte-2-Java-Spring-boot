package cat.copernic.Projecte2_Grup4.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.List;

@Document(collection = "documentacio_incidencies")
/**
 * Document NoSQL que emmagatzema la documentació associada a una incidència.
 *
 * <p>
 * La col·lecció {@code documentacio_incidencies} guarda fitxers binaris
 * (imatges o PDF) vinculats a una incidència concreta. Aquest document permet
 * centralitzar:</p>
 * <ul>
 * <li>Fotografies del dany (amb noms i tipus de contingut).</li>
 * <li>Comunicat d'accident (opcional) i la seva metainformació.</li>
 * <li>Informe de taller (opcional) i la seva metainformació.</li>
 * <li>Fotografies del procés o resultat de la reparació (amb noms i tipus de
 * contingut).</li>
 * </ul>
 *
 * <p>
 * La metainformació de noms i {@code contentType} facilita la descàrrega o la
 * visualització correcta dels fitxers des de la capa web.</p>
 */
public class DocumentacioIncidenciaNoSQL {

    @Id
    private String id; // ID únic del document d'incidència

    private List<byte[]> fotosDany; // Fotos del dany o problema en format binari
    private List<String> fotosDanyNoms;
    private List<String> fotosDanyContentTypes;
    private byte[] comunicatAccident; // Comunicat d'accident escanejat en binari
    private String comunicatAccidentNom;
    private String comunicatAccidentContentType;
    private byte[] informeTaller; // Informe del taller en PDF en binari
    private String informeTallerNom;
    private String informeTallerContentType;
    private List<byte[]> fotosReparacio; // Fotos durant el procés de reparació en binari
    private List<String> fotosReparacioNoms;
    private List<String> fotosReparacioContentTypes;

    // ======================== CONSTRUCTORS ===================================
    /**
     * Constructor per defecte.
     */
    public DocumentacioIncidenciaNoSQL() {
    }

    /**
     * Constructor complet amb els principals continguts binaris.
     *
     * <p>
     * Aquest constructor inicialitza la informació bàsica del document. Les
     * llistes de noms i tipus de contingut es poden establir posteriorment
     * mitjançant els setters.</p>
     *
     * @param id identificador del document d'incidència
     * @param fotosDany llista de fotografies de dany en binari
     * @param comunicatAccident comunicat d'accident en binari
     * @param informeTaller informe del taller en binari (habitualment PDF)
     * @param fotosReparacio llista de fotografies de reparació en binari
     */
    public DocumentacioIncidenciaNoSQL(String id, List<byte[]> fotosDany, byte[] comunicatAccident,
            byte[] informeTaller, List<byte[]> fotosReparacio) {
        this.id = id;
        this.fotosDany = fotosDany;
        this.comunicatAccident = comunicatAccident;
        this.informeTaller = informeTaller;
        this.fotosReparacio = fotosReparacio;
    }

    // ======================== GETTERS & SETTERS =================================
    /**
     * Retorna l'identificador del document d'incidència.
     *
     * @return id del document
     */
    public String getId() {
        return id;
    }

    /**
     * Assigna l'identificador del document d'incidència.
     *
     * @param id id del document
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Retorna les fotografies de dany en format binari.
     *
     * @return llista de fotos de dany
     */
    public List<byte[]> getFotosDany() {
        return fotosDany;
    }

    /**
     * Assigna les fotografies de dany en format binari.
     *
     * @param fotosDany llista de fotos de dany
     */
    public void setFotosDany(List<byte[]> fotosDany) {
        this.fotosDany = fotosDany;
    }

    /**
     * Retorna els noms associats a les fotografies de dany.
     *
     * @return llista de noms de fitxer de les fotos de dany
     */
    public List<String> getFotosDanyNoms() {
        return fotosDanyNoms;
    }

    /**
     * Assigna els noms associats a les fotografies de dany.
     *
     * @param fotosDanyNoms llista de noms de fitxer
     */
    public void setFotosDanyNoms(List<String> fotosDanyNoms) {
        this.fotosDanyNoms = fotosDanyNoms;
    }

    /**
     * Retorna els tipus de contingut (MIME) associats a les fotografies de
     * dany.
     *
     * @return llista de content types de les fotos de dany
     */
    public List<String> getFotosDanyContentTypes() {
        return fotosDanyContentTypes;
    }

    /**
     * Assigna els tipus de contingut (MIME) associats a les fotografies de
     * dany.
     *
     * @param fotosDanyContentTypes llista de content types
     */
    public void setFotosDanyContentTypes(List<String> fotosDanyContentTypes) {
        this.fotosDanyContentTypes = fotosDanyContentTypes;
    }

    /**
     * Retorna el comunicat d'accident en format binari.
     *
     * @return comunicat d'accident
     */
    public byte[] getComunicatAccident() {
        return comunicatAccident;
    }

    /**
     * Assigna el comunicat d'accident en format binari.
     *
     * @param comunicatAccident comunicat d'accident
     */
    public void setComunicatAccident(byte[] comunicatAccident) {
        this.comunicatAccident = comunicatAccident;
    }

    /**
     * Retorna l'informe del taller en format binari.
     *
     * @return informe del taller
     */
    public byte[] getInformeTaller() {
        return informeTaller;
    }

    /**
     * Assigna l'informe del taller en format binari.
     *
     * @param informeTaller informe del taller
     */
    public void setInformeTaller(byte[] informeTaller) {
        this.informeTaller = informeTaller;
    }

    /**
     * Retorna les fotografies de reparació en format binari.
     *
     * @return llista de fotos de reparació
     */
    public List<byte[]> getFotosReparacio() {
        return fotosReparacio;
    }

    /**
     * Assigna les fotografies de reparació en format binari.
     *
     * @param fotosReparacio llista de fotos de reparació
     */
    public void setFotosReparacio(List<byte[]> fotosReparacio) {
        this.fotosReparacio = fotosReparacio;
    }

    /**
     * Retorna els noms associats a les fotografies de reparació.
     *
     * @return llista de noms de fitxer de les fotos de reparació
     */
    public List<String> getFotosReparacioNoms() {
        return fotosReparacioNoms;
    }

    /**
     * Assigna els noms associats a les fotografies de reparació.
     *
     * @param fotosReparacioNoms llista de noms de fitxer
     */
    public void setFotosReparacioNoms(List<String> fotosReparacioNoms) {
        this.fotosReparacioNoms = fotosReparacioNoms;
    }

    /**
     * Retorna els tipus de contingut (MIME) associats a les fotografies de
     * reparació.
     *
     * @return llista de content types de les fotos de reparació
     */
    public List<String> getFotosReparacioContentTypes() {
        return fotosReparacioContentTypes;
    }

    /**
     * Assigna els tipus de contingut (MIME) associats a les fotografies de
     * reparació.
     *
     * @param fotosReparacioContentTypes llista de content types
     */
    public void setFotosReparacioContentTypes(List<String> fotosReparacioContentTypes) {
        this.fotosReparacioContentTypes = fotosReparacioContentTypes;
    }

    /**
     * Retorna el nom del fitxer del comunicat d'accident.
     *
     * @return nom del comunicat d'accident
     */
    public String getComunicatAccidentNom() {
        return comunicatAccidentNom;
    }

    /**
     * Assigna el nom del fitxer del comunicat d'accident.
     *
     * @param comunicatAccidentNom nom del comunicat d'accident
     */
    public void setComunicatAccidentNom(String comunicatAccidentNom) {
        this.comunicatAccidentNom = comunicatAccidentNom;
    }

    /**
     * Retorna el tipus de contingut (MIME) del comunicat d'accident.
     *
     * @return content type del comunicat d'accident
     */
    public String getComunicatAccidentContentType() {
        return comunicatAccidentContentType;
    }

    /**
     * Assigna el tipus de contingut (MIME) del comunicat d'accident.
     *
     * @param comunicatAccidentContentType content type del comunicat d'accident
     */
    public void setComunicatAccidentContentType(String comunicatAccidentContentType) {
        this.comunicatAccidentContentType = comunicatAccidentContentType;
    }

    /**
     * Retorna el nom del fitxer de l'informe del taller.
     *
     * @return nom de l'informe del taller
     */
    public String getInformeTallerNom() {
        return informeTallerNom;
    }

    /**
     * Assigna el nom del fitxer de l'informe del taller.
     *
     * @param informeTallerNom nom de l'informe del taller
     */
    public void setInformeTallerNom(String informeTallerNom) {
        this.informeTallerNom = informeTallerNom;
    }

    /**
     * Retorna el tipus de contingut (MIME) de l'informe del taller.
     *
     * @return content type de l'informe del taller
     */
    public String getInformeTallerContentType() {
        return informeTallerContentType;
    }

    /**
     * Assigna el tipus de contingut (MIME) de l'informe del taller.
     *
     * @param informeTallerContentType content type de l'informe del taller
     */
    public void setInformeTallerContentType(String informeTallerContentType) {
        this.informeTallerContentType = informeTallerContentType;
    }

}
