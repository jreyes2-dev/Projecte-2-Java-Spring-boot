package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.model.User;
import cat.copernic.Projecte2_Grup4.model.Vehicle;
import cat.copernic.Projecte2_Grup4.model.enums.EstatVehicle;
import cat.copernic.Projecte2_Grup4.model.enums.Rol;
import cat.copernic.Projecte2_Grup4.repository.UserRepository;
import cat.copernic.Projecte2_Grup4.repository.VehicleRepository;
import cat.copernic.Projecte2_Grup4.service.LocalitzacioService;
import cat.copernic.Projecte2_Grup4.service.VehicleService;

import java.io.IOException;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/web/vehicles")
/**
 * Controlador web per a la gestió de vehicles.
 *
 * <p>
 * Proporciona funcionalitats de llistat, alta, edició, actualització,
 * eliminació i canvi d'estat (activació/desactivació). També permet servir la
 * fotografia associada a un vehicle.</p>
 *
 * <p>
 * El control d'accés s'aplica segons el rol de l'usuari autenticat:</p>
 * <ul>
 * <li><strong>ADMIN</strong>: pot crear i eliminar vehicles, a més
 * d'editar-los.</li>
 * <li><strong>AGENT</strong>: pot editar, activar i desactivar vehicles.</li>
 * <li><strong>CLIENT</strong>: no pot editar vehicles, però pot visualitzar la
 * foto d'un vehicle autenticat.</li>
 * </ul>
 */
public class VehicleController {

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private VehicleRepository vehicleRepository;

    @Autowired
    private LocalitzacioService localitzacioService;

    @Autowired
    private UserRepository userRepository;

    /**
     * Recupera l'usuari autenticat des del context de seguretat.
     *
     * @return usuari autenticat si existeix i és vàlid; en cas contrari
     * {@code null}
     */
    private User currentUserOrNull() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getName() == null) {
            return null;
        }
        return userRepository.findByNomUser(auth.getName()).orElse(null);
    }

    /**
     * Indica si l'usuari té rol de client.
     *
     * @param u usuari a comprovar
     * @return {@code true} si és {@link Rol#CLIENT}; en cas contrari
     * {@code false}
     */
    private boolean isClient(User u) {
        return u != null && u.getRol() == Rol.CLIENT;
    }

    /**
     * Indica si l'usuari té rol d'agent.
     *
     * @param u usuari a comprovar
     * @return {@code true} si és {@link Rol#AGENT}; en cas contrari
     * {@code false}
     */
    private boolean isAgent(User u) {
        return u != null && u.getRol() == Rol.AGENT;
    }

    /**
     * Indica si l'usuari té rol d'administrador.
     *
     * @param u usuari a comprovar
     * @return {@code true} si és {@link Rol#ADMIN}; en cas contrari
     * {@code false}
     */
    private boolean isAdmin(User u) {
        return u != null && u.getRol() == Rol.ADMIN;
    }

    /**
     * Indica si l'usuari té rol d'agent o d'administrador.
     *
     * @param u usuari a comprovar
     * @return {@code true} si és agent o admin; en cas contrari {@code false}
     */
    private boolean isAgentOrAdmin(User u) {
        return isAgent(u) || isAdmin(u);
    }

    /**
     * Configura el {@link WebDataBinder} per impedir que determinats camps del
     * model {@code vehicle} es puguin vincular directament des del formulari.
     *
     * <p>
     * Això evita que els camps binaris de la foto es puguin modificar
     * mitjançant binding i obliga a gestionar-los a través del fitxer
     * {@link MultipartFile}.</p>
     *
     * @param binder binder utilitzat per Spring MVC
     */
    @InitBinder("vehicle")
    public void initBinderVehicle(WebDataBinder binder) {
        binder.setDisallowedFields("foto", "fotoContentType");
    }

    /**
     * Llista vehicles o bé filtra per matrícula si s'especifica el paràmetre.
     *
     * @param matricula matrícula a cercar (opcional)
     * @param model model de Spring per exposar dades a la vista
     * @return vista de llistat de vehicles
     */
    @GetMapping("/llistar")
    public String llistarVehicles(
            @RequestParam(value = "matricula", required = false) String matricula,
            Model model) {

        if (matricula != null && !matricula.isBlank()) {
            Vehicle v = vehicleService.obtenirVehiclePerMatricula(matricula);
            model.addAttribute("llistaVehicles", (v != null) ? java.util.List.of(v) : java.util.List.of());
            model.addAttribute("matricula", matricula);
        } else {
            model.addAttribute("llistaVehicles", vehicleRepository.findAll());
            model.addAttribute("matricula", "");
        }
        return "vehicle/llistar-vehicles";
    }

    // ✅ Foto: permès a qualsevol autenticat (inclou CLIENT)
    /**
     * Serveix la fotografia associada a un vehicle en format binari.
     *
     * <p>
     * Si el vehicle no existeix o no té foto, retorna {@code 404}. En cas
     * contrari, retorna el contingut i el {@code Content-Type} detectat o, si
     * no està informat, {@code application/octet-stream}.</p>
     *
     * @param matricula matrícula del vehicle
     * @return resposta HTTP amb la imatge del vehicle
     */
    @GetMapping("/{matricula}/foto")
    @ResponseBody
    public ResponseEntity<byte[]> veureFoto(@PathVariable("matricula") String matricula) {
        Vehicle vehicle = vehicleRepository.findById(matricula).orElse(null);

        if (vehicle == null || vehicle.getFoto() == null || vehicle.getFoto().length == 0) {
            return ResponseEntity.notFound().build();
        }

        MediaType mt = MediaType.APPLICATION_OCTET_STREAM;
        try {
            if (vehicle.getFotoContentType() != null && !vehicle.getFotoContentType().isBlank()) {
                mt = MediaType.parseMediaType(vehicle.getFotoContentType());
            }
        } catch (Exception ignored) {
        }

        return ResponseEntity.ok()
                .contentType(mt)
                .cacheControl(CacheControl.noCache())
                .body(vehicle.getFoto());
    }

    // ✅ Crear: NOMÉS ADMIN
    /**
     * Mostra el formulari de creació d'un vehicle nou.
     *
     * <p>
     * Accés restringit a administradors.</p>
     *
     * @param model model de Spring per exposar el vehicle i les localitzacions
     * disponibles
     * @return vista de creació o redirecció a accés denegat si no hi ha
     * permisos
     */
    @GetMapping("/crear")
    public String crearVehicle(Model model) {
        User u = currentUserOrNull();
        if (!isAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        model.addAttribute("vehicle", new Vehicle());
        model.addAttribute("localitzacions", localitzacioService.llistarLocalitzacionsPerSelector());
        model.addAttribute("editant", false);
        return "vehicle/crear-vehicles";
    }

    // ✅ Guardar alta: NOMÉS ADMIN
    /**
     * Desa l'alta d'un vehicle nou, incloent-hi validacions bàsiques de
     * l'estat, la foto i la localització.
     *
     * <p>
     * Accés restringit a administradors. La foto és opcional i, si s'adjunta,
     * es valida:</p>
     * <ul>
     * <li>Formats admesos: JPG, PNG i WEBP.</li>
     * <li>Mida màxima: 5 MB.</li>
     * </ul>
     *
     * @param vehicle dades del vehicle provinents del formulari
     * @param codiPostal codi postal de la localització (opcional)
     * @param estatStr estat del vehicle en format {@link EstatVehicle}
     * (obligatori)
     * @param foto fitxer de foto (opcional)
     * @param redirect atributs flash per informar del resultat
     * @return redirecció al llistat de vehicles o al formulari en cas d'error
     */
    @PostMapping("/guardar")
    public String guardarVehicle(
            @ModelAttribute Vehicle vehicle,
            @RequestParam(value = "codiPostal", required = false) String codiPostal,
            @RequestParam(value = "estat", required = true) String estatStr,
            @RequestParam(value = "fotoFile", required = false) MultipartFile foto,
            RedirectAttributes redirect) {

        User u = currentUserOrNull();
        if (!isAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        try {
            vehicle.setEstat(EstatVehicle.valueOf(estatStr));
        } catch (Exception e) {
            redirect.addFlashAttribute("missatge", "Estat no vàlid: " + estatStr);
            redirect.addFlashAttribute("tipusMissatge", "danger");
            return "redirect:/web/vehicles/crear";
        }

        if (foto != null && !foto.isEmpty()) {
            String ct = foto.getContentType();

            if (ct == null || !(ct.equals("image/jpeg") || ct.equals("image/png") || ct.equals("image/webp"))) {
                redirect.addFlashAttribute("missatge", "Format d'imatge no permès (només JPG/PNG/WEBP)");
                redirect.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/vehicles/crear";
            }
            if (foto.getSize() > 5L * 1024 * 1024) {
                redirect.addFlashAttribute("missatge", "La imatge supera 5MB");
                redirect.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/vehicles/crear";
            }

            try {
                vehicle.setFoto(foto.getBytes());
                vehicle.setFotoContentType(ct);
            } catch (IOException e) {
                redirect.addFlashAttribute("missatge", "Error llegint la imatge");
                redirect.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/vehicles/crear";
            }
        }

        if (codiPostal != null && !codiPostal.isBlank()) {
            var loc = localitzacioService.obtenirLocalitzacioPerId(codiPostal);
            if (loc == null) {
                redirect.addFlashAttribute("missatge", "Codi postal inexistent: " + codiPostal);
                redirect.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/vehicles/crear";
            }
            vehicle.setLocalitzacio(loc);
        } else {
            vehicle.setLocalitzacio(null);
        }

        vehicleRepository.save(vehicle);

        redirect.addFlashAttribute("missatge", "Vehicle creat correctament");
        redirect.addFlashAttribute("tipusMissatge", "success");
        return "redirect:/web/vehicles/llistar";
    }

    // ✅ Editar: AGENT o ADMIN (CLIENT no)
    /**
     * Mostra el formulari d'edició d'un vehicle existent.
     *
     * <p>
     * Accés restringit a usuaris amb rol d'agent o administrador.</p>
     *
     * @param matricula matrícula del vehicle
     * @param model model de Spring per exposar el vehicle i les localitzacions
     * disponibles
     * @param redirect atributs flash per informar en cas de vehicle inexistent
     * @return vista d'edició o redirecció al llistat/accés denegat segons
     * correspongui
     */
    @GetMapping("/editar/{matricula}")
    public String editarVehicle(@PathVariable("matricula") String matricula,
            Model model,
            RedirectAttributes redirect) {

        User u = currentUserOrNull();
        if (!isAgentOrAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        Vehicle vehicle = vehicleRepository.findById(matricula).orElse(null);
        if (vehicle == null) {
            redirect.addFlashAttribute("missatge", "Vehicle no trobat");
            redirect.addFlashAttribute("tipusMissatge", "danger");
            return "redirect:/web/vehicles/llistar";
        }

        model.addAttribute("vehicle", vehicle);
        model.addAttribute("localitzacions", localitzacioService.llistarLocalitzacionsPerSelector());
        model.addAttribute("editant", true);
        return "vehicle/crear-vehicles";
    }

    // ✅ Actualitzar: AGENT o ADMIN (CLIENT no)
    /**
     * Actualitza un vehicle existent amb les dades del formulari.
     *
     * <p>
     * Accés restringit a usuaris amb rol d'agent o administrador. Gestiona de
     * manera controlada l'actualització de la foto (opcional) i la localització
     * (opcional), i valida el valor de l'estat.</p>
     *
     * @param vehicle dades provinents del formulari (inclou la matrícula per
     * identificar el registre)
     * @param codiPostal codi postal de la localització (opcional)
     * @param estatStr estat del vehicle en format {@link EstatVehicle}
     * (obligatori)
     * @param foto fitxer de foto (opcional)
     * @param redirect atributs flash per informar del resultat
     * @return redirecció al llistat o al formulari d'edició en cas d'error
     */
    @PostMapping("/actualitzar")
    public String actualitzarVehicle(
            @ModelAttribute Vehicle vehicle,
            @RequestParam(value = "codiPostal", required = false) String codiPostal,
            @RequestParam(value = "estat", required = true) String estatStr,
            @RequestParam(value = "fotoFile", required = false) MultipartFile foto,
            RedirectAttributes redirect) {

        User u = currentUserOrNull();
        if (!isAgentOrAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        Vehicle existent = vehicleRepository.findById(vehicle.getMatricule()).orElse(null);
        if (existent == null) {
            redirect.addFlashAttribute("missatge", "Vehicle no trobat");
            redirect.addFlashAttribute("tipusMissatge", "danger");
            return "redirect:/web/vehicles/llistar";
        }

        existent.setMarca(vehicle.getMarca());
        existent.setModel(vehicle.getModel());
        existent.setColor(vehicle.getColor());
        existent.setKilometres(vehicle.getKilometres());
        existent.setUltimManteniment(vehicle.getUltimManteniment());
        existent.setCostDiari(vehicle.getCostDiari());

        try {
            existent.setEstat(EstatVehicle.valueOf(estatStr));
        } catch (Exception e) {
            redirect.addFlashAttribute("missatge", "Estat no vàlid: " + estatStr);
            redirect.addFlashAttribute("tipusMissatge", "danger");
            return "redirect:/web/vehicles/editar/" + vehicle.getMatricule();
        }

        if (foto != null && !foto.isEmpty()) {
            String ct = foto.getContentType();

            if (ct == null || !(ct.equals("image/jpeg") || ct.equals("image/png") || ct.equals("image/webp"))) {
                redirect.addFlashAttribute("missatge", "Format d'imatge no permès (només JPG/PNG/WEBP)");
                redirect.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/vehicles/editar/" + vehicle.getMatricule();
            }
            if (foto.getSize() > 5L * 1024 * 1024) {
                redirect.addFlashAttribute("missatge", "La imatge supera 5MB");
                redirect.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/vehicles/editar/" + vehicle.getMatricule();
            }

            try {
                existent.setFoto(foto.getBytes());
                existent.setFotoContentType(ct);
            } catch (IOException e) {
                redirect.addFlashAttribute("missatge", "Error llegint la imatge");
                redirect.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/vehicles/editar/" + vehicle.getMatricule();
            }
        }

        if (codiPostal != null && !codiPostal.isBlank()) {
            var loc = localitzacioService.obtenirLocalitzacioPerId(codiPostal);
            if (loc == null) {
                redirect.addFlashAttribute("missatge", "Codi postal inexistent: " + codiPostal);
                redirect.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/vehicles/editar/" + vehicle.getMatricule();
            }
            existent.setLocalitzacio(loc);
        } else {
            existent.setLocalitzacio(null);
        }

        vehicleRepository.save(existent);

        redirect.addFlashAttribute("missatge", "Vehicle actualitzat correctament");
        redirect.addFlashAttribute("tipusMissatge", "success");
        return "redirect:/web/vehicles/llistar";
    }

    // ✅ Eliminar: NOMÉS ADMIN
    /**
     * Elimina un vehicle per matrícula.
     *
     * <p>
     * Accés restringit a administradors.</p>
     *
     * @param matricula matrícula del vehicle a eliminar
     * @param redirect atributs flash per informar del resultat
     * @return redirecció al llistat de vehicles
     */
    @PostMapping("/eliminar/{matricula}")
    public String eliminarVehicle(@PathVariable("matricula") String matricula,
            RedirectAttributes redirect) {

        User u = currentUserOrNull();
        if (!isAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        if (vehicleRepository.existsById(matricula)) {
            vehicleRepository.deleteById(matricula);
            redirect.addFlashAttribute("missatge", "Vehicle eliminat correctament");
            redirect.addFlashAttribute("tipusMissatge", "success");
        } else {
            redirect.addFlashAttribute("missatge", "Vehicle no trobat");
            redirect.addFlashAttribute("tipusMissatge", "danger");
        }

        return "redirect:/web/vehicles/llistar";
    }

    // ✅ Desactivar: AGENT o ADMIN
    /**
     * Desactiva un vehicle i, opcionalment, registra una data de fi de
     * desactivació.
     *
     * <p>
     * Accés restringit a usuaris amb rol d'agent o administrador.</p>
     *
     * @param matricula matrícula del vehicle
     * @param dataFiStr data de fi de desactivació en format ISO (opcional)
     * @param redirect atributs flash per informar del resultat
     * @return redirecció al llistat filtrat per matrícula
     */
    @PostMapping("/desactivar/{matricula}")
    public String desactivarVehicle(
            @PathVariable("matricula") String matricula,
            @RequestParam(value = "dataFiDesactivacio", required = false) String dataFiStr,
            RedirectAttributes redirect) {

        User u = currentUserOrNull();
        if (!isAgentOrAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        LocalDate dataFi = null;
        try {
            if (dataFiStr != null && !dataFiStr.isBlank()) {
                dataFi = LocalDate.parse(dataFiStr);
            }
            vehicleService.desactivarVehicle(matricula, dataFi);

            redirect.addFlashAttribute("missatge", "Vehicle desactivat correctament");
            redirect.addFlashAttribute("tipusMissatge", "success");

        } catch (Exception e) {
            redirect.addFlashAttribute("missatge", e.getMessage());
            redirect.addFlashAttribute("tipusMissatge", "danger");
        }

        return "redirect:/web/vehicles/llistar?matricula=" + matricula;
    }

    // ✅ Activar: AGENT o ADMIN
    /**
     * Activa un vehicle i, opcionalment, registra informació associada a
     * l'activació.
     *
     * <p>
     * Accés restringit a usuaris amb rol d'agent o administrador.</p>
     *
     * @param matricula matrícula del vehicle
     * @param motiu motiu de l'activació (opcional)
     * @param importActivacio import associat a l'activació (opcional)
     * @param redirect atributs flash per informar del resultat
     * @return redirecció al llistat filtrat per matrícula
     */
    @PostMapping("/activar/{matricula}")
    public String activarVehicle(
            @PathVariable("matricula") String matricula,
            @RequestParam(value = "motiu", required = false) String motiu,
            @RequestParam(value = "importActivacio", required = false) Double importActivacio,
            RedirectAttributes redirect) {

        User u = currentUserOrNull();
        if (!isAgentOrAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        try {
            vehicleService.activarVehicle(matricula, motiu, importActivacio);

            redirect.addFlashAttribute("missatge", "Vehicle activat correctament");
            redirect.addFlashAttribute("tipusMissatge", "success");

        } catch (Exception e) {
            redirect.addFlashAttribute("missatge", e.getMessage());
            redirect.addFlashAttribute("tipusMissatge", "danger");
        }

        return "redirect:/web/vehicles/llistar?matricula=" + matricula;
    }
}
