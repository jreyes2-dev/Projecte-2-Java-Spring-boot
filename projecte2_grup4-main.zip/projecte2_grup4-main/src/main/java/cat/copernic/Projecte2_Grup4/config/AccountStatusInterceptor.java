package cat.copernic.Projecte2_Grup4.config;

import cat.copernic.Projecte2_Grup4.model.Agent;
import cat.copernic.Projecte2_Grup4.model.Client;
import cat.copernic.Projecte2_Grup4.model.enums.Estat;
import cat.copernic.Projecte2_Grup4.model.enums.EstatAgent;
import cat.copernic.Projecte2_Grup4.repository.AgentRepository;
import cat.copernic.Projecte2_Grup4.repository.ClientRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.HandlerInterceptor;

import java.io.IOException;
import java.util.Collection;
import java.util.Optional;

/**
 *
 * Interceptor que comprova l'estat del compte abans de continuar.
 *
 */
public class AccountStatusInterceptor implements HandlerInterceptor {

    private final ClientRepository clientRepository;
    private final AgentRepository agentRepository;

    public AccountStatusInterceptor(ClientRepository clientRepository, AgentRepository agentRepository) {
        this.clientRepository = clientRepository;
        this.agentRepository = agentRepository;
    }

    /**
     * Processa la petició.
     * @param request paràmetre
     * @param response paràmetre
     * @param handler paràmetre
     * @return resultat
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws IOException {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || "anonymousUser".equals(auth.getPrincipal())) {
            return true;
        }

        String username = auth.getName();
        Collection<? extends GrantedAuthority> authorities = auth.getAuthorities();

        boolean isClient = authorities.stream().anyMatch(a -> "ROLE_CLIENT".equals(a.getAuthority()));
        boolean isAgentOrAdmin = authorities.stream().anyMatch(a
                -> "ROLE_AGENT".equals(a.getAuthority()) || "ROLE_ADMIN".equals(a.getAuthority())
        );

        if (isClient) {
            Optional<Client> optClient = clientRepository.findByNomUser(username);
            if (optClient.isPresent()) {
                Client c = optClient.get();

                if (c.getEstat() == Estat.DENEGAT) {
                    kick(request);
                    redirect(request, response, "/web/denegada-registre");
                    return false;
                }

                if (c.getEstat() == Estat.PENDENT) {
                    kick(request);
                    redirect(request, response, "/web/pendent");
                    return false;
                }
            }
        }

        if (isAgentOrAdmin) {
            Optional<Agent> optAgent = agentRepository.findByNomUser(username);

            if (optAgent.isPresent() && optAgent.get().getEstatAgent() == EstatAgent.INACTIU) {
                kick(request);
                redirect(request, response, "/web/login?inactive");
                return false;
            }
        }

        return true;
    }

    private void kick(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        SecurityContextHolder.clearContext();
    }

    private void redirect(HttpServletRequest request, HttpServletResponse response, String path) throws IOException {
        String ctx = request.getContextPath();
        response.sendRedirect(ctx + path);
    }
}
