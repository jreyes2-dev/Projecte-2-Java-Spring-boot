package cat.copernic.Projecte2_Grup4.config;

import org.springframework.security.core.AuthenticationException;

/**
 *
 * Excepció d'autenticació específica.
 *
 */
public class ClientPendingAuthenticationException extends AuthenticationException {

    public ClientPendingAuthenticationException(String msg) {
        super(msg);
    }
}
