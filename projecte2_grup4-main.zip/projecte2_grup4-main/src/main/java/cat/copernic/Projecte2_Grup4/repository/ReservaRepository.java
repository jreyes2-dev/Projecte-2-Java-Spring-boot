package cat.copernic.Projecte2_Grup4.repository;

import cat.copernic.Projecte2_Grup4.model.Reserva;
import cat.copernic.Projecte2_Grup4.model.enums.EstatReserva;
import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * Repositori JPA per gestionar la persistència d'entitats {@link Reserva}.
 *
 * <p>
 * Inclou consultes per llistar reserves d'un client i per validar
 * disponibilitat de vehicles (solapament de dates i reserves en curs o
 * futures). També incorpora mètodes de cerca per codi de reserva, email i
 * matrícula.</p>
 */
public interface ReservaRepository extends JpaRepository<Reserva, Long> {

    // RF53: reserves pròpies
    /**
     * Recupera les reserves d'un client, ordenades per data d'inici descendent.
     *
     * @param dni DNI del client
     * @return llista de reserves del client
     */
    List<Reserva> findByClientDniOrderByDataIniciDesc(String dni);

    // Comprovar solapament: existeix reserva del vehicle que xafi dates?
    // Overlap típic: (inici < fiNova) AND (fi > iniciNova)
    /**
     * Compta quantes reserves no cancel·lades d'un vehicle se solapen amb un
     * interval de dates.
     *
     * <p>
     * Solapament considerat:
     * {@code (dataInici < dataFiNova) AND (dataFi > dataIniciNova)}.</p>
     *
     * @param matricula matrícula del vehicle
     * @param dataInici data d'inici sol·licitada
     * @param dataFi data de fi sol·licitada
     * @param estatCancelat estat que es considera cancel·lat (exclòs del
     * còmput)
     * @return nombre de reserves solapades
     */
    @Query("""
        SELECT COUNT(r)
        FROM Reserva r
        WHERE r.vehicle.matricule = :matricula
          AND r.estat <> :estatCancelat
          AND (r.dataInici < :dataFi AND r.dataFi > :dataInici)
    """)
    long countReservesSolapades(
            @Param("matricula") String matricula,
            @Param("dataInici") LocalDate dataInici,
            @Param("dataFi") LocalDate dataFi,
            @Param("estatCancelat") EstatReserva estatCancelat
    );

    /**
     * Compta quantes reserves no cancel·lades d'un vehicle estan en curs o són
     * futures (a partir d'una data).
     *
     * @param matricula matrícula del vehicle
     * @param avui data de referència (normalment, la data actual)
     * @param estatCancelat estat que es considera cancel·lat (exclòs del
     * còmput)
     * @return nombre de reserves en curs o futures
     */
    @Query("""
        SELECT COUNT(r)
        FROM Reserva r
        WHERE r.vehicle.matricule = :matricula
          AND r.estat <> :estatCancelat
          AND r.dataFi >= :avui
    """)
    long countReservesNoCanceladesEnCursOFutures(
            @Param("matricula") String matricula,
            @Param("avui") LocalDate avui,
            @Param("estatCancelat") EstatReserva estatCancelat
    );

    /**
     * Cerca reserves per codi de reserva i/o correu electrònic del client.
     *
     * <p>
     * Quan un paràmetre és {@code null} o buit, no s'aplica com a filtre.</p>
     *
     * @param codi codi de reserva (coincidència exacta, ignorant
     * majúscules/minúscules)
     * @param email correu del client (coincidència exacta, ignorant
     * majúscules/minúscules)
     * @return llista de reserves que compleixen els criteris
     */
    @Query("""
    SELECT r
    FROM Reserva r
    WHERE (:codi IS NULL OR :codi = '' OR LOWER(r.codiReserva) = LOWER(:codi))
      AND (:email IS NULL OR :email = '' OR LOWER(r.client.email) = LOWER(:email))
""")
    List<Reserva> cercarPerCodiOEmail(
            @Param("codi") String codi,
            @Param("email") String email
    );

    /**
     * Cerca reserves per codi de reserva, correu electrònic del client i/o
     * matrícula del vehicle.
     *
     * <p>
     * Quan un paràmetre és {@code null} o buit, no s'aplica com a filtre.</p>
     *
     * @param codi codi de reserva (coincidència exacta, ignorant
     * majúscules/minúscules)
     * @param email correu del client (coincidència exacta, ignorant
     * majúscules/minúscules)
     * @param matricula matrícula del vehicle (coincidència exacta, ignorant
     * majúscules/minúscules)
     * @return llista de reserves que compleixen els criteris
     */
    @Query("""
    SELECT r
    FROM Reserva r
    WHERE (:codi IS NULL OR :codi = '' OR LOWER(r.codiReserva) = LOWER(:codi))
      AND (:email IS NULL OR :email = '' OR LOWER(r.client.email) = LOWER(:email))
      AND (:matricula IS NULL OR :matricula = '' OR LOWER(r.vehicle.matricule) = LOWER(:matricula))
""")
    List<Reserva> cercarPerCodiEmailOMatricula(
            @Param("codi") String codi,
            @Param("email") String email,
            @Param("matricula") String matricula
    );

}
