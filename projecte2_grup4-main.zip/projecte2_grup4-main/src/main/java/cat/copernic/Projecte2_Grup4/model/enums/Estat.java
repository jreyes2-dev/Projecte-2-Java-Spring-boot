package cat.copernic.Projecte2_Grup4.model.enums;

/**
 * Enumeració que defineix l'estat administratiu d'un usuari o client.
 *
 * <p>
 * Permet representar si un usuari ha estat acceptat, denegat o està pendent de
 * validació.</p>
 */
public enum Estat {
    ACEPTAT, DENEGAT, PENDENT
}
