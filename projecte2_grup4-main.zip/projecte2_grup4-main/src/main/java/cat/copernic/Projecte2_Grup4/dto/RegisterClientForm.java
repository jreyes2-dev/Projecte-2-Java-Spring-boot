package cat.copernic.Projecte2_Grup4.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

/**
 *
 * Classe de l'aplicació.
 *
 */
public class RegisterClientForm {

    @NotBlank(message = "El DNI és obligatori")
    @Size(max = 20, message = "El DNI no pot superar 20 caràcters")
    private String dni;

    @NotBlank(message = "El nom és obligatori")
    @Size(max = 100, message = "El nom no pot superar 100 caràcters")
    private String nom;

    @NotBlank(message = "El primer cognom és obligatori")
    @Size(max = 100, message = "El primer cognom no pot superar 100 caràcters")
    private String cognom1;

    @Size(max = 100, message = "El segon cognom no pot superar 100 caràcters")
    private String cognom2;

    @NotBlank(message = "L'adreça és obligatòria")
    private String adreca;

    @NotBlank(message = "El nom d'usuari és obligatori")
    @Size(max = 100, message = "El nom d'usuari no pot superar 100 caràcters")
    private String nomUser;

    @NotBlank(message = "El correu electrònic és obligatori")
    @Email(message = "El correu electrònic no és vàlid")
    @Size(max = 100, message = "L'email no pot superar 100 caràcters")
    private String email;

    @NotBlank(message = "La contrasenya és obligatòria")
    @Size(min = 6, message = "La contrasenya ha de tenir com a mínim 6 caràcters")
    private String contrasenya;

    @NotBlank(message = "Has de repetir la contrasenya")
    private String repetirContrasenya;

    @NotBlank(message = "La nacionalitat és obligatòria")
    @Size(max = 80, message = "La nacionalitat no pot superar 80 caràcters")
    private String nacionalitat;

    @NotBlank(message = "El telèfon és obligatori")
    @Size(max = 50, message = "El telèfon no pot superar 50 caràcters")
    private String telefon;

    @NotNull(message = "La data de naixement és obligatòria")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate dataNaixement;

    @NotBlank(message = "El tipus de llicència és obligatori")
    @Size(max = 50, message = "El tipus de llicència no pot superar 50 caràcters")
    private String tipusLlicenciaConduir;

    @NotBlank(message = "El número de targeta és obligatori")
    @Size(max = 30, message = "El número de targeta no pot superar 30 caràcters")
    private String numeroTargetaCredit;

    @NotNull(message = "La caducitat del DNI/ID és obligatòria")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate dataCaducitatIdentificacio;

    @NotNull(message = "La caducitat de la llicència és obligatòria")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate dataCaducitatLlicencia;

    /**
     *
     * Retorna el valor corresponent.
     * @return resultat
     *
     */
    public String getDni() {
        return dni;
    }

    /**
     *
     * Assigna el valor indicat.
     * @param dni paràmetre
     *
     */
    public void setDni(String dni) {
        this.dni = dni;
    }

    /**
     *
     * Retorna el valor corresponent.
     * @return resultat
     *
     */
    public String getNom() {
        return nom;
    }

    /**
     *
     * Assigna el valor indicat.
     * @param nom paràmetre
     *
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     *
     * Retorna el valor corresponent.
     * @return resultat
     *
     */
    public String getCognom1() {
        return cognom1;
    }

    /**
     *
     * Assigna el valor indicat.
     * @param cognom1 paràmetre
     *
     */
    public void setCognom1(String cognom1) {
        this.cognom1 = cognom1;
    }

    /**
     *
     * Retorna el valor corresponent.
     * @return resultat
     *
     */
    public String getCognom2() {
        return cognom2;
    }

    /**
     *
     * Assigna el valor indicat.
     * @param cognom2 paràmetre
     *
     */
    public void setCognom2(String cognom2) {
        this.cognom2 = cognom2;
    }

    /**
     *
     * Retorna el valor corresponent.
     * @return resultat
     *
     */
    public String getAdreca() {
        return adreca;
    }

    /**
     *
     * Assigna el valor indicat.
     * @param adreca paràmetre
     *
     */
    public void setAdreca(String adreca) {
        this.adreca = adreca;
    }

    /**
     *
     * Retorna el valor corresponent.
     * @return resultat
     *
     */
    public String getNomUser() {
        return nomUser;
    }

    /**
     *
     * Assigna el valor indicat.
     * @param nomUser paràmetre
     *
     */
    public void setNomUser(String nomUser) {
        this.nomUser = nomUser;
    }

    /**
     *
     * Retorna el valor corresponent.
     * @return resultat
     *
     */
    public String getEmail() {
        return email;
    }

    /**
     *
     * Assigna el valor indicat.
     * @param email paràmetre
     *
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     *
     * Retorna el valor corresponent.
     * @return resultat
     *
     */
    public String getContrasenya() {
        return contrasenya;
    }

    /**
     *
     * Assigna el valor indicat.
     * @param contrasenya paràmetre
     *
     */
    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }

    /**
     *
     * Retorna el valor corresponent.
     *
     * @return resultat
     */
    public String getRepetirContrasenya() {
        return repetirContrasenya;
    }

    /**
     * Assigna el valor indicat.
     *
     * @param repetirContrasenya paràmetre
     */
    public void setRepetirContrasenya(String repetirContrasenya) {
        this.repetirContrasenya = repetirContrasenya;
    }

    /**
     * Retorna el valor corresponent.
     *
     * @return resultat
     */
    public String getNacionalitat() {
        return nacionalitat;
    }

    /**
     * Assigna el valor indicat.
     *
     * @param nacionalitat paràmetre
     */
    public void setNacionalitat(String nacionalitat) {
        this.nacionalitat = nacionalitat;
    }

    /**
     * Retorna el valor corresponent.
     * @return resultat
     */
    public String getTelefon() {
        return telefon;
    }

    /**
     * Assigna el valor indicat.
     *
     * @param telefon paràmetre
     */
    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    /**
     * Retorna el valor corresponent.
     *
     * @return resultat
     */
    public LocalDate getDataNaixement() {
        return dataNaixement;
    }

    /**
     * Assigna el valor indicat.
     *
     * @param dataNaixement paràmetre
     */
    public void setDataNaixement(LocalDate dataNaixement) {
        this.dataNaixement = dataNaixement;
    }

    /**
     * Retorna el valor corresponent.
     *
     * @return resultat
     */
    public String getTipusLlicenciaConduir() {
        return tipusLlicenciaConduir;
    }

    /**
     * Assigna el valor indicat.
     *
     * @param tipusLlicenciaConduir paràmetre
     */
    public void setTipusLlicenciaConduir(String tipusLlicenciaConduir) {
        this.tipusLlicenciaConduir = tipusLlicenciaConduir;
    }

    /**
     * Retorna el valor corresponent.
     *
     * @return resultat
     */
    public String getNumeroTargetaCredit() {
        return numeroTargetaCredit;
    }

    /**
     * Assigna el valor indicat.
     *
     * @param numeroTargetaCredit paràmetre
     */
    public void setNumeroTargetaCredit(String numeroTargetaCredit) {
        this.numeroTargetaCredit = numeroTargetaCredit;
    }

    /**
     * Retorna el valor corresponent.
     *
     * @return resultat
     */
    public LocalDate getDataCaducitatIdentificacio() {
        return dataCaducitatIdentificacio;
    }

    /**
     * Assigna el valor indicat.
     *
     * @param dataCaducitatIdentificacio paràmetre
     *
     */
    public void setDataCaducitatIdentificacio(LocalDate dataCaducitatIdentificacio) {
        this.dataCaducitatIdentificacio = dataCaducitatIdentificacio;
    }

    /**
     * Retorna el valor corresponent.
     *
     * @return resultat
     */
    public LocalDate getDataCaducitatLlicencia() {
        return dataCaducitatLlicencia;
    }

    /**
     * Assigna el valor indicat.
     *
     * @param dataCaducitatLlicencia paràmetre
     */
    public void setDataCaducitatLlicencia(LocalDate dataCaducitatLlicencia) {
        this.dataCaducitatLlicencia = dataCaducitatLlicencia;
    }

    /**
     * Executa l'operació.
     *
     * @return resultat
     */
    public boolean passwordsMatch() {
        return contrasenya != null && contrasenya.equals(repetirContrasenya);
    }
}
