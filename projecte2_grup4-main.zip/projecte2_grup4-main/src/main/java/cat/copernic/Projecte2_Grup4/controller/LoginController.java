package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.dto.RegisterClientForm;
import cat.copernic.Projecte2_Grup4.model.Client;
import cat.copernic.Projecte2_Grup4.model.enums.Estat;
import cat.copernic.Projecte2_Grup4.model.enums.Rol;
import cat.copernic.Projecte2_Grup4.repository.ClientRepository;
import cat.copernic.Projecte2_Grup4.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Controlador web.
 */

@Controller
public class LoginController {

    @GetMapping("/web/login")
    String login() {
        return "login_registre/login";
    }

    private final ClientRepository clientRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public LoginController(ClientRepository clientRepository, UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.clientRepository = clientRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

/**
 * Executa l'operació.
 * 
 * @param model paràmetre
 * @return resultat
 */

    @GetMapping("/web/register")
    public String registerForm(Model model) {
        if (!model.containsAttribute("registerForm")) {
            model.addAttribute("registerForm", new RegisterClientForm());
        }
        return "login_registre/register";
    }

    @PostMapping("/web/register")
    public String registerSubmit(
            @Valid @ModelAttribute("registerForm") RegisterClientForm form,
            BindingResult binding,
            RedirectAttributes redirect,
            Model model,
            HttpSession session
    ) {
        if (!binding.hasFieldErrors("repetirContrasenya") && !form.passwordsMatch()) {
            binding.rejectValue("repetirContrasenya", "password.mismatch", "Les contrasenyes no coincideixen");
        }

        if (!binding.hasFieldErrors("dni") && userRepository.existsById(form.getDni())) {
            binding.rejectValue("dni", "dni.exists", "Ja existeix un usuari amb aquest DNI");
        }
        if (!binding.hasFieldErrors("nomUser") && userRepository.existsByNomUser(form.getNomUser())) {
            binding.rejectValue("nomUser", "nomUser.exists", "Aquest nom d'usuari ja està en ús");
        }
        if (!binding.hasFieldErrors("email") && userRepository.existsByEmail(form.getEmail())) {
            binding.rejectValue("email", "email.exists", "Aquest correu electrònic ja està en ús");
        }

        if (binding.hasErrors()) {
            model.addAttribute("registerForm", form);
            return "login_registre/register";
        }

        Client client = new Client();
        client.setDni(form.getDni());
        client.setNom(form.getNom());
        client.setCognom1(form.getCognom1());
        client.setCognom2(form.getCognom2() == null ? "" : form.getCognom2());
        client.setAdreca(form.getAdreca());
        client.setNomUser(form.getNomUser());
        client.setEmail(form.getEmail());
        client.setContrasenya(passwordEncoder.encode(form.getContrasenya()));
        client.setTipusLlicenciaConduir(form.getTipusLlicenciaConduir());
        client.setNumeroTargetaCredit(form.getNumeroTargetaCredit());
        client.setDataCaducitatIdentificacio(form.getDataCaducitatIdentificacio());
        client.setDataCaducitatLlicencia(form.getDataCaducitatLlicencia());
        client.setNacionalitat(form.getNacionalitat());
        client.setTelefon(form.getTelefon());
        client.setDataNaixement(form.getDataNaixement());
        client.setPuntsRecolectats(0);
        client.setEstat(Estat.PENDENT);
        client.setRol(Rol.CLIENT);

        clientRepository.save(client);

        session.setAttribute("REGISTER_DNI", client.getDni());

        return "redirect:/web/register/validacio";
    }

/**
 * Executa l'operació.
 * 
 * @param session paràmetre
 * @return resultat
 */

    @GetMapping("/web/register/validacio")
    public String registreValidacio(HttpSession session) {
        Object dniObj = session.getAttribute("REGISTER_DNI");
        if (dniObj instanceof String dni && !dni.isBlank()) {
            clientRepository.findById(dni).ifPresent(c -> {
                if (c.getEstat() == Estat.DENEGAT) {
                    session.setAttribute("REGISTER_DENIED", true);
                }
            });
        }

        if (Boolean.TRUE.equals(session.getAttribute("REGISTER_DENIED"))) {
            session.removeAttribute("REGISTER_DENIED");
            return "redirect:/web/register/denegada";
        }

        return "login_registre/validacio-registre";
    }

/**
 * Executa l'operació.
 * 
 * @return resultat
 */

    @GetMapping("/web/register/denegada")
    public String registreDenegat() {
        return "login_registre/denegada-registre";
    }
}
