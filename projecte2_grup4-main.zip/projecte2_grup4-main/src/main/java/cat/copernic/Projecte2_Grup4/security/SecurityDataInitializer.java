package cat.copernic.Projecte2_Grup4.security;

import cat.copernic.Projecte2_Grup4.model.Agent;
import cat.copernic.Projecte2_Grup4.model.enums.Estat;
import cat.copernic.Projecte2_Grup4.model.enums.Rol;
import cat.copernic.Projecte2_Grup4.repository.AgentRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

/**
 * Inicialitzador de dades de seguretat que crea un usuari administrador inicial
 * si la base de dades arrenca buida.
 *
 * <p>
 * En ser un projecte acadèmic/prototip, aquesta inicialització es controla
 * mitjançant propietats de configuració. Si l'opció està activada i no existeix
 * cap agent amb rol {@link Rol#ADMIN}, es crea un {@link Agent} mínim amb
 * credencials configurables.</p>
 *
 * <p>
 * Propietats suportades (amb valors per defecte):</p>
 * <ul>
 * <li>{@code app.security.bootstrap-admin.enabled} (true)</li>
 * <li>{@code app.security.bootstrap-admin.dni} (00000000A)</li>
 * <li>{@code app.security.bootstrap-admin.username} (admin)</li>
 * <li>{@code app.security.bootstrap-admin.email} (admin@local)</li>
 * <li>{@code app.security.bootstrap-admin.password} (admin)</li>
 * </ul>
 */
@Component
public class SecurityDataInitializer implements CommandLineRunner {

    private final AgentRepository agentRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${app.security.bootstrap-admin.enabled:true}")
    private boolean enabled;

    @Value("${app.security.bootstrap-admin.dni:00000000A}")
    private String dni;

    @Value("${app.security.bootstrap-admin.username:admin}")
    private String username;

    @Value("${app.security.bootstrap-admin.email:admin@local}")
    private String email;

    @Value("${app.security.bootstrap-admin.password:admin}")
    private String password;

    /**
     * Constructor amb injecció de dependències.
     *
     * @param agentRepository repositori d'agents per persistir i consultar
     * administradors
     * @param passwordEncoder codificador per emmagatzemar la contrasenya en
     * format segur
     */
    public SecurityDataInitializer(AgentRepository agentRepository, PasswordEncoder passwordEncoder) {
        this.agentRepository = agentRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Executa la inicialització en l'arrencada de l'aplicació.
     *
     * <p>
     * Si la propietat {@code enabled} és {@code false}, no fa cap acció. Si ja
     * existeix algun agent amb rol {@link Rol#ADMIN}, tampoc no crea cap usuari
     * nou.</p>
     *
     * @param args arguments de línia d'ordres
     */
    @Override
    public void run(String... args) {
        if (!enabled) {
            return;
        }

        // Si ja hi ha algun ADMIN, no fem res
        boolean hiHaAdmin = agentRepository.findAll().stream().anyMatch(a -> a.getRol() == Rol.ADMIN);
        if (hiHaAdmin) {
            return;
        }

        // Si la BD està buida o no hi ha cap admin, creem un admin mínim
        Agent admin = new Agent();
        admin.setDni(dni);
        admin.setNom("Admin");
        admin.setCognom1("Sistema");
        admin.setCognom2("");
        admin.setAdreca("-");
        admin.setNomUser(username);
        admin.setEmail(email);
        admin.setContrasenya(passwordEncoder.encode(password));
        admin.setTipusLlicenciaConduir("-");
        admin.setNumeroTargetaCredit("-");
        admin.setDataCaducitatIdentificacio(LocalDate.now().plusYears(10));
        admin.setDataCaducitatLlicencia(LocalDate.now().plusYears(10));
        admin.setEstat(Estat.ACEPTAT);
        admin.setPuntsRecolectats(0);
        admin.setRol(Rol.ADMIN);

        agentRepository.save(admin);
    }
}
