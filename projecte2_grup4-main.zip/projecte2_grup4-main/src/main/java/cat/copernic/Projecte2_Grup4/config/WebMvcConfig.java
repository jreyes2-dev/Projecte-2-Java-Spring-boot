package cat.copernic.Projecte2_Grup4.config;

import cat.copernic.Projecte2_Grup4.repository.AgentRepository;
import cat.copernic.Projecte2_Grup4.repository.ClientRepository;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 *
 * Configura interceptors i regles MVC.
 *
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private final ClientRepository clientRepository;
    private final AgentRepository agentRepository;

    public WebMvcConfig(ClientRepository clientRepository, AgentRepository agentRepository) {
        this.clientRepository = clientRepository;
        this.agentRepository = agentRepository;
    }

    /**
     * Registra els interceptors de Spring MVC.
     *
     * <p>
     * Aplica {@link InactiveAgentInterceptor} sobre les rutes de la web i
     * exclou els endpoints d'autenticació i recursos estàtics per evitar bucles
     * de redirecció i millorar el rendiment.</p>
     *
     * @param registry registre d'interceptors de Spring MVC
     */
    /**
     * Afegeix un element.
     *
     * @param registry paràmetre
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new AccountStatusInterceptor(clientRepository, agentRepository))
                .addPathPatterns("/web/**")
                .excludePathPatterns(
                        "/web/login",
                        "/web/logout",
                        "/web/register/**",
                        "/web/pendent",
                        "/web/denegada-registre",
                        "/web/access-denied",
                        "/css/**",
                        "/js/**",
                        "/images/**",
                        "/webjars/**"
                );
    }
}
