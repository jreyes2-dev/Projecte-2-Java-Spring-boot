package cat.copernic.Projecte2_Grup4.repository;

import cat.copernic.Projecte2_Grup4.model.FotoLliurament;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

/**
 * Repositori JPA per gestionar entitats {@link FotoLliurament}.
 *
 * <p>
 * Permet recuperar les fotografies associades a una reserva, ordenades per data
 * de creació, per tal de mantenir la seqüència temporal de les imatges del
 * lliurament.</p>
 */
public interface FotoLliuramentRepository extends JpaRepository<FotoLliurament, Long> {

    /**
     * Recupera les fotos de lliurament d'una reserva, ordenades de més antiga a
     * més recent.
     *
     * @param reservaId identificador intern de la reserva
     * @return llista de fotos associades a la reserva
     */
    List<FotoLliurament> findByReservaIdOrderByDataCreacioAsc(Long reservaId);
}
