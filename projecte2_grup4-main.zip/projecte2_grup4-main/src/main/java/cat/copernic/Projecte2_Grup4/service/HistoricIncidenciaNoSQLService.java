package cat.copernic.Projecte2_Grup4.service;

import cat.copernic.Projecte2_Grup4.model.HistoricIncidenciaNoSQL;
import cat.copernic.Projecte2_Grup4.model.Incidencia;
import cat.copernic.Projecte2_Grup4.model.enums.AccioIncidenciaNoSQL;
import cat.copernic.Projecte2_Grup4.repository.HistoricIncidenciaNoSQLRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Servei encarregat de gestionar l'històric d'incidències en una base de dades
 * NoSQL.
 *
 * <p>
 * La seva funció principal és enregistrar canvis d'estat i modificacions d'una
 * {@link Incidencia} com a entrades d'històric
 * ({@link HistoricIncidenciaNoSQL}), i oferir consultes i informes basats en
 * aquests registres.</p>
 *
 * <p>
 * Aquest històric permet:
 * <ul>
 * <li>Traçabilitat d'accions (creació, modificació, desactivació, reactivació,
 * finalització, eliminació).</li>
 * <li>Obtenció de l'evolució temporal d'una incidència.</li>
 * <li>Càlcul de temps acumulat actiu per incidència (hores de duració).</li>
 * <li>Generació d'informes agregats per matrícula o globalment.</li>
 * </ul>
 * </p>
 */
@Service
public class HistoricIncidenciaNoSQLService {

    /**
     * Repositori d'accés a dades per a l'històric d'incidències en NoSQL.
     */
    private final HistoricIncidenciaNoSQLRepository historicRepo;

    /**
     * Constructor amb injecció del repositori NoSQL de l'històric.
     *
     * @param historicRepo repositori per persistir i consultar
     * {@link HistoricIncidenciaNoSQL}
     */
    public HistoricIncidenciaNoSQLService(HistoricIncidenciaNoSQLRepository historicRepo) {
        this.historicRepo = historicRepo;
    }

    /**
     * Enregistra un canvi a l'històric associat a una incidència.
     *
     * <p>
     * Construeix un {@link HistoricIncidenciaNoSQL} amb les dades rellevants de
     * la incidència i l'acció realitzada. Si l'acció és
     * {@link AccioIncidenciaNoSQL#FINALITZA}, també s'informa la data de
     * finalització com el moment actual.</p>
     *
     * <p>
     * Per seguretat, si la incidència és nul·la o no té identificador, el
     * mètode no fa cap operació.</p>
     *
     * @param incidencia incidència sobre la qual s'enregistra el canvi
     * @param accio tipus d'acció que es vol enregistrar
     * @param userResponsable usuari responsable de l'acció
     * @param comentari comentari descriptiu del canvi
     */
    public void enregistrarCanvi(Incidencia incidencia, AccioIncidenciaNoSQL accio, String userResponsable, String comentari) {
        if (incidencia == null) {
            return;
        }

        String idInc = incidencia.getIdIncidence() != null ? String.valueOf(incidencia.getIdIncidence()) : null;
        if (idInc == null) {
            return;
        }

        LocalDateTime dataInici = incidencia.getDataCreacio();
        LocalDateTime dataFi = accio == AccioIncidenciaNoSQL.FINALITZA ? LocalDateTime.now() : null;
        String matricula = incidencia.getVehicle() != null ? incidencia.getVehicle().getMatricule() : null;
        String titol = incidencia.getTitle();
        String descripcio = incidencia.getDescription();
        BigDecimal cost = incidencia.getEstimatedCost();

        HistoricIncidenciaNoSQL h = new HistoricIncidenciaNoSQL(
                idInc,
                accio,
                dataInici,
                dataFi,
                matricula,
                titol,
                descripcio,
                cost,
                userResponsable,
                comentari
        );

        historicRepo.save(h);
    }

    /**
     * Obté l'històric complet d'una incidència concreta, ordenat
     * cronològicament (ascendent).
     *
     * <p>
     * Si l'identificador és nul o buit, retorna una llista buida.</p>
     *
     * @param idIncidencia identificador de la incidència
     * @return llista de registres d'històric ordenats per data de canvi
     * (ascendent)
     */
    public List<HistoricIncidenciaNoSQL> obtenirHistoricPerIncidencia(String idIncidencia) {
        if (idIncidencia == null || idIncidencia.trim().isEmpty()) {
            return new ArrayList<>();
        }
        return historicRepo.findAllByIdIncidenciaOrderByDataCanviAsc(idIncidencia.trim());
    }

    /**
     * Alias de {@link #obtenirHistoricPerIncidencia(String)} per llistar
     * l'històric d'una incidència.
     *
     * @param idIncidencia identificador de la incidència
     * @return llista de registres d'històric per la incidència indicada
     */
    public List<HistoricIncidenciaNoSQL> llistarHistoricPerIncidencia(String idIncidencia) {
        return obtenirHistoricPerIncidencia(idIncidencia);
    }

    /**
     * Genera un informe agregat a partir dels registres d'històric.
     *
     * <p>
     * Si es proporciona una matrícula, l'informe es restringeix als registres
     * d'aquell vehicle. Si la matrícula és nul·la o buida, es genera un informe
     * global amb totes les incidències.</p>
     *
     * <p>
     * Per a cada incidència, es calcula:
     * <ul>
     * <li>L'últim estat/acció (a partir del registre més recent).</li>
     * <li>El cost estimat (del darrer registre).</li>
     * <li>Les hores acumulades de duració activa (segons el flux d'accions
     * enregistrades).</li>
     * </ul>
     * </p>
     *
     * @param matricula matrícula del vehicle per filtrar l'informe (opcional)
     * @return resultat de l'informe amb ítems i totals agregats
     */
    public InformeResult generarInforme(String matricula) {
        List<HistoricIncidenciaNoSQL> logs = (matricula == null || matricula.trim().isEmpty())
                ? historicRepo.findAllByOrderByDataCanviDesc()
                : historicRepo.findAllByMatriculaOrderByDataCanviDesc(matricula.trim());

        Map<String, List<HistoricIncidenciaNoSQL>> perIncidencia = logs.stream()
                .filter(h -> h != null && h.getIdIncidencia() != null)
                .collect(Collectors.groupingBy(HistoricIncidenciaNoSQL::getIdIncidencia));

        List<InformeItem> items = new ArrayList<>();
        BigDecimal costTotal = BigDecimal.ZERO;

        for (Map.Entry<String, List<HistoricIncidenciaNoSQL>> e : perIncidencia.entrySet()) {
            List<HistoricIncidenciaNoSQL> hist = e.getValue();
            if (hist == null || hist.isEmpty()) {
                continue;
            }

            HistoricIncidenciaNoSQL ultim = hist.stream()
                    .max(Comparator.comparing(HistoricIncidenciaNoSQL::getDataCanvi,
                            Comparator.nullsLast(Comparator.naturalOrder())))
                    .orElse(null);

            if (ultim == null) {
                continue;
            }

            double hores = calcularHoresAcumulades(hist);

            BigDecimal cost = Optional.ofNullable(ultim.getCost()).orElse(BigDecimal.ZERO);
            costTotal = costTotal.add(cost);

            InformeItem it = new InformeItem();
            it.setIdIncidencia(ultim.getIdIncidencia());
            it.setData(ultim.getDataCanvi());
            it.setMatricula(ultim.getMatricula());
            it.setTitol(ultim.getTitol());
            it.setDescripcio(ultim.getDescripcio());
            it.setCost(ultim.getCost());
            it.setHoresDuracio(hores);
            it.setAccio(ultim.getAccio());
            it.setUserResponsable(ultim.getUserResponsable());
            items.add(it);
        }

        items.sort(Comparator.comparing(InformeItem::getData, Comparator.nullsLast(Comparator.naturalOrder())).reversed());

        InformeResult res = new InformeResult();
        res.setItems(items);
        res.setTotalIncidencies(items.size());
        res.setCostTotal(costTotal);
        return res;
    }

    /**
     * Calcula les hores acumulades en què una incidència ha estat activa a
     * partir del seu històric.
     *
     * <p>
     * El càlcul es basa en la seqüència temporal de canvis:
     * <ul>
     * <li>Quan hi ha un tancament (desactivació/finalització/eliminació),
     * s'atura el comptador.</li>
     * <li>Quan hi ha una reactivació (o una modificació amb comentari que
     * indica reactivació), es reprèn.</li>
     * <li>Si queda activa al final de la seqüència, es computa fins al moment
     * actual.</li>
     * </ul>
     * </p>
     *
     * @param hist llista de registres d'històric d'una incidència
     * @return hores totals (en format decimal) que la incidència ha estat
     * activa
     */
    private double calcularHoresAcumulades(List<HistoricIncidenciaNoSQL> hist) {
        List<HistoricIncidenciaNoSQL> ordenats = hist.stream()
                .filter(h -> h != null && h.getDataCanvi() != null)
                .sorted(Comparator.comparing(HistoricIncidenciaNoSQL::getDataCanvi))
                .collect(Collectors.toList());

        if (ordenats.isEmpty()) {
            return 0;
        }

        double totalSeconds = 0;

        HistoricIncidenciaNoSQL first = ordenats.get(0);
        boolean actiu = true;
        LocalDateTime inici = first.getDataInici() != null ? first.getDataInici() : first.getDataCanvi();

        if (esTancament(first)) {
            actiu = false;
            inici = null;
        }

        if (esReactivacio(first)) {
            actiu = true;
            inici = first.getDataCanvi();
        }

        for (HistoricIncidenciaNoSQL h : ordenats) {
            LocalDateTime t = h.getDataCanvi();

            if (esReactivacio(h)) {
                if (!actiu) {
                    actiu = true;
                    inici = t;
                }
                continue;
            }

            if (h.getAccio() == AccioIncidenciaNoSQL.CREA) {
                if (!actiu) {
                    actiu = true;
                    inici = h.getDataInici() != null ? h.getDataInici() : t;
                }
                continue;
            }

            if (esTancament(h)) {
                if (actiu && inici != null && t != null) {
                    totalSeconds += Math.max(0, Duration.between(inici, t).getSeconds());
                }
                actiu = false;
                inici = null;
            }
        }

        if (actiu && inici != null) {
            totalSeconds += Math.max(0, Duration.between(inici, LocalDateTime.now()).getSeconds());
        }

        return totalSeconds / 3600;
    }

    /**
     * Indica si un registre d'històric representa una acció de tancament de la
     * incidència.
     *
     * @param h registre d'històric
     * @return {@code true} si l'acció és DESACTIVA, FINALITZA o ELIMINA;
     * altrament {@code false}
     */
    private boolean esTancament(HistoricIncidenciaNoSQL h) {
        if (h == null || h.getAccio() == null) {
            return false;
        }
        return h.getAccio() == AccioIncidenciaNoSQL.DESACTIVA
                || h.getAccio() == AccioIncidenciaNoSQL.FINALITZA
                || h.getAccio() == AccioIncidenciaNoSQL.ELIMINA;
    }

    /**
     * Indica si un registre d'històric representa una reactivació de la
     * incidència.
     *
     * <p>
     * Es considera reactivació si:
     * <ul>
     * <li>L'acció és {@link AccioIncidenciaNoSQL#REACTIVA}, o bé</li>
     * <li>L'acció és {@link AccioIncidenciaNoSQL#MODIFICA} i el comentari
     * suggereix reactivació (conté fragments com "reactiv" o "activ").</li>
     * </ul>
     * </p>
     *
     * @param h registre d'històric
     * @return {@code true} si es detecta una reactivació; altrament
     * {@code false}
     */
    private boolean esReactivacio(HistoricIncidenciaNoSQL h) {
        if (h == null) {
            return false;
        }
        if (h.getAccio() == AccioIncidenciaNoSQL.REACTIVA) {
            return true;
        }
        if (h.getAccio() != AccioIncidenciaNoSQL.MODIFICA) {
            return false;
        }
        String c = h.getComentari();
        if (c == null) {
            return false;
        }
        String lc = c.trim().toLowerCase();
        return lc.contains("reactiv") || lc.contains("activ");
    }

    /**
     * Obté el conjunt de matrícules que apareixen a l'històric.
     *
     * <p>
     * Retorna matrícules no nul·les, no buides, normalitzades (trim), sense
     * duplicats i ordenades.</p>
     *
     * @return llista ordenada de matrícules disponibles a l'històric
     */
    public List<String> obtenirMatriculesDisponibles() {
        return historicRepo.findAll().stream()
                .map(HistoricIncidenciaNoSQL::getMatricula)
                .filter(m -> m != null && !m.trim().isEmpty())
                .map(String::trim)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }

    /**
     * Resultat d'un informe d'històric, amb ítems detallats i totals agregats.
     */
    public static class InformeResult {

        /**
         * Ítems detallats (un per incidència).
         */
        private List<InformeItem> items;

        /**
         * Nombre total d'incidències incloses a l'informe.
         */
        private int totalIncidencies;

        /**
         * Suma del cost (normalment estimat) de les incidències incloses.
         */
        private BigDecimal costTotal;

        /**
         * Retorna la llista d'ítems de l'informe.
         *
         * @return ítems de l'informe
         */
        public List<InformeItem> getItems() {
            return items;
        }

        /**
         * Estableix la llista d'ítems de l'informe.
         *
         * @param items ítems de l'informe
         */
        public void setItems(List<InformeItem> items) {
            this.items = items;
        }

        /**
         * Retorna el nombre total d'incidències.
         *
         * @return total d'incidències
         */
        public int getTotalIncidencies() {
            return totalIncidencies;
        }

        /**
         * Estableix el nombre total d'incidències.
         *
         * @param totalIncidencies total d'incidències
         */
        public void setTotalIncidencies(int totalIncidencies) {
            this.totalIncidencies = totalIncidencies;
        }

        /**
         * Retorna el cost total agregat.
         *
         * @return cost total
         */
        public BigDecimal getCostTotal() {
            return costTotal;
        }

        /**
         * Estableix el cost total agregat.
         *
         * @param costTotal cost total
         */
        public void setCostTotal(BigDecimal costTotal) {
            this.costTotal = costTotal;
        }
    }

    /**
     * Ítem d'informe que representa l'últim estat conegut d'una incidència i
     * les seves dades agregades.
     */
    public static class InformeItem {

        /**
         * Identificador de la incidència.
         */
        private String idIncidencia;

        /**
         * Data del registre d'històric emprat com a referència (normalment el
         * més recent).
         */
        private LocalDateTime data;

        /**
         * Matrícula del vehicle associat.
         */
        private String matricula;

        /**
         * Títol de la incidència.
         */
        private String titol;

        /**
         * Descripció de la incidència.
         */
        private String descripcio;

        /**
         * Cost associat (habitualment estimat).
         */
        private BigDecimal cost;

        /**
         * Hores totals de duració acumulada en estat actiu.
         */
        private double horesDuracio;

        /**
         * Darrera acció registrada a l'històric.
         */
        private AccioIncidenciaNoSQL accio;

        /**
         * Usuari responsable de l'acció registrada.
         */
        private String userResponsable;

        /**
         * Retorna l'identificador de la incidència.
         *
         * @return id de la incidència
         */
        public String getIdIncidencia() {
            return idIncidencia;
        }

        /**
         * Estableix l'identificador de la incidència.
         *
         * @param idIncidencia id de la incidència
         */
        public void setIdIncidencia(String idIncidencia) {
            this.idIncidencia = idIncidencia;
        }

        /**
         * Retorna la data del registre de referència.
         *
         * @return data del registre
         */
        public LocalDateTime getData() {
            return data;
        }

        /**
         * Estableix la data del registre de referència.
         *
         * @param data data del registre
         */
        public void setData(LocalDateTime data) {
            this.data = data;
        }

        /**
         * Retorna la matrícula del vehicle.
         *
         * @return matrícula
         */
        public String getMatricula() {
            return matricula;
        }

        /**
         * Estableix la matrícula del vehicle.
         *
         * @param matricula matrícula
         */
        public void setMatricula(String matricula) {
            this.matricula = matricula;
        }

        /**
         * Retorna el títol de la incidència.
         *
         * @return títol
         */
        public String getTitol() {
            return titol;
        }

        /**
         * Estableix el títol de la incidència.
         *
         * @param titol títol
         */
        public void setTitol(String titol) {
            this.titol = titol;
        }

        /**
         * Retorna la descripció de la incidència.
         *
         * @return descripció
         */
        public String getDescripcio() {
            return descripcio;
        }

        /**
         * Estableix la descripció de la incidència.
         *
         * @param descripcio descripció
         */
        public void setDescripcio(String descripcio) {
            this.descripcio = descripcio;
        }

        /**
         * Retorna el cost associat.
         *
         * @return cost
         */
        public BigDecimal getCost() {
            return cost;
        }

        /**
         * Estableix el cost associat.
         *
         * @param cost cost
         */
        public void setCost(BigDecimal cost) {
            this.cost = cost;
        }

        /**
         * Retorna les hores de duració acumulada.
         *
         * @return hores de duració
         */
        public double getHoresDuracio() {
            return horesDuracio;
        }

        /**
         * Estableix les hores de duració acumulada.
         *
         * @param horesDuracio hores de duració
         */
        public void setHoresDuracio(double horesDuracio) {
            this.horesDuracio = horesDuracio;
        }

        /**
         * Retorna la darrera acció registrada.
         *
         * @return acció
         */
        public AccioIncidenciaNoSQL getAccio() {
            return accio;
        }

        /**
         * Estableix la darrera acció registrada.
         *
         * @param accio acció
         */
        public void setAccio(AccioIncidenciaNoSQL accio) {
            this.accio = accio;
        }

        /**
         * Retorna l'usuari responsable.
         *
         * @return usuari responsable
         */
        public String getUserResponsable() {
            return userResponsable;
        }

        /**
         * Estableix l'usuari responsable.
         *
         * @param userResponsable usuari responsable
         */
        public void setUserResponsable(String userResponsable) {
            this.userResponsable = userResponsable;
        }
    }
}
