package cat.copernic.Projecte2_Grup4.model.enums;

/**
 * Enumeració d'accions possibles registrades a l'històric d'incidències
 * (NoSQL).
 *
 * <p>
 * Defineix les operacions que es poden auditar sobre una incidència, com ara la
 * creació, modificació, eliminació, desactivació, finalització o
 * reactivació.</p>
 */
public enum AccioIncidenciaNoSQL {
    CREA,
    MODIFICA,
    ELIMINA,
    DESACTIVA,
    FINALITZA,
    REACTIVA
}
