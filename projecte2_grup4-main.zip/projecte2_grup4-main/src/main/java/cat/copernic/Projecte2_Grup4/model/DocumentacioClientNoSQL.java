package cat.copernic.Projecte2_Grup4.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "documentacio_client")
/**
 * Document NoSQL que emmagatzema la documentació d'un client.
 *
 * <p>
 * La col·lecció {@code documentacio_client} guarda fitxers binaris associats a
 * un DNI concret. El DNI actua com a identificador del document, permetent
 * recuperar la documentació de manera directa.</p>
 *
 * <p>
 * Els camps binaris poden contenir imatges o documents (per exemple PDF)
 * corresponents a:</p>
 * <ul>
 * <li>DNI</li>
 * <li>Passaport</li>
 * <li>Carnet de conduir</li>
 * </ul>
 */
public class DocumentacioClientNoSQL {

    @Id
    private String dni;  // DNI del client com a ID

    private byte[] documentDNI;        // Imatge o PDF del DNI
    private byte[] documentPassaport;  // Imatge o PDF del passaport
    private byte[] carnetConduir;      // Imatge o PDF de la llicència de conduir

    // ======================== CONSTRUCTORS ===================================
    /**
     * Constructor per defecte.
     */
    public DocumentacioClientNoSQL() {
    }

    /**
     * Constructor complet.
     *
     * @param dni DNI del client (identificador del document)
     * @param documentDNI contingut binari del DNI
     * @param documentPassaport contingut binari del passaport
     * @param carnetConduir contingut binari del carnet de conduir
     */
    public DocumentacioClientNoSQL(String dni, byte[] documentDNI, byte[] documentPassaport, byte[] carnetConduir) {
        this.dni = dni;
        this.documentDNI = documentDNI;
        this.documentPassaport = documentPassaport;
        this.carnetConduir = carnetConduir;
    }

    // ========================== GETTERS I SETTERS =================================
    /**
     * Retorna el DNI del client associat al document.
     *
     * @return DNI del client
     */
    public String getDni() {
        return dni;
    }

    /**
     * Assigna el DNI del client associat al document.
     *
     * @param dni DNI del client
     */
    public void setDni(String dni) {
        this.dni = dni;
    }

    /**
     * Retorna el contingut binari del document de DNI.
     *
     * @return contingut del DNI (pot ser {@code null})
     */
    public byte[] getDocumentDNI() {
        return documentDNI;
    }

    /**
     * Assigna el contingut binari del document de DNI.
     *
     * @param documentDNI contingut del DNI
     */
    public void setDocumentDNI(byte[] documentDNI) {
        this.documentDNI = documentDNI;
    }

    /**
     * Retorna el contingut binari del document de passaport.
     *
     * @return contingut del passaport (pot ser {@code null})
     */
    public byte[] getDocumentPassaport() {
        return documentPassaport;
    }

    /**
     * Assigna el contingut binari del document de passaport.
     *
     * @param documentPassaport contingut del passaport
     */
    public void setDocumentPassaport(byte[] documentPassaport) {
        this.documentPassaport = documentPassaport;
    }

    /**
     * Retorna el contingut binari del carnet de conduir.
     *
     * @return contingut del carnet de conduir (pot ser {@code null})
     */
    public byte[] getCarnetConduir() {
        return carnetConduir;
    }

    /**
     * Assigna el contingut binari del carnet de conduir.
     *
     * @param carnetConduir contingut del carnet de conduir
     */
    public void setCarnetConduir(byte[] carnetConduir) {
        this.carnetConduir = carnetConduir;
    }
}
