package cat.copernic.Projecte2_Grup4.service;

import cat.copernic.Projecte2_Grup4.model.DocumentacioIncidenciaNoSQL;
import cat.copernic.Projecte2_Grup4.repository.DocumentacioIncidenciaNoSQLRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

@Service
/**
 * Servei per gestionar la documentació associada a una incidència emmagatzemada
 * a MongoDB.
 *
 * <p>
 * Centralitza la lògica de:</p>
 * <ul>
 * <li>Creació del document {@link DocumentacioIncidenciaNoSQL} si no
 * existeix.</li>
 * <li>Pujada i validació de fitxers (fotos de dany, fotos de reparació i
 * PDFs).</li>
 * <li>Control de límits de fitxers per pujada.</li>
 * <li>Detecció de fitxers duplicats mitjançant el nom del fitxer
 * (normalitzat).</li>
 * <li>Eliminació i substitució d'elements de documentació existents.</li>
 * </ul>
 *
 * <p>
 * Els fitxers es guarden en format binari dins del document MongoDB, juntament
 * amb el nom i el content-type per poder-los servir posteriorment amb el tipus
 * correcte.</p>
 */
public class DocumentacioIncidenciaNoSQLService {

    private final DocumentacioIncidenciaNoSQLRepository repo;

    /**
     * Constructor amb injecció del repositori MongoDB.
     *
     * @param repo repositori de {@link DocumentacioIncidenciaNoSQL}
     */
    public DocumentacioIncidenciaNoSQLService(DocumentacioIncidenciaNoSQLRepository repo) {
        this.repo = repo;
    }

    /**
     * Obté el document de documentació per l'identificador de la incidència.
     *
     * @param idIncidencia identificador de la incidència (clau del document
     * MongoDB)
     * @return document de documentació o {@code null} si l'id és buit o no
     * existeix
     */
    public DocumentacioIncidenciaNoSQL obtenirPerIdIncidencia(String idIncidencia) {
        if (idIncidencia == null || idIncidencia.trim().isEmpty()) {
            return null;
        }
        return repo.findById(idIncidencia.trim()).orElse(null);
    }

    /**
     * Crea el document de documentació si no existeix i el retorna.
     *
     * @param idIncidencia identificador de la incidència
     * @return document existent o un de nou guardat a la base de dades
     * @throws IllegalArgumentException si l'identificador no és vàlid
     */
    public DocumentacioIncidenciaNoSQL crearSiNoExisteix(String idIncidencia) {
        String id = (idIncidencia == null) ? "" : idIncidencia.trim();
        if (id.isEmpty()) {
            throw new IllegalArgumentException("Cal seleccionar una incidència");
        }

        DocumentacioIncidenciaNoSQL d = obtenirPerIdIncidencia(id);
        if (d != null) {
            return d;
        }

        DocumentacioIncidenciaNoSQL nou = new DocumentacioIncidenciaNoSQL();
        nou.setId(id);
        return repo.save(nou);
    }

    /**
     * Elimina el document de documentació associat a una incidència.
     *
     * @param idIncidencia identificador de la incidència
     */
    public void eliminar(String idIncidencia) {
        if (idIncidencia == null || idIncidencia.trim().isEmpty()) {
            return;
        }
        repo.deleteById(idIncidencia.trim());
    }

    // ================= RESULTAT (compatible amb el Controller) =================
    /**
     * Resultat de l'operació d'afegir fitxers a una documentació d'incidència.
     *
     * <p>
     * Inclou el document guardat i llistes amb:</p>
     * <ul>
     * <li>Fitxers ignorats (p. ex. sense nom).</li>
     * <li>Fitxers detectats com a duplicats (pel nom).</li>
     * </ul>
     */
    public static class AfegirFitxersResult {

        private final DocumentacioIncidenciaNoSQL doc;
        private final List<String> ignorats;
        private final List<String> duplicats;

        /**
         * Constructor del resultat.
         *
         * @param doc document guardat/actualitzat
         * @param ignorats llista de noms ignorats
         * @param duplicats llista de noms duplicats
         */
        public AfegirFitxersResult(DocumentacioIncidenciaNoSQL doc, List<String> ignorats, List<String> duplicats) {
            this.doc = doc;
            this.ignorats = ignorats;
            this.duplicats = duplicats;
        }

        /**
         * Retorna el document de documentació resultant.
         *
         * @return document
         */
        public DocumentacioIncidenciaNoSQL getDoc() {
            return doc;
        }

        /**
         * Retorna els fitxers ignorats durant la pujada.
         *
         * @return llista de noms ignorats
         */
        public List<String> getIgnorats() {
            return ignorats;
        }

        /**
         * Retorna els fitxers detectats com a duplicats.
         *
         * @return llista de noms duplicats
         */
        public List<String> getDuplicats() {
            return duplicats;
        }

        /**
         * Indica si el resultat conté avisos (ignorats o duplicats).
         *
         * @return {@code true} si hi ha avisos; {@code false} en cas contrari
         */
        public boolean teAvisos() {
            return (ignorats != null && !ignorats.isEmpty()) || (duplicats != null && !duplicats.isEmpty());
        }
    }

    // ================= HELPERS =================
    /**
     * Normalitza un nom de fitxer per facilitar la detecció de duplicats.
     *
     * @param nom nom original
     * @return nom normalitzat (trim + minúscules) o cadena buida si és
     * {@code null}
     */
    private static String normNom(String nom) {
        return (nom == null) ? "" : nom.trim().toLowerCase(Locale.ROOT);
    }

    /**
     * Compta quants fitxers no buits hi ha a la llista.
     *
     * @param fitxers llista de fitxers
     * @return nombre de fitxers no buits
     */
    private static int comptarNoBuids(List<MultipartFile> fitxers) {
        if (fitxers == null) {
            return 0;
        }
        int c = 0;
        for (MultipartFile f : fitxers) {
            if (f != null && !f.isEmpty()) {
                c++;
            }
        }
        return c;
    }

    /**
     * Valida el nombre màxim de fitxers per pujada per a una categoria
     * concreta.
     *
     * @param etiqueta etiqueta descriptiva (p. ex. "Fotos dany")
     * @param max màxim permès
     * @param fitxers llista de fitxers rebuts
     * @throws IllegalArgumentException si se supera el màxim permès
     */
    private static void validarMaxPerPujada(String etiqueta, int max, List<MultipartFile> fitxers) {
        int n = comptarNoBuids(fitxers);
        if (n > max) {
            throw new IllegalArgumentException(
                    "Només pots pujar fins a " + max + " fitxers a la vegada (" + etiqueta + ")."
            );
        }
    }

    /**
     * Indica si hi ha algun fitxer realment seleccionat per pujar.
     *
     * @param fotosDany llista de fotos de dany
     * @param comunicatAccident fitxer del comunicat d'accident
     * @param informeTaller fitxer de l'informe de taller
     * @param fotosReparacio llista de fotos de reparació
     * @return {@code true} si hi ha algun fitxer nou; {@code false} en cas
     * contrari
     */
    private static boolean hiHaFitxersNous(List<MultipartFile> fotosDany,
            MultipartFile comunicatAccident,
            MultipartFile informeTaller,
            List<MultipartFile> fotosReparacio) {
        boolean hiHaFotosDany = fotosDany != null && fotosDany.stream().anyMatch(f -> f != null && !f.isEmpty());
        boolean hiHaFotosReparacio = fotosReparacio != null && fotosReparacio.stream().anyMatch(f -> f != null && !f.isEmpty());
        boolean hiHaCom = comunicatAccident != null && !comunicatAccident.isEmpty();
        boolean hiHaInf = informeTaller != null && !informeTaller.isEmpty();
        return hiHaFotosDany || hiHaFotosReparacio || hiHaCom || hiHaInf;
    }

    /**
     * Afegeix un nom normalitzat a un conjunt si és present i no és buit.
     *
     * @param s conjunt on afegir
     * @param nom nom a afegir
     */
    private static void addIfPresent(Set<String> s, String nom) {
        String nn = normNom(nom);
        if (!nn.isEmpty()) {
            s.add(nn);
        }
    }

    /**
     * Obté el conjunt de noms de fitxer ja existents dins del document (fotos i
     * PDFs).
     *
     * @param doc document de documentació
     * @return conjunt de noms normalitzats
     */
    private static Set<String> nomsExistentsGlobals(DocumentacioIncidenciaNoSQL doc) {
        Set<String> s = new HashSet<>();
        if (doc == null) {
            return s;
        }

        if (doc.getFotosDanyNoms() != null) {
            doc.getFotosDanyNoms().forEach(n -> addIfPresent(s, n));
        }
        if (doc.getFotosReparacioNoms() != null) {
            doc.getFotosReparacioNoms().forEach(n -> addIfPresent(s, n));
        }

        addIfPresent(s, doc.getComunicatAccidentNom());
        addIfPresent(s, doc.getInformeTallerNom());

        return s;
    }

    // ================= MÈTODE PRINCIPAL: GUARDAR DOCUMENTACIÓ =================
    /**
     * Afegeix fitxers de documentació a una incidència (fotos i/o PDFs).
     *
     * <p>
     * Aplica les validacions següents:</p>
     * <ul>
     * <li>La incidència ha d'estar informada.</li>
     * <li>Com a mínim s'ha d'haver seleccionat un fitxer.</li>
     * <li>Límit de fitxers per pujada: 6 per fotos de dany i 6 per fotos de
     * reparació.</li>
     * <li>Detecció de duplicats pel nom del fitxer (normalitzat), tant respecte
     * el document existent com dins la mateixa pujada.</li>
     * </ul>
     *
     * @param idIncidencia identificador de la incidència
     * @param fotosDany llista de fotos del dany
     * @param comunicatAccident comunicat d'accident (PDF o imatge)
     * @param informeTaller informe del taller (PDF)
     * @param fotosReparacio llista de fotos de reparació
     * @return resultat amb el document guardat i avisos de fitxers
     * ignorats/duplicats
     * @throws IOException si hi ha errors llegint el contingut dels fitxers
     * @throws IllegalArgumentException si falla alguna validació funcional
     */
    public AfegirFitxersResult afegirFitxers(
            String idIncidencia,
            List<MultipartFile> fotosDany,
            MultipartFile comunicatAccident,
            MultipartFile informeTaller,
            List<MultipartFile> fotosReparacio) throws IOException {

        String id = (idIncidencia == null) ? "" : idIncidencia.trim();
        if (id.isEmpty()) {
            throw new IllegalArgumentException("Cal seleccionar una incidència");
        }

        if (!hiHaFitxersNous(fotosDany, comunicatAccident, informeTaller, fotosReparacio)) {
            throw new IllegalArgumentException("No s'ha seleccionat cap fitxer per pujar.");
        }

        // límits
        validarMaxPerPujada("Fotos dany", 6, fotosDany);
        validarMaxPerPujada("Fotos reparació", 6, fotosReparacio);

        DocumentacioIncidenciaNoSQL doc = crearSiNoExisteix(id);

        List<String> ignorats = new ArrayList<>();
        List<String> duplicats = new ArrayList<>();

        // Existents globals (fotos + PDFs, creuat)
        Set<String> existents = nomsExistentsGlobals(doc);

        // Noms ja seleccionats en aquesta pujada (per evitar duplicats entre camps en la mateixa pujada)
        Set<String> vistos = new HashSet<>();

        // ---- Fotos dany ----
        if (fotosDany != null && !fotosDany.isEmpty()) {
            List<byte[]> fotos = (doc.getFotosDany() != null) ? doc.getFotosDany() : new ArrayList<>();
            List<String> noms = (doc.getFotosDanyNoms() != null) ? doc.getFotosDanyNoms() : new ArrayList<>();
            List<String> types = (doc.getFotosDanyContentTypes() != null) ? doc.getFotosDanyContentTypes() : new ArrayList<>();

            for (MultipartFile f : fotosDany) {
                if (f == null || f.isEmpty()) {
                    continue;
                }

                String nom = f.getOriginalFilename();
                String nn = normNom(nom);
                if (nn.isEmpty()) {
                    ignorats.add("(sense nom)");
                    continue;
                }

                if (existents.contains(nn) || vistos.contains(nn)) {
                    duplicats.add(nom);
                    continue;
                }

                vistos.add(nn);
                existents.add(nn);

                fotos.add(f.getBytes());
                noms.add(nom);
                types.add(f.getContentType() != null ? f.getContentType() : "application/octet-stream");
            }

            doc.setFotosDany(fotos);
            doc.setFotosDanyNoms(noms);
            doc.setFotosDanyContentTypes(types);
        }

        // ---- Fotos reparació ----
        if (fotosReparacio != null && !fotosReparacio.isEmpty()) {
            List<byte[]> fotos = (doc.getFotosReparacio() != null) ? doc.getFotosReparacio() : new ArrayList<>();
            List<String> noms = (doc.getFotosReparacioNoms() != null) ? doc.getFotosReparacioNoms() : new ArrayList<>();
            List<String> types = (doc.getFotosReparacioContentTypes() != null) ? doc.getFotosReparacioContentTypes() : new ArrayList<>();

            for (MultipartFile f : fotosReparacio) {
                if (f == null || f.isEmpty()) {
                    continue;
                }

                String nom = f.getOriginalFilename();
                String nn = normNom(nom);
                if (nn.isEmpty()) {
                    ignorats.add("(sense nom)");
                    continue;
                }

                if (existents.contains(nn) || vistos.contains(nn)) {
                    duplicats.add(nom);
                    continue;
                }

                vistos.add(nn);
                existents.add(nn);

                fotos.add(f.getBytes());
                noms.add(nom);
                types.add(f.getContentType() != null ? f.getContentType() : "application/octet-stream");
            }

            doc.setFotosReparacio(fotos);
            doc.setFotosReparacioNoms(noms);
            doc.setFotosReparacioContentTypes(types);
        }

        // ---- Comunicat PDF ----
        if (comunicatAccident != null && !comunicatAccident.isEmpty()) {
            String nom = comunicatAccident.getOriginalFilename();
            String nn = normNom(nom);
            if (nn.isEmpty()) {
                ignorats.add("(comunicat sense nom)");
            } else if (existents.contains(nn) || vistos.contains(nn)) {
                duplicats.add(nom);
            } else {
                vistos.add(nn);
                existents.add(nn);
                doc.setComunicatAccident(comunicatAccident.getBytes());
                doc.setComunicatAccidentNom(nom);
                doc.setComunicatAccidentContentType(comunicatAccident.getContentType() != null
                        ? comunicatAccident.getContentType()
                        : "application/pdf");
            }
        }

        // ---- Informe PDF ----
        if (informeTaller != null && !informeTaller.isEmpty()) {
            String nom = informeTaller.getOriginalFilename();
            String nn = normNom(nom);
            if (nn.isEmpty()) {
                ignorats.add("(informe sense nom)");
            } else if (existents.contains(nn) || vistos.contains(nn)) {
                duplicats.add(nom);
            } else {
                vistos.add(nn);
                existents.add(nn);
                doc.setInformeTaller(informeTaller.getBytes());
                doc.setInformeTallerNom(nom);
                doc.setInformeTallerContentType(informeTaller.getContentType() != null
                        ? informeTaller.getContentType()
                        : "application/pdf");
            }
        }

        DocumentacioIncidenciaNoSQL guardat = repo.save(doc);
        return new AfegirFitxersResult(guardat, ignorats, duplicats);
    }

    // ================= CREACIÓ: només fotos dany (màx 4) =================
    /**
     * Afegeix fotos de dany durant la creació d'una incidència, amb un límit
     * més restrictiu.
     *
     * @param idIncidencia identificador de la incidència
     * @param fotosDany llista de fotos de dany (màxim 4)
     * @return resultat amb el document guardat i avisos de fitxers
     * ignorats/duplicats
     * @throws IOException si hi ha errors llegint el contingut dels fitxers
     * @throws IllegalArgumentException si se supera el límit o l'id és invàlid
     */
    public AfegirFitxersResult afegirFotosDanyCreacio(String idIncidencia, List<MultipartFile> fotosDany) throws IOException {
        validarMaxPerPujada("Fotos dany", 4, fotosDany);
        return afegirFitxers(idIncidencia, fotosDany, null, null, null);
    }

    // ================= ELIMINAR =================
    /**
     * Elimina un fitxer o un element de llistes (fotos) segons el tipus
     * indicat.
     *
     * <p>
     * Tipus suportats:</p>
     * <ul>
     * <li>{@code "comunicat"}: elimina el comunicat d'accident.</li>
     * <li>{@code "informe"}: elimina l'informe de taller.</li>
     * <li>{@code "fotosDany"}: elimina una foto de dany per índex.</li>
     * <li>{@code "fotosReparacio"}: elimina una foto de reparació per
     * índex.</li>
     * </ul>
     *
     * @param idIncidencia identificador de la incidència
     * @param tipus tipus de fitxer/camp a modificar
     * @param index índex de la foto (obligatori per als tipus de fotos)
     */
    public void eliminarFitxer(String idIncidencia, String tipus, Integer index) {
        DocumentacioIncidenciaNoSQL doc = repo.findById(idIncidencia).orElse(null);
        if (doc == null) {
            return;
        }

        switch (tipus) {
            case "comunicat" -> {
                doc.setComunicatAccident(null);
                doc.setComunicatAccidentNom(null);
                doc.setComunicatAccidentContentType(null);
            }
            case "informe" -> {
                doc.setInformeTaller(null);
                doc.setInformeTallerNom(null);
                doc.setInformeTallerContentType(null);
            }
            case "fotosDany" -> {
                if (index == null) {
                    return;
                }
                if (doc.getFotosDany() != null && index >= 0 && index < doc.getFotosDany().size()) {
                    doc.getFotosDany().remove((int) index);
                }
                if (doc.getFotosDanyNoms() != null && index >= 0 && index < doc.getFotosDanyNoms().size()) {
                    doc.getFotosDanyNoms().remove((int) index);
                }
                if (doc.getFotosDanyContentTypes() != null && index >= 0 && index < doc.getFotosDanyContentTypes().size()) {
                    doc.getFotosDanyContentTypes().remove((int) index);
                }
            }
            case "fotosReparacio" -> {
                if (index == null) {
                    return;
                }
                if (doc.getFotosReparacio() != null && index >= 0 && index < doc.getFotosReparacio().size()) {
                    doc.getFotosReparacio().remove((int) index);
                }
                if (doc.getFotosReparacioNoms() != null && index >= 0 && index < doc.getFotosReparacioNoms().size()) {
                    doc.getFotosReparacioNoms().remove((int) index);
                }
                if (doc.getFotosReparacioContentTypes() != null && index >= 0 && index < doc.getFotosReparacioContentTypes().size()) {
                    doc.getFotosReparacioContentTypes().remove((int) index);
                }
            }
            default -> {
                return;
            }
        }

        repo.save(doc);
    }

    /**
     * Substitueix un fitxer existent del document per un de nou, controlant
     * duplicats per nom.
     *
     * <p>
     * Permet mantenir el mateix nom quan s'està reemplaçant exactament el
     * mateix element.</p>
     *
     * @param idIncidencia identificador de la incidència
     * @param tipus tipus de fitxer/camp a modificar (comunicat, informe,
     * fotosDany, fotosReparacio)
     * @param index índex de la foto (obligatori per als tipus de fotos)
     * @param fitxer nou fitxer a establir
     * @throws IOException si hi ha errors llegint el contingut del fitxer
     * @throws IllegalArgumentException si el fitxer no té nom o ja existeix un
     * altre fitxer amb el mateix nom
     */
    public void canviarFitxer(String idIncidencia, String tipus, Integer index, MultipartFile fitxer) throws IOException {
        if (fitxer == null || fitxer.isEmpty()) {
            return;
        }

        DocumentacioIncidenciaNoSQL doc = repo.findById(idIncidencia).orElse(null);
        if (doc == null) {
            return;
        }

        String nomNou = fitxer.getOriginalFilename();
        String nnNou = normNom(nomNou);
        if (nnNou.isEmpty()) {
            throw new IllegalArgumentException("El fitxer no té nom.");
        }

        // Existents globals
        Set<String> existents = nomsExistentsGlobals(doc);

        // Permetre mantenir el mateix nom quan estàs reemplaçant aquell mateix element
        String nomActual = null;
        switch (tipus) {
            case "comunicat" ->
                nomActual = doc.getComunicatAccidentNom();
            case "informe" ->
                nomActual = doc.getInformeTallerNom();
            case "fotosDany" -> {
                if (index == null) {
                    return;
                }
                if (doc.getFotosDanyNoms() != null && index >= 0 && index < doc.getFotosDanyNoms().size()) {
                    nomActual = doc.getFotosDanyNoms().get(index);
                }
            }
            case "fotosReparacio" -> {
                if (index == null) {
                    return;
                }
                if (doc.getFotosReparacioNoms() != null && index >= 0 && index < doc.getFotosReparacioNoms().size()) {
                    nomActual = doc.getFotosReparacioNoms().get(index);
                }
            }
            default -> {
                return;
            }
        }
        if (nomActual != null) {
            existents.remove(normNom(nomActual));
        }

        if (existents.contains(nnNou)) {
            throw new IllegalArgumentException("Aquest fitxer ja està pujat: " + nomNou);
        }

        switch (tipus) {
            case "comunicat" -> {
                doc.setComunicatAccident(fitxer.getBytes());
                doc.setComunicatAccidentNom(nomNou);
                doc.setComunicatAccidentContentType(fitxer.getContentType() != null ? fitxer.getContentType() : "application/pdf");
            }
            case "informe" -> {
                doc.setInformeTaller(fitxer.getBytes());
                doc.setInformeTallerNom(nomNou);
                doc.setInformeTallerContentType(fitxer.getContentType() != null ? fitxer.getContentType() : "application/pdf");
            }
            case "fotosDany" -> {
                if (index == null) {
                    return;
                }
                if (doc.getFotosDany() != null && index >= 0 && index < doc.getFotosDany().size()) {
                    doc.getFotosDany().set(index, fitxer.getBytes());
                }
                if (doc.getFotosDanyNoms() != null && index >= 0 && index < doc.getFotosDanyNoms().size()) {
                    doc.getFotosDanyNoms().set(index, nomNou);
                }
                if (doc.getFotosDanyContentTypes() != null && index >= 0 && index < doc.getFotosDanyContentTypes().size()) {
                    doc.getFotosDanyContentTypes().set(index, fitxer.getContentType() != null ? fitxer.getContentType() : "application/octet-stream");
                }
            }
            case "fotosReparacio" -> {
                if (index == null) {
                    return;
                }
                if (doc.getFotosReparacio() != null && index >= 0 && index < doc.getFotosReparacio().size()) {
                    doc.getFotosReparacio().set(index, fitxer.getBytes());
                }
                if (doc.getFotosReparacioNoms() != null && index >= 0 && index < doc.getFotosReparacioNoms().size()) {
                    doc.getFotosReparacioNoms().set(index, nomNou);
                }
                if (doc.getFotosReparacioContentTypes() != null && index >= 0 && index < doc.getFotosReparacioContentTypes().size()) {
                    doc.getFotosReparacioContentTypes().set(index, fitxer.getContentType() != null ? fitxer.getContentType() : "application/octet-stream");
                }
            }
            default -> {
                return;
            }
        }

        repo.save(doc);
    }
}
