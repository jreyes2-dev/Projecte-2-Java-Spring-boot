package cat.copernic.Projecte2_Grup4.service;

import cat.copernic.Projecte2_Grup4.model.Vehicle;
import cat.copernic.Projecte2_Grup4.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import cat.copernic.Projecte2_Grup4.model.enums.EstatReserva;
import cat.copernic.Projecte2_Grup4.model.enums.EstatVehicle;
import cat.copernic.Projecte2_Grup4.repository.ReservaRepository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.springframework.transaction.annotation.Transactional;

/**
 * Servei de negoci per a la gestió de {@link Vehicle}.
 *
 * <p>
 * Proporciona operacions de consulta de vehicles i gestiona
 * l'activació/desactivació aplicant regles de coherència amb les reserves:
 * <ul>
 * <li>Un vehicle no es pot desactivar si té reserves no cancel·lades en curs o
 * futures.</li>
 * <li>Quan es desactiva, s'informa la data de desactivació i opcionalment la
 * data de fi de desactivació.</li>
 * <li>Quan s'activa, el vehicle torna a estat disponible i es poden enregistrar
 * dades opcionals del motiu/import.</li>
 * </ul>
 * </p>
 */
@Service
public class VehicleService {

    /**
     * Repositori d'accés a dades de {@link Vehicle}.
     */
    @Autowired
    private VehicleRepository vehicleRepository;

    /**
     * Repositori d'accés a dades de reserves, utilitzat per validar si hi ha
     * reserves actives o futures.
     */
    @Autowired
    private ReservaRepository reservaRepository;

    /**
     * Retorna tots els vehicles del sistema.
     *
     * @return llista completa de vehicles
     */
    public List<Vehicle> llistarTotsVehicles() {
        return vehicleRepository.findAll();
    }

    /**
     * Obté un vehicle a partir de la seva matrícula.
     *
     * @param matricula matrícula del vehicle
     * @return vehicle trobat o {@code null} si no existeix
     */
    public Vehicle obtenirVehiclePerMatricula(String matricula) {
        return vehicleRepository.findById(matricula).orElse(null);
    }

    /**
     * Desactiva un vehicle sempre que no tingui reserves no cancel·lades en
     * curs o futures.
     *
     * <p>
     * Regla de negoci: si existeixen reserves no cancel·lades a partir d'avui,
     * el vehicle no es pot desactivar fins que aquestes reserves s'hagin
     * anul·lat.</p>
     *
     * <p>
     * Quan es desactiva:
     * <ul>
     * <li>Es canvia l'estat del vehicle a
     * {@link EstatVehicle#No_Disponible}.</li>
     * <li>Es registra la data de desactivació amb el moment actual.</li>
     * <li>Opcionalment, s'informa la data de fi de desactivació.</li>
     * </ul>
     * </p>
     *
     * @param matricula matrícula del vehicle
     * @param dataFiDesactivacioOpcional data opcional de finalització de la
     * desactivació
     * @throws IllegalArgumentException si el vehicle no existeix o si té
     * reserves no cancel·lades
     */
    @Transactional
    public void desactivarVehicle(String matricula, LocalDate dataFiDesactivacioOpcional) {
        Vehicle v = obtenirVehiclePerMatricula(matricula);
        if (v == null) {
            throw new IllegalArgumentException("Vehicle no trobat");
        }

        long reserves = reservaRepository.countReservesNoCanceladesEnCursOFutures(
                matricula,
                LocalDate.now(),
                EstatReserva.CANCELAT
        );

        if (reserves > 0) {
            throw new IllegalArgumentException(
                    "No es pot desactivar el vehicle: hi ha reserves. Abans han de ser anul·lades."
            );
        }

        v.setEstat(EstatVehicle.No_Disponible); // ha d'existir al teu enum
        v.setDataDesactivacio(LocalDateTime.now());
        v.setDataFiDesactivacio(dataFiDesactivacioOpcional);

        vehicleRepository.save(v);
    }

    /**
     * Activa un vehicle, retornant-lo a l'estat disponible i desant informació
     * opcional d'activació.
     *
     * <p>
     * Quan s'activa:
     * <ul>
     * <li>Es canvia l'estat del vehicle a {@link EstatVehicle#Disponible}.</li>
     * <li>Es pot registrar un motiu d'activació (si s'informa i no és
     * buit).</li>
     * <li>Es pot registrar un import associat a l'activació.</li>
     * </ul>
     * </p>
     *
     * @param matricula matrícula del vehicle
     * @param motiuOpcional motiu d'activació (opcional)
     * @param importOpcional import associat a l'activació (opcional)
     * @throws IllegalArgumentException si el vehicle no existeix
     */
    @Transactional
    public void activarVehicle(String matricula, String motiuOpcional, Double importOpcional) {
        Vehicle v = obtenirVehiclePerMatricula(matricula);
        if (v == null) {
            throw new IllegalArgumentException("Vehicle no trobat");
        }

        v.setEstat(EstatVehicle.Disponible); // actiu
        v.setMotiuActivacio((motiuOpcional != null && !motiuOpcional.isBlank()) ? motiuOpcional : null);
        v.setImportActivacio(importOpcional);

        vehicleRepository.save(v);
    }

}
