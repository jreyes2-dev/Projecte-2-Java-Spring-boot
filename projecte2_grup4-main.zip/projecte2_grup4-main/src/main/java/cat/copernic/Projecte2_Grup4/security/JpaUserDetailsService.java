package cat.copernic.Projecte2_Grup4.security;

import cat.copernic.Projecte2_Grup4.config.AgentInactiveAuthenticationException;
import cat.copernic.Projecte2_Grup4.config.ClientPendingAuthenticationException;
import cat.copernic.Projecte2_Grup4.model.Agent;
import cat.copernic.Projecte2_Grup4.model.Client;
import cat.copernic.Projecte2_Grup4.model.User;
import cat.copernic.Projecte2_Grup4.model.enums.Estat;
import cat.copernic.Projecte2_Grup4.model.enums.EstatAgent;
import cat.copernic.Projecte2_Grup4.model.enums.Rol;
import cat.copernic.Projecte2_Grup4.repository.AgentRepository;
import cat.copernic.Projecte2_Grup4.repository.ClientRepository;
import cat.copernic.Projecte2_Grup4.repository.UserRepository;
import java.util.List;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
/**
 * Implementació de {@link UserDetailsService} basada en JPA per a
 * l'autenticació amb Spring Security.
 *
 * <p>
 * Carrega un {@link User} des de la base de dades mitjançant
 * {@link UserRepository} i el transforma en un {@link UserDetails} utilitzable
 * pel mecanisme d'autenticació de Spring Security.</p>
 *
 * <p>
 * El rol s'obté des del camp {@link Rol} de l'usuari. Si no està informat,
 * s'aplica un mecanisme de reserva (fallback) en funció del tipus concret
 * d'usuari ({@link Agent} o {@link Client}).</p>
 */
public class JpaUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;
    private final ClientRepository clientRepository;
    private final AgentRepository agentRepository;

    public JpaUserDetailsService(UserRepository userRepository,
            ClientRepository clientRepository,
            AgentRepository agentRepository) {
        this.userRepository = userRepository;
        this.clientRepository = clientRepository;
        this.agentRepository = agentRepository;
    }

    /**
     * Carrega les credencials d'un usuari a partir del seu nom d'usuari.
     *
     * <p>
     * Construeix un {@link UserDetails} amb:</p>
     * <ul>
     * <li>Nom d'usuari: {@code user.getNomUser()}</li>
     * <li>Contrasenya: {@code user.getContrasenya()}</li>
     * <li>Autoritats: {@code ROLE_&lt;ROL&gt;} segons {@link Rol}</li>
     * </ul>
     *
     * @param username nom d'usuari utilitzat per iniciar sessió
     * @return detalls de seguretat de l'usuari
     * @throws UsernameNotFoundException si no es troba cap usuari amb aquest
     * nom
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        User user = userRepository.findByNomUser(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuari no trobat: " + username));

        Rol rol = user.getRol();
        boolean enabled = true;

        if (rol == Rol.CLIENT) {
            Client client = clientRepository.findByNomUser(username)
                    .orElseThrow(() -> new UsernameNotFoundException("Client no trobat per l'usuari: " + username));

            if (client.getEstat() == Estat.PENDENT) {
                throw new ClientPendingAuthenticationException("Compte pendent");
            }
            enabled = (client.getEstat() == Estat.ACEPTAT);
        }

        if (rol == Rol.AGENT || rol == Rol.ADMIN) {
            Agent agent = agentRepository.findByNomUser(username)
                    .orElseThrow(() -> new UsernameNotFoundException("Agent no trobat per l'usuari: " + username));

            if (agent.getEstatAgent() == EstatAgent.INACTIU) {
                throw new AgentInactiveAuthenticationException("Agent inactiu");
            }

            enabled = (agent.getEstatAgent() == EstatAgent.ACTIU);
        }

        List<SimpleGrantedAuthority> authorities
                = (rol == null) ? List.of() : List.of(new SimpleGrantedAuthority("ROLE_" + rol.name()));

        return org.springframework.security.core.userdetails.User
                .withUsername(user.getNomUser())
                .password(user.getContrasenya())
                .authorities(authorities)
                .disabled(!enabled)
                .build();
    }
}
