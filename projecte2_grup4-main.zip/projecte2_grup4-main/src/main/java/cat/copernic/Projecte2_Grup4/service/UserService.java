/*package cat.copernic.Projecte2_Grup4.service;

import cat.copernic.Projecte2_Grup4.model.Client;
import cat.copernic.Projecte2_Grup4.model.User;
import cat.copernic.Projecte2_Grup4.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }


    public Optional<User> login(String nomUser, String contrasenya) {
        Optional<User> userOpt = userRepository.findByNomUser(nomUser);

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (passwordEncoder.matches(contrasenya, user.getContrasenya())) {
                return userOpt;
            }
        }
        return Optional.empty();
    }

    /* REGISTRO CLIENT 
    public User registerClient(
            String dni,
            String nom,
            String cognom1,
            String cognom2,
            String adreca,
            String nomUser,
            String email,
            String contrasenya,
            String tipusLlicencia,
            String targeta,
            LocalDate caducitatId,
            LocalDate caducitatLlicencia
    ) {

        if (userRepository.existsByNomUser(nomUser)) {
            throw new RuntimeException("El nombre de usuario ya existe");
        }

        if (userRepository.existsByEmail(email)) {
            throw new RuntimeException("El email ya está registrado");
        }

        Client client = new Client(
                0,
                new ArrayList<>(),
                dni,
                nom,
                cognom1,
                cognom2,
                adreca,
                nomUser,
                email,
                passwordEncoder.encode(contrasenya),
                tipusLlicencia,
                targeta,
                caducitatId,
                caducitatLlicencia
        );

        return userRepository.save(client);
    }
}
*/