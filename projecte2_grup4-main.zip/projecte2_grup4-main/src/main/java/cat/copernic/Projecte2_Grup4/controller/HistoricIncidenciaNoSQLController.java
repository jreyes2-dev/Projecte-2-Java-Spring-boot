package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.model.Agent;
import cat.copernic.Projecte2_Grup4.model.HistoricIncidenciaNoSQL;
import cat.copernic.Projecte2_Grup4.model.enums.EstatAgent;
import cat.copernic.Projecte2_Grup4.service.AgentService;
import cat.copernic.Projecte2_Grup4.service.HistoricIncidenciaNoSQLService;
import cat.copernic.Projecte2_Grup4.service.HistoricIncidenciaNoSQLService.InformeItem;
import cat.copernic.Projecte2_Grup4.service.HistoricIncidenciaNoSQLService.InformeResult;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

@Controller
@RequestMapping("/web/incidencies/historic")
/**
 * Controlador web encarregat de la visualització i la consulta de l'històric
 * d'incidències emmagatzemat en un repositori NoSQL.
 *
 * <p>
 * Permet generar un informe per matrícula i, opcionalment, filtrar la
 * informació mostrada segons l'usuari responsable i/o la incidència
 * seleccionada.</p>
 *
 * <p>
 * Quan l'usuari autenticat no és administrador, el controlador restringeix les
 * dades mostrades a aquelles associades al seu propi nom d'usuari.</p>
 */
public class HistoricIncidenciaNoSQLController {

    private final HistoricIncidenciaNoSQLService historicIncidenciaNoSQLService;
    private final AgentService agentService;

    /**
     * Constructor amb injecció de dependències.
     *
     * @param historicIncidenciaNoSQLService servei per generar informes i
     * recuperar l'històric NoSQL
     * @param agentService servei de gestió d'agents (usuaris del sistema amb
     * rol d'agent)
     */
    public HistoricIncidenciaNoSQLController(HistoricIncidenciaNoSQLService historicIncidenciaNoSQLService, AgentService agentService) {
        this.historicIncidenciaNoSQLService = historicIncidenciaNoSQLService;
        this.agentService = agentService;
    }

    /**
     * Llista i mostra l'informe d'històric d'incidències.
     *
     * <p>
     * Funcionalitats principals:</p>
     * <ul>
     * <li>Obtenció d'agents actius per mostrar-los a la vista.</li>
     * <li>Generació d'un informe per matrícula (si s'ha indicat).</li>
     * <li>Filtrat automàtic per usuari si l'usuari autenticat no és
     * administrador.</li>
     * <li>Càlcul del total d'incidències i del cost total acumulat.</li>
     * <li>Selecció d'una incidència (per defecte la primera disponible) per
     * carregar el seu històric detallat.</li>
     * </ul>
     *
     * @param matricula matrícula del vehicle per la qual es vol generar
     * l'informe (opcional)
     * @param usuari nom d'usuari responsable (opcional; si no és admin es força
     * al de l'usuari autenticat)
     * @param idIncidencia identificador de la incidència a seleccionar
     * (opcional)
     * @param model model de Spring per exposar dades a la vista
     * @return nom de la plantilla Thymeleaf per renderitzar la pàgina
     * d'històric
     */
    @GetMapping("/llistar")
    public String llistar(@RequestParam(name = "matricula", required = false, defaultValue = "") String matricula,
            @RequestParam(name = "usuari", required = false, defaultValue = "") String usuari,
            @RequestParam(name = "idIncidencia", required = false, defaultValue = "") String idIncidencia,
            Model model) {

        List<Agent> agentsActius = agentService.llistarTotsAgents().stream()
                .filter(a -> a.getEstatAgent() == EstatAgent.ACTIU)
                .toList();

        String usuariSel = usuari != null ? usuari.trim() : "";
        if (!isAdmin()) {
            usuariSel = currentUsername();
        }

        InformeResult informe = historicIncidenciaNoSQLService.generarInforme(matricula);
        List<InformeItem> items = informe.getItems();

        if (!isAdmin()) {
            final String u = usuariSel;
            items = items.stream()
                    .filter(it -> u.equalsIgnoreCase(it.getUserResponsable()))
                    .toList();
        }

        int totalIncidencies = items != null ? items.size() : 0;
        BigDecimal costTotal = BigDecimal.ZERO;
        if (items != null) {
            for (InformeItem it : items) {
                if (it.getCost() != null) {
                    costTotal = costTotal.add(it.getCost());
                }
            }
        }

        model.addAttribute("rolActual", rolActual());
        model.addAttribute("usuari", usuariSel);
        model.addAttribute("agentsActius", agentsActius);

        model.addAttribute("matricula", matricula);
        model.addAttribute("matricules", historicIncidenciaNoSQLService.obtenirMatriculesDisponibles());
        model.addAttribute("items", items);

        model.addAttribute("totalIncidencies", totalIncidencies);
        model.addAttribute("costTotal", costTotal);

        String idSeleccionada = null;
        if (items != null && !items.isEmpty()) {
            if (idIncidencia != null && !idIncidencia.trim().isEmpty()) {
                String candidat = idIncidencia.trim();
                boolean existeix = items.stream().anyMatch(it -> candidat.equals(it.getIdIncidencia()));
                idSeleccionada = existeix ? candidat : items.get(0).getIdIncidencia();
            } else {
                idSeleccionada = items.get(0).getIdIncidencia();
            }
        }

        if (idSeleccionada != null && !idSeleccionada.trim().isEmpty()) {
            model.addAttribute("idIncidencia", idSeleccionada);
            List<HistoricIncidenciaNoSQL> historic = historicIncidenciaNoSQLService.llistarHistoricPerIncidencia(idSeleccionada);

            if (!isAdmin()) {
                final String u = usuariSel;
                historic = historic.stream()
                        .filter(h -> u.equalsIgnoreCase(h.getUserResponsable()))
                        .toList();
            }

            model.addAttribute("historic", historic);
        } else {
            model.addAttribute("idIncidencia", "");
            model.addAttribute("historic", null);
        }

        return "incidencies/historic-incidencies";
    }

    /**
     * Determina si l'usuari autenticat té rol d'administrador.
     *
     * @return {@code true} si l'usuari té l'autoritat ROLE_ADMIN o ADMIN; en
     * cas contrari {@code false}
     */
    private boolean isAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && authentication.getAuthorities().stream()
                .anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()) || "ADMIN".equals(a.getAuthority()));
    }

    /**
     * Recupera el nom d'usuari de la sessió actual.
     *
     * @return nom d'usuari autenticat; si no hi ha autenticació, retorna una
     * cadena buida
     */
    private String currentUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return (authentication != null) ? authentication.getName() : "";
    }

    /**
     * Retorna una representació simplificada del rol actual de l'usuari.
     *
     * @return "ADMIN" si l'usuari és administrador; en cas contrari "AGENT"
     */
    private String rolActual() {
        return isAdmin() ? "ADMIN" : "AGENT";
    }

}
