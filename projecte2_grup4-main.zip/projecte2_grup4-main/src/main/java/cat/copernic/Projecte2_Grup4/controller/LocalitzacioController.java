package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.model.Localitzacio;
import cat.copernic.Projecte2_Grup4.service.LocalitzacioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/web/localitzacions")
/**
 * Controlador web per a la gestió de les localitzacions del sistema.
 *
 * <p>
 * Permet llistar localitzacions, crear-ne de noves, editar-les, guardar canvis
 * i eliminar-les. També incorpora accions d'assignació i desassignació per
 * vincular vehicles i agents a una localització concreta.</p>
 *
 * <p>
 * La lògica de negoci (cerca, persistència i assignacions) es delega al servei
 * {@link LocalitzacioService}.</p>
 */
public class LocalitzacioController {

    @Autowired
    private LocalitzacioService localitzacioService;

    /**
     * Mostra el llistat de localitzacions, amb una cerca opcional.
     *
     * <p>
     * Si es proporciona el paràmetre {@code q} i no és buit, es realitza una
     * cerca. En cas contrari, es llisten totes les localitzacions
     * disponibles.</p>
     *
     * @param q text de cerca (opcional)
     * @param model model de Spring per exposar dades a la vista
     * @return nom de la plantilla Thymeleaf del llistat de localitzacions
     */
    @GetMapping("/llistar")
    public String llistar(@RequestParam(value = "q", required = false) String q, Model model) {

        List<Localitzacio> llista;
        if (q != null && !q.isBlank()) {
            llista = localitzacioService.cercarLocalitzacions(q);
        } else {
            llista = localitzacioService.llistarTotesLocalitzacions();
        }

        model.addAttribute("llistaLocalitzacions", llista);
        model.addAttribute("q", (q != null ? q : ""));
        return "localitzacions/llistar-localitzacions";
    }

    /**
     * Mostra el formulari per crear una nova localització.
     *
     * @param model model de Spring per inicialitzar l'objecte
     * {@link Localitzacio} a la vista
     * @return nom de la plantilla Thymeleaf del formulari de creació
     */
    @GetMapping("/crear-nova-localitzacio")
    public String mostrarFormCrear(Model model) {
        model.addAttribute("localitzacio", new Localitzacio());
        return "localitzacions/crear-localitzacions";
    }

    /**
     * Mostra el formulari d'edició d'una localització identificada pel seu codi
     * postal.
     *
     * <p>
     * Si la localització no existeix, es redirigeix al llistat amb un missatge
     * d'avís.</p>
     *
     * @param codiPostal identificador de la localització (codi postal)
     * @param model model de Spring per exposar dades a la vista
     * @param redirectAttributes atributs flash per mostrar missatges després de
     * redireccions
     * @return vista d'edició si existeix; en cas contrari, redirecció al
     * llistat
     */
    @GetMapping("/editar/{codiPostal}")
    public String mostrarFormEditar(@PathVariable("codiPostal") String codiPostal,
            Model model,
            RedirectAttributes redirectAttributes) {

        Localitzacio loc = localitzacioService.obtenirLocalitzacioPerId(codiPostal);
        if (loc == null) {
            redirectAttributes.addFlashAttribute("missatge", "La localització no existeix!");
            redirectAttributes.addFlashAttribute("tipusMissatge", "warning");
            return "redirect:/web/localitzacions/llistar";
        }

        model.addAttribute("localitzacio", loc);
        return "localitzacions/modificar-localitzacio";
    }

    /**
     * Desa una localització (alta o actualització) i redirigeix al llistat.
     *
     * <p>
     * Determina si és una nova localització comprovant si ja existeix una
     * entrada amb el mateix codi postal.</p>
     *
     * @param localitzacio localització a desar
     * @param redirectAttributes atributs flash per informar del resultat de
     * l'operació
     * @return redirecció cap al llistat de localitzacions
     */
    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("localitzacio") Localitzacio localitzacio,
            RedirectAttributes redirectAttributes) {

        try {
            boolean esNova = (localitzacioService.obtenirLocalitzacioPerId(localitzacio.getCodiPostal()) == null);

            // Desar (alta o actualització)
            localitzacioService.guardarLocalitzacio(localitzacio);

            redirectAttributes.addFlashAttribute("missatge",
                    esNova ? "Localització creada correctament!" : "Localització actualitzada correctament!");
            redirectAttributes.addFlashAttribute("tipusMissatge", "success");

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("missatge", "Error en desar la localització: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipusMissatge", "danger");
        }

        return "redirect:/web/localitzacions/llistar";
    }

    /**
     * Elimina una localització pel seu codi postal.
     *
     * <p>
     * Inclou una validació prèvia per evitar eliminar una localització si té
     * vehicles assignats o un agent associat.</p>
     *
     * @param codiPostal identificador de la localització (codi postal)
     * @param redirectAttributes atributs flash per informar del resultat de
     * l'operació
     * @return redirecció cap al llistat de localitzacions
     */
    @PostMapping("/eliminar/{codiPostal}")
    public String eliminar(@PathVariable("codiPostal") String codiPostal,
            RedirectAttributes redirectAttributes) {
        try {
            Localitzacio loc = localitzacioService.obtenirLocalitzacioPerId(codiPostal);
            if (loc == null) {
                redirectAttributes.addFlashAttribute("missatge", "La localització no existeix!");
                redirectAttributes.addFlashAttribute("tipusMissatge", "warning");
                return "redirect:/web/localitzacions/llistar";
            }

            // Política bàsica com vas demanar: si té vehicles o agent, no l'eliminem (com a primer pas funcional)
            if (loc.getVehicles() != null && !loc.getVehicles().isEmpty()) {
                redirectAttributes.addFlashAttribute("missatge", "No es pot eliminar: té vehicles assignats");
                redirectAttributes.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/localitzacions/llistar";
            }
            if (loc.getAgent() != null) {
                redirectAttributes.addFlashAttribute("missatge", "No es pot eliminar: té un agent assignat");
                redirectAttributes.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/localitzacions/llistar";
            }

            localitzacioService.eliminarLocalitzacio(codiPostal);

            redirectAttributes.addFlashAttribute("missatge", "Localització eliminada correctament!");
            redirectAttributes.addFlashAttribute("tipusMissatge", "success");

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("missatge", "Error en eliminar la localització: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipusMissatge", "danger");
        }

        return "redirect:/web/localitzacions/llistar";
    }

    // --- Assignacions (POST senzills) ---
    /**
     * Assigna un vehicle a una localització.
     *
     * <p>
     * L'operació es delega al servei i retorna un missatge d'èxit o error.</p>
     *
     * @param codiPostal codi postal de la localització
     * @param matricule matrícula del vehicle a assignar
     * @param redirectAttributes atributs flash per informar del resultat
     * @return redirecció cap al formulari d'edició de la localització
     */
    @PostMapping("/assignar-vehicle")
    public String assignarVehicle(@RequestParam("codiPostal") String codiPostal,
            @RequestParam("matricule") String matricule,
            RedirectAttributes redirectAttributes) {

        boolean ok = localitzacioService.assignarVehicle(codiPostal, matricule);

        if (ok) {
            redirectAttributes.addFlashAttribute("missatge", "Vehicle assignat correctament!");
            redirectAttributes.addFlashAttribute("tipusMissatge", "success");
        } else {
            redirectAttributes.addFlashAttribute("missatge", "No s'ha pogut assignar (localització o vehicle inexistent)");
            redirectAttributes.addFlashAttribute("tipusMissatge", "danger");
        }

        return "redirect:/web/localitzacions/editar/" + codiPostal;
    }

    /**
     * Assigna un agent a una localització.
     *
     * <p>
     * L'operació es delega al servei i retorna un missatge d'èxit o error.</p>
     *
     * @param codiPostal codi postal de la localització
     * @param dni DNI de l'agent a assignar
     * @param redirectAttributes atributs flash per informar del resultat
     * @return redirecció cap al formulari d'edició de la localització
     */
    @PostMapping("/assignar-agent")
    public String assignarAgent(@RequestParam("codiPostal") String codiPostal,
            @RequestParam("dni") String dni,
            RedirectAttributes redirectAttributes) {

        boolean ok = localitzacioService.assignarAgent(codiPostal, dni);

        if (ok) {
            redirectAttributes.addFlashAttribute("missatge", "Agent assignat correctament!");
            redirectAttributes.addFlashAttribute("tipusMissatge", "success");
        } else {
            redirectAttributes.addFlashAttribute("missatge", "No s'ha pogut assignar (localització o agent inexistent)");
            redirectAttributes.addFlashAttribute("tipusMissatge", "danger");
        }

        return "redirect:/web/localitzacions/editar/" + codiPostal;
    }

    /**
     * Desassigna l'agent associat a una localització.
     *
     * @param codiPostal codi postal de la localització
     * @param redirectAttributes atributs flash per informar del resultat
     * @return redirecció cap al formulari d'edició de la localització
     */
    @PostMapping("/desassignar-agent/{codiPostal}")
    public String desassignarAgent(@PathVariable("codiPostal") String codiPostal,
            RedirectAttributes redirectAttributes) {
        boolean ok = localitzacioService.desassignarAgent(codiPostal);

        if (ok) {
            redirectAttributes.addFlashAttribute("missatge", "Agent desassignat correctament!");
            redirectAttributes.addFlashAttribute("tipusMissatge", "success");
        } else {
            redirectAttributes.addFlashAttribute("missatge", "La localització no existeix!");
            redirectAttributes.addFlashAttribute("tipusMissatge", "warning");
        }

        return "redirect:/web/localitzacions/editar/" + codiPostal;
    }
}
