package cat.copernic.Projecte2_Grup4.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.util.List;

@Entity
@Table(name = "localitzacio")
/**
 * Entitat JPA que representa una localització (punt o oficina) del sistema.
 *
 * <p>
 * Una localització s'identifica pel seu {@code codiPostal} i conté informació
 * descriptiva com el nom i l'adreça. També pot tenir:</p>
 * <ul>
 * <li>Un {@link Agent} assignat (relació 1:1), que actua com a responsable del
 * punt.</li>
 * <li>Una llista de {@link Vehicle} associats (relació 1:N) que es troben a la
 * localització.</li>
 * </ul>
 */
public class Localitzacio {

    @Id
    @Column(length = 10)
    private String codiPostal;

    @Column(columnDefinition = "TEXT")
    private String nom;

    @Column(columnDefinition = "TEXT")
    private String adreça;

    @OneToOne
    @JoinColumn(name = "dni")
    private Agent agent;

    @OneToMany(mappedBy = "localitzacio")
    private List<Vehicle> vehicles;

    // constructors
    /**
     * Constructor per defecte.
     */
    public Localitzacio() {
    }

    /**
     * Constructor complet.
     *
     * @param codiPostal codi postal (identificador)
     * @param nom nom de la localització
     * @param adreça adreça de la localització
     * @param agent agent assignat (opcional)
     * @param vehicles vehicles associats (opcional)
     */
    public Localitzacio(String codiPostal, String nom, String adreça, Agent agent, List<Vehicle> vehicles) {
        this.codiPostal = codiPostal;
        this.nom = nom;
        this.adreça = adreça;
        this.agent = agent;
        this.vehicles = vehicles;
    }

    // getters i setters
    /**
     * Retorna el codi postal de la localització.
     *
     * @return codi postal
     */
    public String getCodiPostal() {
        return codiPostal;
    }

    /**
     * Assigna el codi postal de la localització.
     *
     * @param codiPostal codi postal
     */
    public void setCodiPostal(String codiPostal) {
        this.codiPostal = codiPostal;
    }

    /**
     * Retorna el nom de la localització.
     *
     * @return nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * Assigna el nom de la localització.
     *
     * @param nom nom
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Retorna l'adreça de la localització.
     *
     * @return adreça
     */
    public String getAdreça() {
        return adreça;
    }

    /**
     * Assigna l'adreça de la localització.
     *
     * @param adreça adreça
     */
    public void setAdreça(String adreça) {
        this.adreça = adreça;
    }

    /**
     * Retorna l'agent assignat a la localització.
     *
     * @return agent assignat
     */
    public Agent getAgent() {
        return agent;
    }

    /**
     * Assigna l'agent responsable de la localització.
     *
     * @param agent agent assignat
     */
    public void setAgent(Agent agent) {
        this.agent = agent;
    }

    /**
     * Retorna la llista de vehicles associats a la localització.
     *
     * @return llista de vehicles
     */
    public List<Vehicle> getVehicles() {
        return vehicles;
    }

    /**
     * Assigna la llista de vehicles associats a la localització.
     *
     * @param vehicles llista de vehicles
     */
    public void setVehicles(List<Vehicle> vehicles) {
        this.vehicles = vehicles;
    }
}
