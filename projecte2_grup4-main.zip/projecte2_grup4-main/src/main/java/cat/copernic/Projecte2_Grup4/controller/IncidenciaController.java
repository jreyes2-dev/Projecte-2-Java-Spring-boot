package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.model.Incidencia;
import cat.copernic.Projecte2_Grup4.model.Vehicle;
import cat.copernic.Projecte2_Grup4.model.enums.Antiguitat;
import cat.copernic.Projecte2_Grup4.model.enums.EstatIncidencia;
import cat.copernic.Projecte2_Grup4.model.enums.Rol;
import cat.copernic.Projecte2_Grup4.service.AgentService;
import cat.copernic.Projecte2_Grup4.service.DocumentacioIncidenciaNoSQLService;
import cat.copernic.Projecte2_Grup4.service.IncidenciaService;
import cat.copernic.Projecte2_Grup4.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/web/incidencies")
/**
 * Controlador web per a la gestió d'incidències del sistema.
 *
 * <p>
 * Inclou funcionalitats de llistat amb filtres, creació, edició, des/activació
 * i validació de dades. El comportament de visualització i permisos varia en
 * funció del rol de l'usuari autenticat (administrador o agent).</p>
 *
 * <p>
 * Quan l'usuari no és administrador, només pot visualitzar i gestionar
 * incidències assignades al seu usuari.</p>
 */
public class IncidenciaController {

    @Autowired
    private IncidenciaService incidenciaService;

    @Autowired
    private AgentService agentService;

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private DocumentacioIncidenciaNoSQLService documentacioIncidenciaNoSQLService;

    /**
     * Mostra el llistat d'incidències amb filtres opcionals (estat, antiguitat
     * i vehicle).
     *
     * <p>
     * Si l'usuari és administrador, pot veure totes les incidències. En cas
     * contrari, només es mostren les incidències assignades al seu nom
     * d'usuari.</p>
     *
     * @param estat filtre per estat de la incidència (opcional)
     * @param antiguitat filtre per antiguitat (opcional)
     * @param matriculaVehicle filtre per matrícula del vehicle (opcional)
     * @param model model de Spring per exposar dades a la vista
     * @return nom de la plantilla Thymeleaf del llistat d'incidències
     */
    @GetMapping("/llistar")
    public String llistarIncidencias(
            @RequestParam(value = "estat", required = false) String estat,
            @RequestParam(value = "antiguitat", required = false) String antiguitat,
            @RequestParam(value = "vehicle", required = false) String matriculaVehicle,
            Model model) {

        boolean esAdmin = isAdmin();

        List<String> nomsAgents = agentService.llistarTotsAgents().stream()
                .filter(a -> a != null
                && a.getRol() == Rol.AGENT
                && a.getNomUser() != null
                && a.getEstatAgent() != null
                && a.getEstatAgent().name().equals("ACTIU"))
                .map(a -> a.getNomUser().trim())
                .filter(n -> !n.isEmpty())
                .collect(Collectors.toList());

        String agentSeleccionat = esAdmin ? "" : currentUsername();

        List<Incidencia> llistaIncidencias = filtrarIncidencias(
                estat, antiguitat, matriculaVehicle, esAdmin, agentSeleccionat
        );

        List<Incidencia> totesIncidencies = incidenciaService.llistarTotesIncidencies();
        long incidenciasAdmin = totesIncidencies.stream()
                .filter(i -> i.getCreadoPor() != null && i.getCreadoPor().equals("ADMIN"))
                .count();

        Integer proximold = totesIncidencies.stream()
                .mapToInt(Incidencia::getIdIncidence)
                .max()
                .orElse(0) + 1;

        List<Vehicle> vehicles = vehicleService.llistarTotsVehicles();

        model.addAttribute("llistaIncidencias", llistaIncidencias);
        model.addAttribute("filtreEstat", estat != null ? estat : "");
        model.addAttribute("filtreAntiguitat", antiguitat != null ? antiguitat : "");
        model.addAttribute("filtreVehicle", matriculaVehicle != null ? matriculaVehicle : "");
        model.addAttribute("esAdmin", esAdmin);
        model.addAttribute("rolActual", rolActual());
        model.addAttribute("agentSeleccionat", agentSeleccionat);
        model.addAttribute("proximold", proximold);
        model.addAttribute("totalIncidencias", totesIncidencies.size());
        model.addAttribute("incidenciasAdmin", incidenciasAdmin);
        model.addAttribute("incidenciasAgent", totesIncidencies.size() - incidenciasAdmin);
        model.addAttribute("nomsAgents", nomsAgents);
        model.addAttribute("vehicles", vehicles);

        return "incidencies/llistar-incidencies";
    }

    /**
     * Aplica els filtres de llistat sobre la col·lecció d'incidències.
     *
     * <p>
     * Regles:</p>
     * <ul>
     * <li>Si és administrador, parteix de totes les incidències.</li>
     * <li>Si és agent, només inclou les incidències assignades al seu
     * usuari.</li>
     * <li>Opcionalment filtra per estat, antiguitat i matrícula de
     * vehicle.</li>
     * </ul>
     *
     * @param estat estat a filtrar (cadena amb el valor de l'enum)
     * @param antiguitat antiguitat a filtrar (cadena amb el valor de l'enum)
     * @param matriculaVehicle matrícula del vehicle a filtrar
     * @param esAdmin indica si l'usuari és administrador
     * @param agentSeleccionat usuari de l'agent (obligatori quan no és admin)
     * @return llista d'incidències filtrada segons els criteris indicats
     */
    private List<Incidencia> filtrarIncidencias(String estat, String antiguitat, String matriculaVehicle,
            boolean esAdmin, String agentSeleccionat) {

        List<Incidencia> totesIncidencies = incidenciaService.llistarTotesIncidencies();

        List<Incidencia> resultat = esAdmin
                ? new ArrayList<>(totesIncidencies)
                : totesIncidencies.stream()
                        .filter(i -> i.getAssignadaA() != null && i.getAssignadaA().equalsIgnoreCase(agentSeleccionat))
                        .collect(Collectors.toList());

        if (estat != null && !estat.isEmpty()) {
            resultat = resultat.stream()
                    .filter(i -> i.getEstat() != null && i.getEstat().toString().equals(estat))
                    .collect(Collectors.toList());
        }

        if (antiguitat != null && !antiguitat.isEmpty()) {
            resultat = resultat.stream()
                    .filter(i -> i.getAntiguitat() != null && i.getAntiguitat().toString().equals(antiguitat))
                    .collect(Collectors.toList());
        }

        if (matriculaVehicle != null && !matriculaVehicle.isEmpty()) {
            resultat = resultat.stream()
                    .filter(i -> i.getVehicle() != null
                    && i.getVehicle().getMatricule() != null
                    && i.getVehicle().getMatricule().equalsIgnoreCase(matriculaVehicle))
                    .collect(Collectors.toList());
        }

        return resultat;
    }

    /**
     * Mostra el formulari per crear una nova incidència.
     *
     * <p>
     * Inicialitza una incidència amb valors per defecte (estat actiu,
     * antiguitat nova) i prepara les dades necessàries per a la vista, com ara
     * la llista de vehicles.</p>
     *
     * @param model model de Spring per exposar dades a la vista
     * @return nom de la plantilla Thymeleaf del formulari de creació
     */
    @GetMapping("/crear-nova-incidencia")
    public String mostrarFormulariCrearNovaIncidencia(Model model) {

        boolean esAdmin = isAdmin();
        String agentSeleccionat = esAdmin ? "ADMIN" : currentUsername();

        Incidencia incidencia = new Incidencia();
        incidencia.setEstat(EstatIncidencia.Activa);
        incidencia.setAntiguitat(Antiguitat.Nova);
        incidencia.setVehicle(new Vehicle());

        Integer proximold = incidenciaService.llistarTotesIncidencies().stream()
                .mapToInt(Incidencia::getIdIncidence)
                .max()
                .orElse(0) + 1;

        List<Vehicle> vehicles = vehicleService.llistarTotsVehicles();

        model.addAttribute("incidencia", incidencia);
        model.addAttribute("esAdmin", esAdmin);
        model.addAttribute("rolActual", rolActual());
        model.addAttribute("agentSeleccionat", agentSeleccionat);
        model.addAttribute("proximold", proximold);
        model.addAttribute("vehicles", vehicles);

        return "incidencies/crear-incidencies";
    }

    /**
     * Mostra el formulari d'edició d'una incidència existent.
     *
     * <p>
     * Valida l'existència de la incidència i comprova permisos: els agents
     * només poden editar incidències assignades al seu usuari.</p>
     *
     * @param id identificador de la incidència
     * @param model model de Spring per exposar dades a la vista
     * @param redirectAttributes atributs flash per mostrar missatges després de
     * redireccions
     * @return vista d'edició si tot és correcte; redirecció al llistat en cas
     * d'error o manca de permisos
     */
    @GetMapping("/editar/{id}")
    public String mostrarFormulariEditarIncidencia(
            @PathVariable("id") Integer id,
            Model model,
            RedirectAttributes redirectAttributes) {

        boolean esAdmin = isAdmin();
        String agentSeleccionat = esAdmin ? "ADMIN" : currentUsername();

        Incidencia incidencia = incidenciaService.obtenirIncidenciaPerld(id);

        if (incidencia == null) {
            redirectAttributes.addFlashAttribute("missatge", "La incidència a editar no existeix!");
            redirectAttributes.addFlashAttribute("tipusMissatge", "warning");
            return "redirect:/web/incidencies/llistar";
        }

        if (!esAdmin && (incidencia.getAssignadaA() == null || !incidencia.getAssignadaA().equalsIgnoreCase(agentSeleccionat))) {
            redirectAttributes.addFlashAttribute("missatge", "No tens permís per editar aquesta incidència!");
            redirectAttributes.addFlashAttribute("tipusMissatge", "danger");
            return "redirect:/web/incidencies/llistar";
        }

        List<Vehicle> vehicles = vehicleService.llistarTotsVehicles();

        model.addAttribute("incidencia", incidencia);
        model.addAttribute("vehicles", vehicles);
        model.addAttribute("vehicleMatricula",
                incidencia.getVehicle() != null ? incidencia.getVehicle().getMatricule() : "");
        model.addAttribute("esAdmin", esAdmin);
        model.addAttribute("rolActual", rolActual());
        model.addAttribute("agentSeleccionat", agentSeleccionat);

        return "incidencies/modificar-incidencies";
    }

    /**
     * Desa una incidència (creació o actualització) i aplica validacions.
     *
     * <p>
     * Flux principal:</p>
     * <ul>
     * <li>Assigna el vehicle segons la matrícula (si s'ha proporcionat).</li>
     * <li>Executa validacions del servei i gestiona errors via atributs
     * flash.</li>
     * <li>Si és una incidència nova, inicialitza camps de control (creador,
     * assignació, dates, etc.).</li>
     * <li>Persisteix la incidència i, si és nova, permet adjuntar fotografies
     * de danys a NoSQL.</li>
     * </ul>
     *
     * @param incidencia objecte incidència provinent del formulari
     * @param vehicleMatricula matrícula del vehicle seleccionat (opcional)
     * @param fotosDany llista de fitxers de fotografies de dany (opcional)
     * @param redirectAttributes atributs flash per informar del resultat de
     * l'operació
     * @return redirecció cap al llistat d'incidències
     */
    @PostMapping("/guardar")
    public String guardarIncidencia(
            @ModelAttribute("incidencia") Incidencia incidencia,
            @RequestParam(value = "vehicleMatricula", required = false) String vehicleMatricula,
            @RequestParam(value = "fotosDany", required = false) List<MultipartFile> fotosDany,
            RedirectAttributes redirectAttributes) {

        boolean esAdmin = isAdmin();
        String agentSeleccionat = esAdmin ? "ADMIN" : currentUsername();

        try {
            if (vehicleMatricula != null && !vehicleMatricula.trim().isEmpty()) {
                Vehicle vehicle = vehicleService.obtenirVehiclePerMatricula(vehicleMatricula.trim());
                incidencia.setVehicle(vehicle);
            } else {
                incidencia.setVehicle(null);
            }

            Map<String, String> errors = incidenciaService.validarIncidencia(incidencia);

            if (!errors.isEmpty()) {
                errors.forEach((camp, missatge) -> redirectAttributes.addFlashAttribute(camp + "Error", missatge));

                if (errors.containsKey("estimatedCost")) {
                    redirectAttributes.addFlashAttribute("showCostLimitModal", true);
                    redirectAttributes.addFlashAttribute("costErrorMessage", errors.get("estimatedCost"));
                }

                if (incidencia.getIdIncidence() != null) {
                    return "redirect:/web/incidencies/editar/" + incidencia.getIdIncidence();
                } else {
                    return "redirect:/web/incidencies/crear-nova-incidencia";
                }
            }

            if (incidencia.getIdIncidence() == null) {
                String creador = esAdmin ? "ADMIN" : agentSeleccionat;
                incidencia.setCreadoPor(creador);
                incidencia.setAssignadaA(creador);
                incidencia.setEstat(EstatIncidencia.Activa);
                incidencia.setDataCreacio(LocalDateTime.now());
                incidencia.setAntiguitat(Antiguitat.Nova);
            } else {
                Incidencia original = incidenciaService.obtenirIncidenciaPerld(incidencia.getIdIncidence());
                if (original != null) {
                    incidencia.setDataCreacio(original.getDataCreacio());
                    incidencia.setAntiguitat(original.getAntiguitat());
                    incidencia.setCreadoPor(original.getCreadoPor());
                    incidencia.setAssignadaA(original.getAssignadaA());
                }
            }

            boolean esNova = (incidencia.getIdIncidence() == null);
            Incidencia guardada = incidenciaService.guardarIncidenciaIRetornar(incidencia);
            incidencia.setIdIncidence(guardada.getIdIncidence());

            if (esNova && fotosDany != null && fotosDany.stream().anyMatch(f -> f != null && !f.isEmpty())) {
                DocumentacioIncidenciaNoSQLService.AfegirFitxersResult resFotos = documentacioIncidenciaNoSQLService
                        .afegirFotosDanyCreacio(String.valueOf(guardada.getIdIncidence()), fotosDany);
                if (resFotos != null && resFotos.getDuplicats() != null && !resFotos.getDuplicats().isEmpty()) {
                    redirectAttributes.addFlashAttribute("missatgeError", "⚠️ Aquesta foto ja està pujada: " + String.join(", ", resFotos.getDuplicats()));
                }
            }

            redirectAttributes.addFlashAttribute("missatge",
                    incidencia.getIdIncidence() == null ? "Incidència creada correctament!" : "Incidència actualitzada correctament!");
            redirectAttributes.addFlashAttribute("tipusMissatge", "success");

        } catch (Exception e) {
            String msg = e.getMessage() != null ? e.getMessage() : "Error inesperat";
            redirectAttributes.addFlashAttribute("missatge", "❌ " + msg);
            redirectAttributes.addFlashAttribute("tipusMissatge", "danger");
        }

        return "redirect:/web/incidencies/llistar";
    }

    /**
     * Desactiva una incidència existent.
     *
     * @param id identificador de la incidència
     * @param redirectAttributes atributs flash per informar del resultat
     * @return redirecció cap al llistat d'incidències
     */
    @PostMapping("/desactivar/{id}")
    public String desactivarIncidencia(@PathVariable("id") Integer id, RedirectAttributes redirectAttributes) {
        return gestionarEstatIncidencia(id, redirectAttributes, false);
    }

    /**
     * Activa una incidència existent.
     *
     * @param id identificador de la incidència
     * @param redirectAttributes atributs flash per informar del resultat
     * @return redirecció cap al llistat d'incidències
     */
    @PostMapping("/activar/{id}")
    public String activarIncidencia(@PathVariable("id") Integer id, RedirectAttributes redirectAttributes) {
        return gestionarEstatIncidencia(id, redirectAttributes, true);
    }

    /**
     * Gestiona el canvi d'estat (activar o desactivar) d'una incidència amb
     * control de permisos.
     *
     * <p>
     * Els agents només poden canviar l'estat de les incidències assignades al
     * seu usuari.</p>
     *
     * @param id identificador de la incidència
     * @param redirectAttributes atributs flash per informar del resultat
     * @param activar {@code true} per activar; {@code false} per desactivar
     * @return redirecció cap al llistat d'incidències
     */
    private String gestionarEstatIncidencia(Integer id, RedirectAttributes redirectAttributes, boolean activar) {
        boolean esAdmin = isAdmin();
        String agentSeleccionat = esAdmin ? "ADMIN" : currentUsername();

        try {
            Incidencia incidencia = incidenciaService.obtenirIncidenciaPerld(id);

            if (incidencia == null) {
                redirectAttributes.addFlashAttribute("missatge", "La incidència no existeix!");
                redirectAttributes.addFlashAttribute("tipusMissatge", "warning");
                return "redirect:/web/incidencies/llistar";
            }

            if (!esAdmin && (incidencia.getAssignadaA() == null || !incidencia.getAssignadaA().equalsIgnoreCase(agentSeleccionat))) {
                redirectAttributes.addFlashAttribute("missatge",
                        "No tens permís per " + (activar ? "activar" : "desactivar") + " aquesta incidència!");
                redirectAttributes.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/incidencies/llistar";
            }

            if (activar) {
                incidenciaService.activarIncidencia(id);
            } else {
                incidenciaService.desactivarIncidencia(id);
            }

            redirectAttributes.addFlashAttribute("missatge",
                    "Incidència " + (activar ? "activada" : "desactivada") + " correctament");
            redirectAttributes.addFlashAttribute("tipusMissatge", "success");

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("missatge", "Error: " + e.getMessage());
            redirectAttributes.addFlashAttribute("tipusMissatge", "danger");
        }

        return "redirect:/web/incidencies/llistar";
    }

    /**
     * Determina si l'usuari autenticat té rol d'administrador.
     *
     * @return {@code true} si disposa de l'autoritat ROLE_ADMIN; en cas
     * contrari {@code false}
     */
    private boolean isAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && authentication.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
    }

    /**
     * Recupera el nom d'usuari de la sessió actual.
     *
     * @return nom d'usuari autenticat; si no hi ha autenticació, retorna una
     * cadena buida
     */
    private String currentUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return (authentication != null) ? authentication.getName() : "";
    }

    /**
     * Retorna una representació simplificada del rol actual de l'usuari.
     *
     * @return "ADMIN" si l'usuari és administrador; en cas contrari "AGENT"
     */
    private String rolActual() {
        return isAdmin() ? "ADMIN" : "AGENT";
    }
}
