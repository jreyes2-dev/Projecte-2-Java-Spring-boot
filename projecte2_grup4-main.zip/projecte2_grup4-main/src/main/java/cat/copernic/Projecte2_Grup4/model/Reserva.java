package cat.copernic.Projecte2_Grup4.model;

import cat.copernic.Projecte2_Grup4.model.enums.EstatReserva;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "reserva")
/**
 * Entitat JPA que representa una reserva de vehicle.
 *
 * <p>
 * Una reserva associa un {@link Client} amb un {@link Vehicle} durant un
 * interval de dates ({@code dataInici} i {@code dataFi}). Inclou informació
 * econòmica (cost total i fiança), l'estat actual de la reserva
 * ({@link EstatReserva}) i la data de creació.</p>
 *
 * <p>
 * La classe també contempla el flux operatiu de:</p>
 * <ul>
 * <li><strong>Lliurament</strong>: data i hora de lliurament i descripció de
 * l'estat del vehicle.</li>
 * <li><strong>Retorn</strong>: data i hora de retorn, retard i possibles
 * desperfectes, així com la gestió de la fiança.</li>
 * </ul>
 */
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // codi que veu l'usuari
    @Column(name = "codi_reserva", length = 30, nullable = false, unique = true)
    private String codiReserva;

    @Column(nullable = false)
    private LocalDate dataInici;

    @Column(nullable = false)
    private LocalDate dataFi;

    @Enumerated(EnumType.STRING)
    @Column(length = 20, nullable = false)
    private EstatReserva estat;

    @Column(name = "cost_total", nullable = false)
    private Double costTotal;

    @Column(nullable = false)
    private Double fianca;

    @Column(name = "data_creacio", nullable = false)
    private LocalDateTime dataCreacio;

    @ManyToOne(optional = false)
    @JoinColumn(name = "vehicle_matricula", referencedColumnName = "matricule")
    private Vehicle vehicle;

    @ManyToOne(optional = false)
    @JoinColumn(name = "client_dni", referencedColumnName = "dni")
    private Client client;

    // Lliurar vehicle
    @Column(name = "data_hora_lliurament")
    private LocalDateTime dataHoraLliurament;

    @Column(name = "descripcio_estat_lliurament", columnDefinition = "TEXT")
    private String descripcioEstatLliurament;

    // Retornar vehicle
    @Column(name = "data_hora_retorn")
    private LocalDateTime dataHoraRetorn;

    @Column(name = "hores_retard")
    private Integer horesRetard;

    @Column(name = "import_retard")
    private Double importRetard;

    @Column(name = "te_desperfectes")
    private Boolean desperfectes;

    @Column(name = "imputable_client")
    private Boolean imputableClient;

    @Column(name = "fianca_retinguda")
    private Boolean fiancaRetinguda;

    /**
     * Retorna la data i hora de lliurament del vehicle.
     *
     * @return data i hora de lliurament (pot ser {@code null} si encara no s'ha
     * lliurat)
     */
    public LocalDateTime getDataHoraLliurament() {
        return dataHoraLliurament;
    }

    /**
     * Constructor per defecte.
     */
    public Reserva() {
    }

    /**
     * Retorna l'identificador intern de la reserva.
     *
     * @return id intern de la reserva
     */
    public Long getId() {
        return id;
    }

    /**
     * Retorna el codi de reserva visible per a l'usuari.
     *
     * @return codi de reserva
     */
    public String getCodiReserva() {
        return codiReserva;
    }

    /**
     * Assigna el codi de reserva visible per a l'usuari.
     *
     * @param codiReserva codi de reserva
     */
    public void setCodiReserva(String codiReserva) {
        this.codiReserva = codiReserva;
    }

    /**
     * Retorna la data d'inici de la reserva.
     *
     * @return data d'inici
     */
    public LocalDate getDataInici() {
        return dataInici;
    }

    /**
     * Assigna la data d'inici de la reserva.
     *
     * @param dataInici data d'inici
     */
    public void setDataInici(LocalDate dataInici) {
        this.dataInici = dataInici;
    }

    /**
     * Retorna la data de fi de la reserva.
     *
     * @return data de fi
     */
    public LocalDate getDataFi() {
        return dataFi;
    }

    /**
     * Assigna la data de fi de la reserva.
     *
     * @param dataFi data de fi
     */
    public void setDataFi(LocalDate dataFi) {
        this.dataFi = dataFi;
    }

    /**
     * Retorna l'estat actual de la reserva.
     *
     * @return estat de la reserva
     */
    public EstatReserva getEstat() {
        return estat;
    }

    /**
     * Assigna l'estat actual de la reserva.
     *
     * @param estat nou estat
     */
    public void setEstat(EstatReserva estat) {
        this.estat = estat;
    }

    /**
     * Retorna el cost total de la reserva.
     *
     * @return cost total
     */
    public Double getCostTotal() {
        return costTotal;
    }

    /**
     * Assigna el cost total de la reserva.
     *
     * @param costTotal cost total
     */
    public void setCostTotal(Double costTotal) {
        this.costTotal = costTotal;
    }

    /**
     * Retorna la fiança associada a la reserva.
     *
     * @return fiança
     */
    public Double getFianca() {
        return fianca;
    }

    /**
     * Assigna la fiança associada a la reserva.
     *
     * @param fianca fiança
     */
    public void setFianca(Double fianca) {
        this.fianca = fianca;
    }

    /**
     * Retorna la data de creació de la reserva.
     *
     * @return data de creació
     */
    public LocalDateTime getDataCreacio() {
        return dataCreacio;
    }

    /**
     * Assigna la data de creació de la reserva.
     *
     * @param dataCreacio nova data de creació
     */
    public void setDataCreacio(LocalDateTime dataCreacio) {
        this.dataCreacio = dataCreacio;
    }

    /**
     * Retorna el vehicle associat a la reserva.
     *
     * @return vehicle associat
     */
    public Vehicle getVehicle() {
        return vehicle;
    }

    /**
     * Assigna el vehicle associat a la reserva.
     *
     * @param vehicle vehicle associat
     */
    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    /**
     * Retorna el client associat a la reserva.
     *
     * @return client associat
     */
    public Client getClient() {
        return client;
    }

    /**
     * Assigna el client associat a la reserva.
     *
     * @param client client associat
     */
    public void setClient(Client client) {
        this.client = client;
    }

    /**
     * Assigna la data i hora de lliurament del vehicle.
     *
     * @param dataHoraLliurament data i hora de lliurament
     */
    public void setDataHoraLliurament(LocalDateTime dataHoraLliurament) {
        this.dataHoraLliurament = dataHoraLliurament;
    }

    /**
     * Retorna la descripció de l'estat del vehicle en el moment del lliurament.
     *
     * @return descripció de l'estat de lliurament
     */
    public String getDescripcioEstatLliurament() {
        return descripcioEstatLliurament;
    }

    /**
     * Assigna la descripció de l'estat del vehicle en el moment del lliurament.
     *
     * @param descripcioEstatLliurament descripció de l'estat de lliurament
     */
    public void setDescripcioEstatLliurament(String descripcioEstatLliurament) {
        this.descripcioEstatLliurament = descripcioEstatLliurament;
    }

    /**
     * Retorna la data i hora de retorn del vehicle.
     *
     * @return data i hora de retorn (pot ser {@code null} si encara no s'ha
     * retornat)
     */
    public LocalDateTime getDataHoraRetorn() {
        return dataHoraRetorn;
    }

    /**
     * Assigna la data i hora de retorn del vehicle.
     *
     * @param dataHoraRetorn data i hora de retorn
     */
    public void setDataHoraRetorn(LocalDateTime dataHoraRetorn) {
        this.dataHoraRetorn = dataHoraRetorn;
    }

    /**
     * Retorna el nombre d'hores de retard en el retorn.
     *
     * @return hores de retard (pot ser {@code null})
     */
    public Integer getHoresRetard() {
        return horesRetard;
    }

    /**
     * Assigna el nombre d'hores de retard en el retorn.
     *
     * @param horesRetard hores de retard
     */
    public void setHoresRetard(Integer horesRetard) {
        this.horesRetard = horesRetard;
    }

    /**
     * Retorna l'import aplicat per retard.
     *
     * @return import de retard (pot ser {@code null})
     */
    public Double getImportRetard() {
        return importRetard;
    }

    /**
     * Assigna l'import aplicat per retard.
     *
     * @param importRetard import de retard
     */
    public void setImportRetard(Double importRetard) {
        this.importRetard = importRetard;
    }

    /**
     * Indica si s'han detectat desperfectes en el retorn.
     *
     * @return {@code true} si hi ha desperfectes; {@code false} si no; o
     * {@code null} si no s'ha informat
     */
    public Boolean getDesperfectes() {
        return desperfectes;
    }

    /**
     * Assigna si s'han detectat desperfectes en el retorn.
     *
     * @param desperfectes indicador de desperfectes
     */
    public void setDesperfectes(Boolean desperfectes) {
        this.desperfectes = desperfectes;
    }

    /**
     * Indica si els desperfectes són imputables al client.
     *
     * @return {@code true} si són imputables; {@code false} si no; o
     * {@code null} si no aplica/no s'ha informat
     */
    public Boolean getImputableClient() {
        return imputableClient;
    }

    /**
     * Assigna si els desperfectes són imputables al client.
     *
     * @param imputableClient indicador d'imputabilitat
     */
    public void setImputableClient(Boolean imputableClient) {
        this.imputableClient = imputableClient;
    }

    /**
     * Indica si s'ha retingut la fiança.
     *
     * @return {@code true} si s'ha retingut; {@code false} si no; o
     * {@code null} si no s'ha informat
     */
    public Boolean getFiancaRetinguda() {
        return fiancaRetinguda;
    }

    /**
     * Assigna si s'ha retingut la fiança.
     *
     * @param fiancaRetinguda indicador de retenció de fiança
     */
    public void setFiancaRetinguda(Boolean fiancaRetinguda) {
        this.fiancaRetinguda = fiancaRetinguda;
    }

}
