package cat.copernic.Projecte2_Grup4.service;

import cat.copernic.Projecte2_Grup4.model.Client;
import cat.copernic.Projecte2_Grup4.model.Reserva;
import cat.copernic.Projecte2_Grup4.model.Vehicle;
import cat.copernic.Projecte2_Grup4.model.enums.EstatReserva;
import cat.copernic.Projecte2_Grup4.model.enums.EstatVehicle;
import cat.copernic.Projecte2_Grup4.repository.ClientRepository;
import cat.copernic.Projecte2_Grup4.repository.ReservaRepository;
import cat.copernic.Projecte2_Grup4.repository.VehicleRepository;
import cat.copernic.Projecte2_Grup4.model.User;
import cat.copernic.Projecte2_Grup4.model.enums.Rol;

import cat.copernic.Projecte2_Grup4.model.FotoLliurament;
import cat.copernic.Projecte2_Grup4.repository.FotoLliuramentRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Servei de negoci per a la gestió de {@link Reserva} dins del sistema de
 * lloguer de vehicles.
 *
 * <p>
 * Inclou les operacions principals del cicle de vida d'una reserva:
 * <ul>
 * <li>Consulta de reserves.</li>
 * <li>Obtenció de vehicles disponibles per dates.</li>
 * <li>Creació i anul·lació de reserves, amb validacions i regles de
 * solapament.</li>
 * <li>Procés de lliurament del vehicle, amb registre de fotos.</li>
 * <li>Procés de retorn del vehicle, amb càlcul de retard i gestió de
 * desperfectes.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Algunes operacions s'executen dins d'una transacció per garantir consistència
 * entre entitats (p. ex. reserva, punts del client i fotos associades).</p>
 */
@Service
public class ReservaService {

    /**
     * Repositori d'accés a dades de {@link Reserva}.
     */
    private final ReservaRepository reservaRepository;

    /**
     * Repositori d'accés a dades de {@link Vehicle}.
     */
    private final VehicleRepository vehicleRepository;

    /**
     * Repositori d'accés a dades de {@link Client}.
     */
    private final ClientRepository clientRepository;

    // >>> RF48/RF47 (fotos lliurament)
    /**
     * Repositori d'accés a dades de {@link FotoLliurament} associades al
     * lliurament d'una reserva.
     */
    private final FotoLliuramentRepository fotoLliuramentRepository;

    /**
     * Retorna totes les reserves del sistema.
     *
     * @return llista completa de reserves
     */
    public List<Reserva> totesLesReserves() {
        return reservaRepository.findAll();
    }

    // ✅ DEIXEM UN SOL CONSTRUCTOR (per evitar errors d'Spring amb 2 constructors)
    /**
     * Constructor únic del servei per a la injecció de dependències.
     *
     * @param reservaRepository repositori de reserves
     * @param vehicleRepository repositori de vehicles
     * @param clientRepository repositori de clients
     * @param fotoLliuramentRepository repositori de fotos de lliurament
     */
    public ReservaService(ReservaRepository reservaRepository,
            VehicleRepository vehicleRepository,
            ClientRepository clientRepository,
            FotoLliuramentRepository fotoLliuramentRepository) {
        this.reservaRepository = reservaRepository;
        this.vehicleRepository = vehicleRepository;
        this.clientRepository = clientRepository;
        this.fotoLliuramentRepository = fotoLliuramentRepository;
    }

    /**
     * Retorna els vehicles disponibles per a un rang de dates.
     *
     * <p>
     * El criteri de disponibilitat és:
     * <ul>
     * <li>Vehicle amb estat {@link EstatVehicle#Disponible}.</li>
     * <li>Cap reserva solapada en el rang indicat (ignorant les reserves
     * cancel·lades).</li>
     * </ul>
     * </p>
     *
     * @param dataInici data d'inici del període
     * @param dataFi data de fi del període
     * @return llista de vehicles disponibles
     */
    public List<Vehicle> vehiclesDisponibles(LocalDate dataInici, LocalDate dataFi) {
        // 1) agafem tots els vehicles
        // 2) filtrem per estat "Disponible"
        // 3) filtrem per NO solapament amb reserves
        return vehicleRepository.findAll().stream()
                .filter(v -> v.getEstat() == EstatVehicle.Disponible) // IMPORTANT: enum exacte
                .filter(v -> reservaRepository.countReservesSolapades(
                v.getMatricule(),
                dataInici,
                dataFi,
                EstatReserva.CANCELAT
        ) == 0)
                .collect(Collectors.toList());
    }

    /**
     * Crea una nova reserva per a un client i un vehicle, amb validacions de
     * dates i disponibilitat.
     *
     * <p>
     * Regles aplicades:
     * <ul>
     * <li>DNI del client obligatori.</li>
     * <li>Dates obligatòries i coherents (dataFi no pot ser anterior a
     * dataInici).</li>
     * <li>El vehicle ha d'estar en estat {@link EstatVehicle#Disponible}.</li>
     * <li>No pot existir cap reserva solapada en el rang de dates (excloent
     * cancel·lades).</li>
     * <li>El cost total es calcula amb dies inclusius (inici i fi
     * compten).</li>
     * <li>La fiança es calcula com 7 * cost diari.</li>
     * <li>El client acumula punts segons el cost total (1 € = 1 punt,
     * truncat).</li>
     * </ul>
     * </p>
     *
     * @param dniClient DNI del client
     * @param matricula matrícula del vehicle
     * @param dataInici data d'inici de la reserva
     * @param dataFi data de fi de la reserva
     * @return reserva creada i guardada
     * @throws IllegalArgumentException si les dades són invàlides, el
     * client/vehicle no existeix o hi ha solapament
     */
    @Transactional
    public Reserva crearReserva(String dniClient, String matricula, LocalDate dataInici, LocalDate dataFi) {

        if (dniClient == null || dniClient.isBlank()) {
            throw new IllegalArgumentException("DNI client obligatori");
        }
        if (dataInici == null || dataFi == null) {
            throw new IllegalArgumentException("Dates obligatòries");
        }
        if (dataFi.isBefore(dataInici)) {
            throw new IllegalArgumentException("La data fi no pot ser anterior a la data inici");
        }

        Client client = clientRepository.findById(dniClient).orElseThrow(()
                -> new IllegalArgumentException("Client no trobat: " + dniClient));

        Vehicle vehicle = vehicleRepository.findById(matricula).orElseThrow(()
                -> new IllegalArgumentException("Vehicle no trobat: " + matricula));

        if (vehicle.getEstat() != EstatVehicle.Disponible) {
            throw new IllegalArgumentException("El vehicle no està disponible");
        }

        long solapades = reservaRepository.countReservesSolapades(
                matricula, dataInici, dataFi, EstatReserva.CANCELAT
        );
        if (solapades > 0) {
            throw new IllegalArgumentException("El vehicle ja té una reserva en aquestes dates");
        }

        double costDiari = vehicle.getCostDiari() != null ? vehicle.getCostDiari() : 0.0;

        // franja de dies: ho fem INCLUSIU (inici i fi compten)
        long dies = ChronoUnit.DAYS.between(dataInici, dataFi) + 1;
        if (dies <= 0) {
            dies = 1;
        }

        double costTotal = dies * costDiari;

        // fiança = 7 * cost diari
        double fianca = 7 * costDiari;

        // ✅ PUNTS: 1€ = 1 punt (truncat). Si el client té null, el tractem com 0.
        int puntsGuanyats = (int) Math.floor(costTotal);
        int puntsActuals = (client.getPuntsRecolectats() != null) ? client.getPuntsRecolectats() : 0;
        client.setPuntsRecolectats(puntsActuals + puntsGuanyats);
        clientRepository.save(client);

        Reserva r = new Reserva();
        r.setClient(client);
        r.setVehicle(vehicle);
        r.setDataInici(dataInici);
        r.setDataFi(dataFi);
        r.setCostTotal(costTotal);
        r.setFianca(fianca);
        r.setEstat(EstatReserva.ACTIVA);
        r.setDataCreacio(LocalDateTime.now());
        r.setCodiReserva(generarCodiReserva());

        return reservaRepository.save(r);
    }

    /**
     * Anul·la una reserva existent, aplicant validacions segons el rol de
     * l'usuari.
     *
     * <p>
     * Regles:
     * <ul>
     * <li>L'usuari actual ha d'estar informat.</li>
     * <li>Si l'usuari és {@link Rol#CLIENT}, només pot anul·lar reserves
     * pròpies.</li>
     * <li>Si l'usuari és AGENT o ADMIN, pot anul·lar qualsevol reserva.</li>
     * </ul>
     * </p>
     *
     * @param reservaId identificador de la reserva
     * @param usuariActual usuari que sol·licita l'anul·lació
     * @throws IllegalArgumentException si no hi ha usuari, la reserva no
     * existeix o no té permisos
     */
    @Transactional
    public void anularReserva(Long reservaId, User usuariActual) {

        if (usuariActual == null) {
            throw new IllegalArgumentException("Usuari no autenticat");
        }

        Reserva r = reservaRepository.findById(reservaId)
                .orElseThrow(() -> new IllegalArgumentException("Reserva no trobada"));

        // CLIENT: només pot anul·lar la seva reserva
        if (usuariActual.getRol() == Rol.CLIENT) {
            if (!r.getClient().getDni().equals(usuariActual.getDni())) {
                throw new IllegalArgumentException("No pots anul·lar una reserva que no és teva");
            }
        }
        // AGENT o ADMIN: poden anul·lar qualsevol (no fem més validacions perquè no és demanat)

        r.setEstat(EstatReserva.CANCELAT);
        reservaRepository.save(r);
    }

    /**
     * Retorna les reserves d'un client ordenades per data d'inici (descendent).
     *
     * @param dniClient DNI del client
     * @return llista de reserves del client
     */
    public List<Reserva> reservesClient(String dniClient) {
        return reservaRepository.findByClientDniOrderByDataIniciDesc(dniClient);
    }

    /**
     * Genera un codi de reserva curt i prou únic per a l'ús del projecte.
     *
     * @return codi de reserva en format "R-XXXXXXXX"
     */
    private String generarCodiReserva() {
        // curt i únic suficient per pràctica
        return "R-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    // Lliurar vehicle
    /**
     * Cerca reserves per gestionar el lliurament, filtrant per codi de reserva
     * o correu del client.
     *
     * @param codiReserva codi de reserva (opcional)
     * @param emailClient correu del client (opcional)
     * @return llista de reserves que coincideixen amb els criteris
     */
    public List<Reserva> cercarReservesPerLliurament(String codiReserva, String emailClient) {
        return reservaRepository.cercarPerCodiOEmail(
                (codiReserva != null ? codiReserva.trim() : null),
                (emailClient != null ? emailClient.trim() : null)
        );
    }

    /**
     * Retorna les fotos de lliurament associades a una reserva, ordenades per
     * data de creació (ascendent).
     *
     * @param reservaId identificador de la reserva
     * @return llista de fotos de lliurament
     */
    public List<FotoLliurament> fotosLliurament(Long reservaId) {
        return fotoLliuramentRepository.findByReservaIdOrderByDataCreacioAsc(reservaId);
    }

    /**
     * Confirma el lliurament d'un vehicle associat a una reserva i guarda les
     * fotos aportades.
     *
     * <p>
     * Registra:
     * <ul>
     * <li>Data i hora del lliurament.</li>
     * <li>Descripció de l'estat en el moment del lliurament.</li>
     * <li>Fotos adjuntes (si n'hi ha), desades com a
     * {@link FotoLliurament}.</li>
     * </ul>
     * </p>
     *
     * @param reservaId identificador de la reserva
     * @param dataHora data i hora del lliurament
     * @param descripcio descripció de l'estat del vehicle en el lliurament
     * @param fotos array de fitxers amb fotos (pot ser {@code null})
     * @throws IllegalArgumentException si la reserva no existeix o si hi ha un
     * error llegint alguna foto
     */
    @Transactional
    public void confirmarLliurament(Long reservaId, LocalDateTime dataHora, String descripcio, MultipartFile[] fotos) {
        Reserva r = reservaRepository.findById(reservaId)
                .orElseThrow(() -> new IllegalArgumentException("Reserva no trobada"));

        r.setDataHoraLliurament(dataHora);
        r.setDescripcioEstatLliurament(descripcio);

        reservaRepository.save(r);

        if (fotos != null) {
            for (MultipartFile f : fotos) {
                if (f == null || f.isEmpty()) {
                    continue;
                }
                try {
                    FotoLliurament fl = new FotoLliurament();
                    fl.setReserva(r);
                    fl.setContingut(f.getBytes());
                    fl.setContentType(f.getContentType());
                    fotoLliuramentRepository.save(fl);
                } catch (IOException e) {
                    throw new IllegalArgumentException("Error llegint foto: " + e.getMessage());
                }
            }
        }
    }

    // Retornar vehicle
    /**
     * Cerca reserves per gestionar el retorn, filtrant per codi de reserva,
     * correu del client o matrícula.
     *
     * @param codiReserva codi de reserva (opcional)
     * @param emailClient correu del client (opcional)
     * @param matricula matrícula del vehicle (opcional)
     * @return llista de reserves que coincideixen amb els criteris
     */
    public List<Reserva> cercarReservesPerRetorn(String codiReserva, String emailClient, String matricula) {
        return reservaRepository.cercarPerCodiEmailOMatricula(
                (codiReserva != null ? codiReserva.trim() : null),
                (emailClient != null ? emailClient.trim() : null),
                (matricula != null ? matricula.trim() : null)
        );
    }

    /**
     * Confirma el retorn d'un vehicle i finalitza la reserva, calculant el
     * retard i gestionant desperfectes.
     *
     * <p>
     * Comportament principal:
     * <ul>
     * <li>Enregistra la data i hora de retorn.</li>
     * <li>Calcula el retard respecte la data prevista (dataFi a les 23:59) i
     * n'obté l'import.</li>
     * <li>Marca si hi ha desperfectes i si són imputables al client.</li>
     * <li>Si hi ha desperfectes, pot crear una incidència associada al vehicle
     * mitjançant el consumidor rebut.</li>
     * <li>Finalitza la reserva establint {@link EstatReserva#FINALITZAT}.</li>
     * </ul>
     * </p>
     *
     * <p>
     * El càlcul del cost per hora de retard segueix la regla del projecte:
     * {@code costHora = costDiari / 5}.</p>
     *
     * @param reservaId identificador de la reserva
     * @param dataHoraRetorn data i hora del retorn
     * @param teDesperfectes indica si hi ha desperfectes
     * @param imputableClient indica si els desperfectes són imputables al
     * client (pot ser {@code null})
     * @param titolIncidencia títol de la incidència (opcional)
     * @param descIncidencia descripció de la incidència (opcional)
     * @param guardarIncidencia funció que s'encarrega de persistir la
     * incidència creada
     * @throws IllegalArgumentException si la reserva no existeix
     */
    @Transactional
    public void confirmarRetorn(
            Long reservaId,
            LocalDateTime dataHoraRetorn,
            boolean teDesperfectes,
            Boolean imputableClient,
            String titolIncidencia,
            String descIncidencia,
            java.util.function.Consumer<cat.copernic.Projecte2_Grup4.model.Incidencia> guardarIncidencia
    ) {
        Reserva r = reservaRepository.findById(reservaId)
                .orElseThrow(() -> new IllegalArgumentException("Reserva no trobada"));

        r.setDataHoraRetorn(dataHoraRetorn);

        // Prevista = dataFi a les 23:59 (Reserva només guarda LocalDate)
        LocalDateTime prevista = LocalDateTime.of(r.getDataFi(), LocalTime.of(23, 59));

        int horesRetard = 0;
        double importRetard = 0.0;

        if (dataHoraRetorn.isAfter(prevista)) {
            long minuts = Duration.between(prevista, dataHoraRetorn).toMinutes();
            horesRetard = (int) Math.ceil(minuts / 60.0);

            double costDiari = (r.getVehicle().getCostDiari() != null) ? r.getVehicle().getCostDiari() : 0.0;

            // ✅ Regla del teu projecte: costHora = costDiari / 5
            double costHora = costDiari / 5.0;

            importRetard = horesRetard * costHora;
        }

        r.setHoresRetard(horesRetard);
        r.setImportRetard(importRetard);

        r.setDesperfectes(teDesperfectes);

        if (!teDesperfectes) {
            r.setImputableClient(null);
            r.setFiancaRetinguda(false);
        } else {
            boolean imputable = (imputableClient != null && imputableClient);
            r.setImputableClient(imputable);

            // Si imputable al client -> retenir fiança; si no -> retornar fiança
            r.setFiancaRetinguda(imputable);

            // Crear incidència relacionada amb el vehicle
            cat.copernic.Projecte2_Grup4.model.Incidencia i = new cat.copernic.Projecte2_Grup4.model.Incidencia();
            i.setVehicle(r.getVehicle());
            i.setTitle((titolIncidencia != null && !titolIncidencia.isBlank())
                    ? titolIncidencia
                    : "Incidència retorn vehicle");
            i.setDescription(descIncidencia);
            guardarIncidencia.accept(i);
        }

        r.setEstat(EstatReserva.FINALITZAT);
        reservaRepository.save(r);
    }

    /**
     * Obté una reserva pel seu identificador.
     *
     * @param id identificador de la reserva
     * @return reserva trobada
     * @throws IllegalArgumentException si la reserva no existeix
     */
    public Reserva obtenirReservaPerId(Long id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Reserva no trobada"));
    }

}
