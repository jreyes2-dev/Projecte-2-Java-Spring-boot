package cat.copernic.Projecte2_Grup4.model.enums;

/**
 * Enumeració que representa l'estat d'una reserva.
 *
 * <p>
 * Defineix el cicle de vida d'una reserva: activa, inactiva, cancel·lada o
 * finalitzada.</p>
 */
public enum EstatReserva {
    ACTIVA,
    INACTIVA,
    CANCELAT,
    FINALITZAT
}
