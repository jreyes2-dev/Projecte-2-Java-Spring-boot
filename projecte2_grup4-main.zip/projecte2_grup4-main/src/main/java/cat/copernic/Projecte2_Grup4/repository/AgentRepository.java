package cat.copernic.Projecte2_Grup4.repository;

import cat.copernic.Projecte2_Grup4.model.Agent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AgentRepository extends JpaRepository<Agent, String> {

    boolean existsByEmail(String email);

    /**
     * Comprova si existeix algun agent amb el correu indicat, excloent un DNI
     * concret.
     *
     * <p>
     * És útil per validar unicitat de correu quan s'actualitza un agent
     * existent.</p>
     *
     * @param email correu electrònic
     * @param dni DNI a excloure de la comprovació
     * @return {@code true} si existeix un altre agent amb aquest correu;
     * {@code false} en cas contrari
     */
    boolean existsByEmailAndDniNot(String email, String dni);

    Optional<Agent> findByNomUser(String nomUser);
}
