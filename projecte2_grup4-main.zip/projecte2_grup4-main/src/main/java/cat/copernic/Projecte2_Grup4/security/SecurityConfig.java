package cat.copernic.Projecte2_Grup4.security;

import cat.copernic.Projecte2_Grup4.config.AgentInactiveAuthenticationException;
import cat.copernic.Projecte2_Grup4.config.ClientPendingAuthenticationException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

@Configuration
@EnableWebSecurity
/**
 * Configuració principal de Spring Security per a l'aplicació web.
 *
 * <p>
 * Defineix:</p>
 * <ul>
 * <li>El codificador de contrasenyes ({@link PasswordEncoder}) mitjançant
 * BCrypt.</li>
 * <li>La cadena de filtres de seguretat ({@link SecurityFilterChain}) amb les
 * regles d'autorització.</li>
 * <li>El formulari d'inici de sessió personalitzat i la gestió de tancament de
 * sessió.</li>
 * <li>El tractament d'accés denegat i algunes capçaleres de seguretat.</li>
 * </ul>
 *
 * <p>
 * Nota: es desactiva CSRF perquè l'aplicació utilitza formularis Thymeleaf
 * sense tokens CSRF als templates, evitant així respostes 403 en peticions
 * POST.</p>
 */
public class SecurityConfig {

    /**
     * Bean del codificador de contrasenyes basat en BCrypt.
     *
     * @return implementació {@link PasswordEncoder}
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Defineix la configuració de seguretat HTTP de l'aplicació.
     *
     * <p>
     * Inclou:</p>
     * <ul>
     * <li>Desactivació de CSRF.</li>
     * <li>Regles d'accés per rols a diferents rutes.</li>
     * <li>Form login amb pàgina personalitzada.</li>
     * <li>Logout i pàgines de redirecció.</li>
     * <li>Gestió d'errors d'autorització.</li>
     * <li>Algunes capçaleres (Content-Type-Options i Frame-Options).</li>
     * </ul>
     *
     * @param http configurador de seguretat HTTP
     * @return {@link SecurityFilterChain} construïda
     * @throws Exception si hi ha errors en la configuració de seguretat
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable());

        http.authorizeHttpRequests(auth -> auth
                .requestMatchers(
                        "/", "/home",
                        "/web/login",
                        "/web/register", "/web/register/**",
                        "/web/pendent",
                        "/web/denegada-registre",
                        "/web/access-denied",
                        "/css/**", "/js/**", "/images/**", "/webjars/**"
                ).permitAll()
                .requestMatchers("/web/agents/**", "/web/localitzacions/**").hasRole("ADMIN")
                .requestMatchers("/web/clients/**").hasAnyRole("AGENT", "ADMIN")
                .requestMatchers("/web/operacions/**").hasAnyRole("AGENT", "ADMIN")
                .anyRequest().authenticated()
        );

        AuthenticationFailureHandler failureHandler = (request, response, exception) -> {

            if (exception instanceof ClientPendingAuthenticationException) {
                response.sendRedirect("/web/pendent");
                return;
            }
        if (exception instanceof AgentInactiveAuthenticationException) {
            response.sendRedirect("/web/login?inactive");
            return;
        }

        String msg = exception != null ? exception.getMessage() : "";
        if ("CLIENT_PENDENT".equals(msg)) {
            response.sendRedirect("/web/pendent");
            return;
        }
        if ("CLIENT_DENEGAT".equals(msg)) {
            response.sendRedirect("/web/denegada-registre");
            return;
        }
        if ("AGENT_INACTIU".equals(msg)) {
            response.sendRedirect("/web/login?inactive");
            return;
        }

        response.sendRedirect("/web/login?error");
    }

    ;

    http.formLogin (form 

    -> form
                .loginPage("/web/login")
                .loginProcessingUrl("/web/login")
                .usernameParameter("nomUser")
                .passwordParameter("contrasenya")
                .defaultSuccessUrl("/", true)
                .failureHandler(failureHandler)
                .permitAll()
        );

    http.logout (logout 

    -> logout
                .logoutUrl("/web/logout")
                .logoutSuccessUrl("/web/login?logout")
        );

    http.exceptionHandling (ex 

    -> ex
                .accessDeniedPage("/web/access-denied")
        );

    http.headers (headers 

    -> headers
                .contentTypeOptions(Customizer.withDefaults())
                .frameOptions(frame -> frame.sameOrigin())
        );

        return http.build ();
}

}
