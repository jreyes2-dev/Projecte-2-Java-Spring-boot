package cat.copernic.Projecte2_Grup4.model.enums;

/**
 * Enumeració que representa l'estat d'un vehicle.
 *
 * <p>
 * Indica si el vehicle està disponible per ser reservat o no disponible.</p>
 */
public enum EstatVehicle {
    Disponible,
    No_Disponible
}
