package cat.copernic.Projecte2_Grup4.model;

import cat.copernic.Projecte2_Grup4.model.enums.Estat;
import cat.copernic.Projecte2_Grup4.model.enums.EstatAgent;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@DiscriminatorValue("AGENT")
/**
 * Entitat que representa un agent del sistema.
 *
 * <p>
 * Un agent és un tipus de client amb capacitats operatives addicionals i un
 * estat propi ({@link EstatAgent}) que permet controlar si està actiu. També
 * pot estar associat a una {@link Localitzacio} concreta, per tal d'indicar el
 * punt o oficina on opera.</p>
 *
 * <p>
 * Per defecte, quan es crea un agent, l'estat general de l'usuari s'estableix a
 * {@link Estat#ACEPTAT} i l'estat d'agent a {@link EstatAgent#ACTIU}.</p>
 */
public class Agent extends Client {

    @Enumerated(EnumType.STRING)
    @Column(name = "estat_agent", length = 10)
    private EstatAgent estatAgent = EstatAgent.ACTIU;

    @OneToOne
    @JoinColumn(name = "codiPostal")
    private Localitzacio localitzacio;

    /**
     * Constructor per defecte.
     *
     * <p>
     * Inicialitza l'agent amb l'estat general {@link Estat#ACEPTAT}.</p>
     */
    public Agent() {
        super();
        this.setEstat(Estat.ACEPTAT);
    }

    /**
     * Constructor amb dades bàsiques de client i associació a localització.
     *
     * @param localitzacio localització associada a l'agent
     * @param dni DNI de l'usuari
     * @param nom nom
     * @param cognom1 primer cognom
     * @param cognom2 segon cognom
     * @param adreca adreça
     * @param nomUser nom d'usuari
     * @param email correu electrònic
     * @param contrasenya contrasenya
     * @param tipusLlicenciaConduir tipus de llicència de conduir
     * @param numeroTargetaCredit número de targeta de crèdit
     * @param dataCaducitatIdentificacio data de caducitat del document
     * d'identificació
     * @param dataCaducitatLlicencia data de caducitat de la llicència de
     * conduir
     */
    public Agent(Localitzacio localitzacio, String dni, String nom, String cognom1, String cognom2, String adreca, String nomUser, String email, String contrasenya, String tipusLlicenciaConduir, String numeroTargetaCredit, LocalDate dataCaducitatIdentificacio, LocalDate dataCaducitatLlicencia) {
        super(dni, nom, cognom1, cognom2, adreca, nomUser, email, contrasenya, tipusLlicenciaConduir, numeroTargetaCredit, dataCaducitatIdentificacio, dataCaducitatLlicencia);
        this.localitzacio = localitzacio;
        this.estatAgent = EstatAgent.ACTIU;
        this.setEstat(Estat.ACEPTAT);
    }

    /**
     * Constructor complet, incloent informació addicional d'usuari i associació
     * a localització.
     *
     * @param localitzacio localització associada a l'agent
     * @param puntsRecolectats punts acumulats
     * @param estat estat general de l'usuari
     * @param telefon telèfon
     * @param dataNaixement data de naixement
     * @param dni DNI de l'usuari
     * @param nom nom
     * @param cognom1 primer cognom
     * @param cognom2 segon cognom
     * @param adreca adreça
     * @param nomUser nom d'usuari
     * @param email correu electrònic
     * @param contrasenya contrasenya
     * @param tipusLlicenciaConduir tipus de llicència de conduir
     * @param numeroTargetaCredit número de targeta de crèdit
     * @param dataCaducitatIdentificacio data de caducitat del document
     * d'identificació
     * @param dataCaducitatLlicencia data de caducitat de la llicència de
     * conduir
     */
    public Agent(Localitzacio localitzacio, Integer puntsRecolectats, Estat estat, String telefon, LocalDate dataNaixement, String dni, String nom, String cognom1, String cognom2, String adreca, String nomUser, String email, String contrasenya, String tipusLlicenciaConduir, String numeroTargetaCredit, LocalDate dataCaducitatIdentificacio, LocalDate dataCaducitatLlicencia) {
        super(puntsRecolectats, estat, telefon, dataNaixement, dni, nom, cognom1, cognom2, adreca, nomUser, email, contrasenya, tipusLlicenciaConduir, numeroTargetaCredit, dataCaducitatIdentificacio, dataCaducitatLlicencia);
        this.localitzacio = localitzacio;
        this.estatAgent = EstatAgent.ACTIU;
    }

    /**
     * Retorna l'estat de l'agent.
     *
     * <p>
     * Si el camp és {@code null}, es retorna {@link EstatAgent#ACTIU} per
     * defecte.</p>
     *
     * @return estat de l'agent
     */
    public EstatAgent getEstatAgent() {
        if (estatAgent == null) {
            return EstatAgent.ACTIU;
        }
        return estatAgent;
    }

    /**
     * Assigna l'estat de l'agent.
     *
     * @param estatAgent nou estat de l'agent
     */
    public void setEstatAgent(EstatAgent estatAgent) {
        this.estatAgent = estatAgent;
    }

    /**
     * Retorna la localització associada a l'agent.
     *
     * @return localització de l'agent
     */
    public Localitzacio getLocalitzacio() {
        return localitzacio;
    }

    /**
     * Assigna la localització associada a l'agent.
     *
     * @param localitzacio nova localització de l'agent
     */
    public void setLocalitzacio(Localitzacio localitzacio) {
        this.localitzacio = localitzacio;
    }
}
