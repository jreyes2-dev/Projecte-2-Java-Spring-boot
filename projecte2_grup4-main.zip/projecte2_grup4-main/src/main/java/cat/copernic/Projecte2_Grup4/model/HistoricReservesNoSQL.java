package cat.copernic.Projecte2_Grup4.model;

import jakarta.persistence.Id;
import java.time.LocalDateTime;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 *
 * @author panie
 */
@Document(collection = "HistoricReserves")
/**
 * Document NoSQL que registra l'històric de canvis d'estat i imports d'una
 * reserva.
 *
 * <p>
 * La col·lecció {@code HistoricReserves} emmagatzema registres d'auditoria
 * associats a una reserva, indicant l'estat anterior i el nou estat, així com
 * possibles canvis en l'import.</p>
 *
 * <p>
 * També es registra la data del canvi, un comentari i l'usuari responsable que
 * ha realitzat l'acció.</p>
 */
public class HistoricReservesNoSQL {

    @Id
    private String idHistorial;

    private Integer idReserva;
    private LocalDateTime dataCanvi;

    private EstatReserva estatAnterior;
    private EstatReserva estatNou;

    private String comentari;
    private String userResponsable;

    private Double importAnterior;
    private Double importNou;

    /**
     * Enumeració d'estats possibles d'una reserva dins l'històric.
     */
    public enum EstatReserva {
        ACTIVA,
        INACTIVA,
        CANCELAT,
        FINALITZADA
    }

    /**
     * Constructor per defecte.
     */
    public HistoricReservesNoSQL() {
    }

    /**
     * Constructor complet de l'històric de reserves.
     *
     * @param idHistorial identificador del registre històric
     * @param idReserva identificador de la reserva
     * @param dataCanvi data i hora del canvi
     * @param estatAnterior estat anterior de la reserva
     * @param estatNou nou estat de la reserva
     * @param comentari comentari associat al canvi (opcional)
     * @param userResponsable usuari responsable del canvi
     * @param importAnterior import anterior (opcional)
     * @param importNou nou import (opcional)
     */
    public HistoricReservesNoSQL(String idHistorial, Integer idReserva, LocalDateTime dataCanvi, EstatReserva estatAnterior, EstatReserva estatNou, String comentari, String userResponsable, Double importAnterior, Double importNou) {
        this.idHistorial = idHistorial;
        this.idReserva = idReserva;
        this.dataCanvi = dataCanvi;
        this.estatAnterior = estatAnterior;
        this.estatNou = estatNou;
        this.comentari = comentari;
        this.userResponsable = userResponsable;
        this.importAnterior = importAnterior;
        this.importNou = importNou;
    }

    /**
     * Retorna l'identificador del registre històric.
     *
     * @return id de l'historial
     */
    public String getIdHistorial() {
        return idHistorial;
    }

    /**
     * Assigna l'identificador del registre històric.
     *
     * @param idHistorial id de l'historial
     */
    public void setIdHistorial(String idHistorial) {
        this.idHistorial = idHistorial;
    }

    /**
     * Retorna l'identificador de la reserva associada.
     *
     * @return id de la reserva
     */
    public Integer getIdReserva() {
        return idReserva;
    }

    /**
     * Assigna l'identificador de la reserva associada.
     *
     * @param idReserva id de la reserva
     */
    public void setIdReserva(Integer idReserva) {
        this.idReserva = idReserva;
    }

    /**
     * Retorna la data i hora del canvi.
     *
     * @return data del canvi
     */
    public LocalDateTime getDataCanvi() {
        return dataCanvi;
    }

    /**
     * Assigna la data i hora del canvi.
     *
     * @param dataCanvi nova data del canvi
     */
    public void setDataCanvi(LocalDateTime dataCanvi) {
        this.dataCanvi = dataCanvi;
    }

    /**
     * Retorna l'estat anterior de la reserva.
     *
     * @return estat anterior
     */
    public EstatReserva getEstatAnterior() {
        return estatAnterior;
    }

    /**
     * Assigna l'estat anterior de la reserva.
     *
     * @param estatAnterior estat anterior
     */
    public void setEstatAnterior(EstatReserva estatAnterior) {
        this.estatAnterior = estatAnterior;
    }

    /**
     * Retorna el nou estat de la reserva.
     *
     * @return nou estat
     */
    public EstatReserva getEstatNou() {
        return estatNou;
    }

    /**
     * Assigna el nou estat de la reserva.
     *
     * @param estatNou nou estat
     */
    public void setEstatNou(EstatReserva estatNou) {
        this.estatNou = estatNou;
    }

    /**
     * Retorna el comentari associat al canvi.
     *
     * @return comentari
     */
    public String getComentari() {
        return comentari;
    }

    /**
     * Assigna el comentari associat al canvi.
     *
     * @param comentari comentari
     */
    public void setComentari(String comentari) {
        this.comentari = comentari;
    }

    /**
     * Retorna l'usuari responsable del canvi.
     *
     * @return usuari responsable
     */
    public String getUserResponsable() {
        return userResponsable;
    }

    /**
     * Assigna l'usuari responsable del canvi.
     *
     * @param userResponsable usuari responsable
     */
    public void setUserResponsable(String userResponsable) {
        this.userResponsable = userResponsable;
    }

    /**
     * Retorna l'import anterior associat al canvi.
     *
     * @return import anterior
     */
    public Double getImportAnterior() {
        return importAnterior;
    }

    /**
     * Assigna l'import anterior associat al canvi.
     *
     * @param importAnterior import anterior
     */
    public void setImportAnterior(Double importAnterior) {
        this.importAnterior = importAnterior;
    }

    /**
     * Retorna el nou import associat al canvi.
     *
     * @return import nou
     */
    public Double getImportNou() {
        return importNou;
    }

    /**
     * Assigna el nou import associat al canvi.
     *
     * @param importNou import nou
     */
    public void setImportNou(Double importNou) {
        this.importNou = importNou;
    }
}
