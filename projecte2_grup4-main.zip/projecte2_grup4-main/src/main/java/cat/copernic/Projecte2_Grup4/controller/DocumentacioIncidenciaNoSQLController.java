package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.model.DocumentacioIncidenciaNoSQL;
import cat.copernic.Projecte2_Grup4.model.Incidencia;
import cat.copernic.Projecte2_Grup4.service.DocumentacioIncidenciaNoSQLService;
import cat.copernic.Projecte2_Grup4.service.IncidenciaService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Controlador MVC encarregat de la gestió de documentació associada a
 * incidències, emmagatzemada en un repositori NoSQL (p. ex. MongoDB).
 *
 * <p>
 * <b>Cas d'ús:</b> quan un vehicle té una incidència (danys, accident,
 * reparació), el sistema permet adjuntar evidències i documents (fotos i PDFs),
 * consultar-los i descarregar-los.</p>
 *
 * <p>
 * <b>Funcionalitats:</b>
 * <ul>
 * <li>Llistar incidències i carregar la documentació d'una incidència
 * seleccionada.</li>
 * <li>Pujar fitxers (fotos de danys, comunicat d'accident, informe de taller,
 * fotos de reparació).</li>
 * <li>Eliminar documentació completa o fitxers concrets.</li>
 * <li>Visualitzar fitxers en línia (inline) i descarregar-los individualment o
 * en ZIP.</li>
 * </ul>
 *
 * <p>
 * <b>Seguretat i permisos:</b> el comportament es diferencia entre ADMIN i
 * AGENT:
 * <ul>
 * <li><b>ADMIN</b> pot veure totes les incidències.</li>
 * <li><b>AGENT</b> només veu incidències creades per ell o assignades a
 * ell.</li>
 * </ul>
 *
 * <p>
 * Aquest controlador mostra gestió de fitxers binaris (upload/download),
 * control d'accés per rol, i empaquetat ZIP per facilitar l'exportació
 * d'evidències.</p>
 */
/**
 * Controlador web.
 */
@Controller
@RequestMapping("/web/incidencies/documentacio")
public class DocumentacioIncidenciaNoSQLController {

    /**
     * Servei de documentació (NoSQL): encapsula la lògica de pujada,
     * validacions i persistència de binaris.
     */
    private final DocumentacioIncidenciaNoSQLService docService;

    /**
     * Servei d'incidències (relacional/negoci): aporta la llista d'incidències
     * i dades complementàries.
     */
    private final IncidenciaService incidenciaService;

    /**
     * Constructor amb injecció de dependències.
     *
     * @param docService servei de documentació NoSQL
     * @param incidenciaService servei d'incidències
     */
    public DocumentacioIncidenciaNoSQLController(DocumentacioIncidenciaNoSQLService docService,
            IncidenciaService incidenciaService) {
        this.docService = docService;
        this.incidenciaService = incidenciaService;
    }

    /**
     * Mostra la pantalla principal de documentació d'incidències.
     *
     * <p>
     * Comportament:</p>
     * <ul>
     * <li>Si l'usuari és ADMIN: mostra totes les incidències.</li>
     * <li>Si és AGENT: filtra incidències creades o assignades a l'agent.</li>
     * <li>Si s'indica {@code idIncidencia}: carrega la documentació i dades de
     * l'incidència seleccionada.</li>
     * </ul>
     *
     * <p>
     * També calcula si la incidència està inactiva (per deshabilitar accions a
     * la vista).</p>
     *
     * @param idIncidencia identificador d'incidència seleccionada (opcional)
     * @param model model MVC per passar dades a la vista
     * @return vista de gestió de documentació
     */
    @GetMapping("/llistar")
    public String llistar(@RequestParam(name = "idIncidencia", required = false) String idIncidencia,
            Model model) {

        boolean esAdmin = isAdmin();
        String usuariSel = esAdmin ? "" : currentUsername();

        List<Incidencia> incidencies = incidenciaService.llistarTotesIncidencies();
        if (!esAdmin) {
            String u = usuariSel;
            incidencies = incidencies.stream()
                    .filter(i -> (i.getCreadoPor() != null && i.getCreadoPor().equalsIgnoreCase(u))
                    || (i.getAssignadaA() != null && i.getAssignadaA().equalsIgnoreCase(u)))
                    .toList();
        }

        String idSel = Optional.ofNullable(idIncidencia).orElse("").trim();
        DocumentacioIncidenciaNoSQL doc = null;
        if (!idSel.isEmpty()) {
            doc = docService.obtenirPerIdIncidencia(idSel);
        }

        Incidencia incidenciaSel = null;
        boolean incidenciaInactiva = false;
        if (!idSel.isEmpty()) {
            try {
                incidenciaSel = incidenciaService.obtenirIncidenciaPerld(Integer.parseInt(idSel));
                if (incidenciaSel != null && incidenciaSel.getEstat() != null) {
                    incidenciaInactiva = "Inactiva".equalsIgnoreCase(incidenciaSel.getEstat().name());
                }
            } catch (Exception ignored) {
                // Si l'id no és parsejable o no existeix, no es carrega incidència seleccionada.
            }
        }

        model.addAttribute("esAdmin", esAdmin);
        model.addAttribute("rolActual", rolActual());
        model.addAttribute("usuari", usuariSel);
        model.addAttribute("incidencies", incidencies);
        model.addAttribute("idIncidencia", idSel);
        model.addAttribute("doc", doc);
        model.addAttribute("incidenciaSel", incidenciaSel);
        model.addAttribute("incidenciaInactiva", incidenciaInactiva);

        return "incidencies/documentacio-incidencies";
    }

    /**
     * Desa (afegeix) fitxers a la documentació d'una incidència.
     *
     * <p>
     * Admet diferents tipus de fitxers: fotos de danys, comunicat d'accident
     * (PDF), informe de taller (PDF) i fotos de reparació.</p>
     *
     * <p>
     * El servei retorna un objecte amb avisos (duplicats/ignorats) que es
     * mostren com a missatge a l'usuari.</p>
     *
     * @param idIncidencia id de la incidència
     * @param fotosDany llista de fotos de danys (opcional)
     * @param comunicatAccident fitxer del comunicat (opcional)
     * @param informeTaller fitxer de l'informe de taller (opcional)
     * @param fotosReparacio llista de fotos de reparació (opcional)
     * @param ra atributs flash per missatges d'èxit/avís/error
     * @return redirecció a la pantalla de llistat mantenint la incidència
     * seleccionada
     */
    @PostMapping("/guardar")
    public String guardar(@RequestParam(name = "idIncidencia") String idIncidencia,
            @RequestParam(name = "fotosDany", required = false) List<MultipartFile> fotosDany,
            @RequestParam(name = "comunicatAccident", required = false) MultipartFile comunicatAccident,
            @RequestParam(name = "informeTaller", required = false) MultipartFile informeTaller,
            @RequestParam(name = "fotosReparacio", required = false) List<MultipartFile> fotosReparacio,
            RedirectAttributes ra) {

        String id = (idIncidencia == null) ? "" : idIncidencia.trim();

        try {
            DocumentacioIncidenciaNoSQLService.AfegirFitxersResult res
                    = docService.afegirFitxers(id, fotosDany, comunicatAccident, informeTaller, fotosReparacio);

            if (res != null && res.teAvisos()) {
                StringBuilder sb = new StringBuilder("⚠️ Alguns fitxers no s'han pujat:");
                if (res.getDuplicats() != null && !res.getDuplicats().isEmpty()) {
                    sb.append(" Duplicats: ").append(String.join(", ", res.getDuplicats())).append(".");
                }
                if (res.getIgnorats() != null && !res.getIgnorats().isEmpty()) {
                    sb.append(" Ignorats: ").append(String.join(", ", res.getIgnorats())).append(".");
                }
                afegirMissatgeError(ra, sb.toString());
            } else {
                afegirMissatgeExit(ra, "✅ Fitxers pujats correctament.");
            }

        } catch (IllegalArgumentException e) {
            afegirMissatgeError(ra, "❌ " + e.getMessage());
        } catch (IOException e) {
            afegirMissatgeError(ra, "❌ Error llegint fitxers: " + e.getMessage());
        } catch (Exception e) {
            afegirMissatgeError(ra, "❌ Error inesperat: " + e.getMessage());
        }

        return "redirect:/web/incidencies/documentacio/llistar?idIncidencia=" + id;
    }

    /**
     * Elimina la documentació completa d'una incidència.
     *
     * @param idIncidencia id de la incidència
     * @param ra atributs flash per mostrar el resultat a l'usuari
     * @return redirecció a la pantalla de llistat
     */
    @PostMapping("/eliminar")
    public String eliminar(@RequestParam(name = "idIncidencia") String idIncidencia,
            RedirectAttributes ra) {
        try {
            docService.eliminar(idIncidencia != null ? idIncidencia.trim() : "");
            afegirMissatgeExit(ra, "✅ Documentació eliminada correctament!");
        } catch (Exception e) {
            afegirMissatgeError(ra, "❌ Error: " + e.getMessage());
        }
        return "redirect:/web/incidencies/documentacio/llistar";
    }

    /**
     * Elimina un fitxer concret d'una incidència.
     *
     * <p>
     * El paràmetre {@code tipus} determina quin conjunt s'està manipulant:
     * comunicat, informe, fotosDany o fotosReparacio. En el cas de llistes de
     * fotos, s'utilitza {@code index} per indicar la posició.</p>
     *
     * @param idIncidencia id de la incidència
     * @param tipus tipus de fitxer a eliminar
     * @param index índex de la foto (opcional, només per col·leccions)
     * @param ra atributs flash per missatges
     * @return redirecció a la pantalla de llistat mantenint la selecció
     */
    @PostMapping("/eliminar-fitxer")
    public String eliminarFitxer(@RequestParam("idIncidencia") String idIncidencia,
            @RequestParam("tipus") String tipus,
            @RequestParam(name = "index", required = false) Integer index,
            RedirectAttributes ra) {

        String id = (idIncidencia == null) ? "" : idIncidencia.trim();

        try {
            docService.eliminarFitxer(id, tipus, index);
            afegirMissatgeExit(ra, "✅ Fitxer eliminat correctament!");
        } catch (Exception e) {
            afegirMissatgeError(ra, "❌ Error: " + e.getMessage());
        }

        return "redirect:/web/incidencies/documentacio/llistar?idIncidencia=" + id;
    }

    /**
     * Substitueix (canvia) un fitxer concret de la documentació d'una
     * incidència.
     *
     * @param idIncidencia id de la incidència
     * @param tipus tipus de fitxer (comunicat, informe, fotosDany,
     * fotosReparacio)
     * @param index índex (opcional, per col·leccions de fotos)
     * @param fitxer nou fitxer a desar
     * @param ra atributs flash per missatges
     * @return redirecció a la pantalla de llistat mantenint la selecció
     */
    @PostMapping("/canviar-fitxer")
    public String canviarFitxer(@RequestParam("idIncidencia") String idIncidencia,
            @RequestParam("tipus") String tipus,
            @RequestParam(name = "index", required = false) Integer index,
            @RequestParam("fitxer") MultipartFile fitxer,
            RedirectAttributes ra) {

        String id = (idIncidencia == null) ? "" : idIncidencia.trim();

        try {
            docService.canviarFitxer(id, tipus, index, fitxer);
            afegirMissatgeExit(ra, "✅ Fitxer actualitzat correctament!");
        } catch (IllegalArgumentException e) {
            afegirMissatgeError(ra, "❌ " + e.getMessage());
        } catch (Exception e) {
            afegirMissatgeError(ra, "❌ Error: " + e.getMessage());
        }

        return "redirect:/web/incidencies/documentacio/llistar?idIncidencia=" + id;
    }

    /**
     * Visualitza un fitxer (inline) al navegador.
     *
     * <p>
     * Fa servir {@link HttpHeaders#CONTENT_DISPOSITION} amb {@code inline}
     * perquè el navegador intenti mostrar el contingut (PDF/imatge) en lloc de
     * descarregar-lo.</p>
     *
     * @param idIncidencia id de la incidència
     * @param tipus tipus de fitxer (comunicat, informe, fotosDany,
     * fotosReparacio)
     * @param index índex per a llistes de fotos (per defecte 0)
     * @return {@link ResponseEntity} amb el binari i el tipus MIME
     * corresponent, o error 404/400
     */
    @GetMapping("/veure/{idIncidencia}/{tipus}")
    public ResponseEntity<byte[]> veure(@PathVariable("idIncidencia") String idIncidencia,
            @PathVariable("tipus") String tipus,
            @RequestParam(name = "index", required = false, defaultValue = "0") int index) {

        DocumentacioIncidenciaNoSQL doc = docService.obtenirPerIdIncidencia(idIncidencia);
        if (doc == null) {
            return ResponseEntity.notFound().build();
        }

        byte[] contingut = null;
        String contentType = "application/octet-stream";
        String nomFitxer = "fitxer";

        switch (tipus) {
            case "comunicat" -> {
                contingut = doc.getComunicatAccident();
                contentType = doc.getComunicatAccidentContentType();
                nomFitxer = doc.getComunicatAccidentNom();
            }
            case "informe" -> {
                contingut = doc.getInformeTaller();
                contentType = doc.getInformeTallerContentType();
                nomFitxer = doc.getInformeTallerNom();
            }
            case "fotosDany" -> {
                if (doc.getFotosDany() == null || index < 0 || index >= doc.getFotosDany().size()) {
                    return ResponseEntity.notFound().build();
                }
                contingut = doc.getFotosDany().get(index);
                if (doc.getFotosDanyContentTypes() != null && index < doc.getFotosDanyContentTypes().size()) {
                    contentType = doc.getFotosDanyContentTypes().get(index);
                } else {
                    contentType = "image/*";
                }
                if (doc.getFotosDanyNoms() != null && index < doc.getFotosDanyNoms().size()) {
                    nomFitxer = doc.getFotosDanyNoms().get(index);
                }
            }
            case "fotosReparacio" -> {
                if (doc.getFotosReparacio() == null || index < 0 || index >= doc.getFotosReparacio().size()) {
                    return ResponseEntity.notFound().build();
                }
                contingut = doc.getFotosReparacio().get(index);
                if (doc.getFotosReparacioContentTypes() != null && index < doc.getFotosReparacioContentTypes().size()) {
                    contentType = doc.getFotosReparacioContentTypes().get(index);
                } else {
                    contentType = "image/*";
                }
                if (doc.getFotosReparacioNoms() != null && index < doc.getFotosReparacioNoms().size()) {
                    nomFitxer = doc.getFotosReparacioNoms().get(index);
                }
            }
            default -> {
                return ResponseEntity.badRequest().build();
            }
        }

        if (contingut == null) {
            return ResponseEntity.notFound().build();
        }

        String safeName = (nomFitxer == null || nomFitxer.isBlank()) ? "fitxer" : nomFitxer.replace("\"", "");
        String safeType = (contentType == null || contentType.isBlank()) ? "application/octet-stream" : contentType;

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + safeName + "\"")
                .contentType(MediaType.parseMediaType(safeType))
                .body(contingut);
    }

    /**
     * Descarrega tota la documentació d'una incidència en un fitxer ZIP.
     *
     * <p>
     * Inclou, si existeixen: comunicat, informe, fotos de danys i fotos de
     * reparació, organitzant les fotos en carpetes.</p>
     *
     * @param idIncidencia id de la incidència
     * @return ZIP com a binari o 404 si no existeix documentació
     */
    /**
     * Executa l'operació.
     *
     * @param idIncidencia paràmetre
     * @return resultat
     */
    @GetMapping("/descarregar-tot/{idIncidencia}")
    public ResponseEntity<byte[]> descarregarTot(@PathVariable("idIncidencia") String idIncidencia) {

        DocumentacioIncidenciaNoSQL doc = docService.obtenirPerIdIncidencia(idIncidencia);
        if (doc == null) {
            return ResponseEntity.notFound().build();
        }

        try {
            byte[] zipBytes = crearZipDocumentacio(idIncidencia, doc);
            String filename = "documentacio_incidencia_" + idIncidencia + ".zip";

            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType("application/zip"))
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                    .body(zipBytes);

        } catch (IOException e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Descarrega un fitxer concret de la documentació d'una incidència.
     *
     * <p>
     * A diferència de {@link #veure(String, String, int)}, aquest endpoint
     * força la descàrrega amb {@code attachment}.</p>
     *
     * @param idIncidencia id de la incidència
     * @param tipus tipus de fitxer (comunicat, informe, fotosDany,
     * fotosReparacio)
     * @param index índex per col·leccions de fotos (per defecte 0)
     * @return binari del fitxer o 404 si no existeix
     */
    @GetMapping("/descarregar/{idIncidencia}/{tipus}")
    public ResponseEntity<byte[]> descarregar(@PathVariable("idIncidencia") String idIncidencia,
            @PathVariable("tipus") String tipus,
            @RequestParam(name = "index", required = false, defaultValue = "0") int index) {

        DocumentacioIncidenciaNoSQL doc = docService.obtenirPerIdIncidencia(idIncidencia);
        if (doc == null) {
            return ResponseEntity.notFound().build();
        }

        byte[] bytes = null;
        String filename = tipus;
        MediaType mediaType = MediaType.APPLICATION_OCTET_STREAM;

        switch (tipus) {
            case "comunicat" -> {
                bytes = doc.getComunicatAccident();
                filename = (doc.getComunicatAccidentNom() != null && !doc.getComunicatAccidentNom().isBlank())
                        ? doc.getComunicatAccidentNom()
                        : ("comunicat_accident_" + idIncidencia + ".pdf");
                mediaType = MediaType.APPLICATION_PDF;
            }
            case "informe" -> {
                bytes = doc.getInformeTaller();
                filename = (doc.getInformeTallerNom() != null && !doc.getInformeTallerNom().isBlank())
                        ? doc.getInformeTallerNom()
                        : ("informe_taller_" + idIncidencia + ".pdf");
                mediaType = MediaType.APPLICATION_PDF;
            }
            case "fotosDany" -> {
                if (doc.getFotosDany() != null && index >= 0 && index < doc.getFotosDany().size()) {
                    bytes = doc.getFotosDany().get(index);
                    filename = (doc.getFotosDanyNoms() != null && index < doc.getFotosDanyNoms().size()
                            && doc.getFotosDanyNoms().get(index) != null && !doc.getFotosDanyNoms().get(index).isBlank())
                            ? doc.getFotosDanyNoms().get(index)
                            : ("foto_dany_" + idIncidencia + "_" + index + ".jpg");
                    mediaType = MediaType.APPLICATION_OCTET_STREAM;
                }
            }
            case "fotosReparacio" -> {
                if (doc.getFotosReparacio() != null && index >= 0 && index < doc.getFotosReparacio().size()) {
                    bytes = doc.getFotosReparacio().get(index);
                    filename = (doc.getFotosReparacioNoms() != null && index < doc.getFotosReparacioNoms().size()
                            && doc.getFotosReparacioNoms().get(index) != null && !doc.getFotosReparacioNoms().get(index).isBlank())
                            ? doc.getFotosReparacioNoms().get(index)
                            : ("foto_reparacio_" + idIncidencia + "_" + index + ".jpg");
                    mediaType = MediaType.APPLICATION_OCTET_STREAM;
                }
            }
            default -> {
                // Tipus desconegut: es retornarà 404 perquè bytes seguirà sent null.
            }
        }

        if (bytes == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
                .contentType(mediaType)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .body(bytes);
    }

    /**
     * Construeix un ZIP amb tots els fitxers disponibles a la documentació.
     *
     * <p>
     * Estructura suggerida:
     * <ul>
     * <li>Documents a l'arrel (PDFs).</li>
     * <li>Fotos dins carpetes {@code fotos_dany/} i
     * {@code fotos_reparacio/}.</li>
     * </ul></p>
     *
     * @param idIncidencia id de la incidència (per construir noms per defecte)
     * @param doc documentació recuperada de NoSQL
     * @return bytes del ZIP
     * @throws IOException si hi ha errors d'escriptura del ZIP
     */
    private byte[] crearZipDocumentacio(String idIncidencia, DocumentacioIncidenciaNoSQL doc) throws IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream(); ZipOutputStream zos = new ZipOutputStream(baos)) {

            if (doc.getComunicatAccident() != null && doc.getComunicatAccident().length > 0) {
                String nomCom = (doc.getComunicatAccidentNom() != null && !doc.getComunicatAccidentNom().isBlank())
                        ? doc.getComunicatAccidentNom()
                        : ("comunicat_accident_" + idIncidencia + ".pdf");
                afegirEntry(zos, nomCom, doc.getComunicatAccident());
            }

            if (doc.getInformeTaller() != null && doc.getInformeTaller().length > 0) {
                String nomInf = (doc.getInformeTallerNom() != null && !doc.getInformeTallerNom().isBlank())
                        ? doc.getInformeTallerNom()
                        : ("informe_taller_" + idIncidencia + ".pdf");
                afegirEntry(zos, nomInf, doc.getInformeTaller());
            }

            if (doc.getFotosDany() != null) {
                for (int i = 0; i < doc.getFotosDany().size(); i++) {
                    byte[] b = doc.getFotosDany().get(i);
                    if (b != null && b.length > 0) {
                        String n = (doc.getFotosDanyNoms() != null && i < doc.getFotosDanyNoms().size()
                                && doc.getFotosDanyNoms().get(i) != null && !doc.getFotosDanyNoms().get(i).isBlank())
                                ? doc.getFotosDanyNoms().get(i)
                                : ("foto_dany_" + idIncidencia + "_" + i + ".jpg");
                        afegirEntry(zos, "fotos_dany/" + n, b);
                    }
                }
            }

            if (doc.getFotosReparacio() != null) {
                for (int i = 0; i < doc.getFotosReparacio().size(); i++) {
                    byte[] b = doc.getFotosReparacio().get(i);
                    if (b != null && b.length > 0) {
                        String n = (doc.getFotosReparacioNoms() != null && i < doc.getFotosReparacioNoms().size()
                                && doc.getFotosReparacioNoms().get(i) != null && !doc.getFotosReparacioNoms().get(i).isBlank())
                                ? doc.getFotosReparacioNoms().get(i)
                                : ("foto_reparacio_" + idIncidencia + "_" + i + ".jpg");
                        afegirEntry(zos, "fotos_reparacio/" + n, b);
                    }
                }
            }

            zos.finish();
            return baos.toByteArray();
        }
    }

    /**
     * Afegeix una entrada al ZIP amb el nom indicat i el seu contingut.
     *
     * @param zos stream ZIP obert
     * @param nom nom de l'entrada (pot incloure subcarpetes)
     * @param contingut bytes del fitxer
     * @throws IOException si hi ha errors d'escriptura
     */
    private void afegirEntry(ZipOutputStream zos, String nom, byte[] contingut) throws IOException {
        ZipEntry entry = new ZipEntry(nom);
        zos.putNextEntry(entry);
        zos.write(contingut);
        zos.closeEntry();
    }

    /**
     * Afegeix un missatge d'èxit al flux web (flash attributes).
     *
     * @param ra atributs flash
     * @param missatge text del missatge
     */
    private void afegirMissatgeExit(RedirectAttributes ra, String missatge) {
        ra.addFlashAttribute("missatge", missatge);
        ra.addFlashAttribute("tipusMissatge", "success");
    }

    /**
     * Afegeix un missatge d'error/avís al flux web (flash attributes).
     *
     * @param ra atributs flash
     * @param missatge text del missatge
     */
    private void afegirMissatgeError(RedirectAttributes ra, String missatge) {
        ra.addFlashAttribute("missatge", missatge);
        ra.addFlashAttribute("tipusMissatge", "danger");
    }

    /**
     * Determina si l'usuari autenticat té permisos d'administrador.
     *
     * @return {@code true} si té autoritat ROLE_ADMIN o ADMIN
     */
    private boolean isAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && authentication.getAuthorities().stream()
                .anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()) || "ADMIN".equals(a.getAuthority()));
    }

    /**
     * Retorna el nom d'usuari actual autenticat.
     *
     * @return username o cadena buida si no hi ha autenticació
     */
    private String currentUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return (authentication != null) ? authentication.getName() : "";
    }

    /**
     * Retorna el rol actual en format de text (per a la vista).
     *
     * @return "ADMIN" o "AGENT" segons permisos
     */
    private String rolActual() {
        return isAdmin() ? "ADMIN" : "AGENT";
    }
}
