package cat.copernic.Projecte2_Grup4.model.enums;

/**
 * Enumeració que indica l'antiguitat d'una incidència.
 *
 * <p>
 * S'utilitza per classificar una incidència com a recent ({@code Nova}) o ja
 * existent des de fa més temps ({@code Antiga}).</p>
 */
public enum Antiguitat {
    Nova,
    Antiga
}
