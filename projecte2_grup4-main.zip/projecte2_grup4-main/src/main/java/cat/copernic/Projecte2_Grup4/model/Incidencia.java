package cat.copernic.Projecte2_Grup4.model;

import cat.copernic.Projecte2_Grup4.model.enums.EstatIncidencia;
import cat.copernic.Projecte2_Grup4.model.enums.Antiguitat;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "incidencia")
/**
 * Entitat JPA que representa una incidència associada a un vehicle.
 *
 * <p>
 * Una incidència recull informació sobre un problema, dany o situació que
 * requereix seguiment, incloent-hi el títol, la descripció i, si escau, un cost
 * estimat.</p>
 *
 * <p>
 * La incidència pot estar vinculada a un {@link Vehicle} i incorpora:</p>
 * <ul>
 * <li>Data de creació.</li>
 * <li>Estat actual ({@link EstatIncidencia}).</li>
 * <li>Antiguitat ({@link Antiguitat}) per classificar-la com a nova o
 * antiga.</li>
 * <li>Usuari creador i usuari al qual està assignada la gestió.</li>
 * </ul>
 *
 * <p>
 * Per defecte, en crear una incidència s'inicialitzen:</p>
 * <ul>
 * <li>{@code dataCreacio} amb el moment actual.</li>
 * <li>{@code estat} a {@link EstatIncidencia#Activa}.</li>
 * <li>{@code antiguitat} a {@link Antiguitat#Nova}.</li>
 * </ul>
 */
public class Incidencia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_incidence")
    private Integer idIncidence;

    @Column(name = "title", length = 200, nullable = false)
    private String title;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @ManyToOne
    @JoinColumn(name = "vehicle_matricula")
    private Vehicle vehicle;

    @Column(name = "data_creacio")
    private LocalDateTime dataCreacio;

    @Enumerated(EnumType.STRING)
    @Column(name = "estat", length = 20)
    private EstatIncidencia estat;

    @Column(name = "estimated_cost", precision = 10, scale = 2)
    private BigDecimal estimatedCost;

    @Enumerated(EnumType.STRING)
    @Column(name = "antiguitat", length = 20)
    private Antiguitat antiguitat;

    @Column(name = "creado_por", length = 100)
    private String creadoPor;

    /**
     * Usuari que té assignada la gestió de la incidència en aquest moment.
     * <p>
     * - Per defecte coincideix amb {@link #creadoPor}. - Si un agent es dona de
     * baixa, pot passar temporalment a "ADMIN". - Si l'agent es torna a
     * activar, les incidències creades per ell i assignades a "ADMIN" poden
     * tornar a quedar-li assignades.
     */
    @Column(name = "assignada_a", length = 100)
    private String assignadaA;

    /**
     * Constructor per defecte.
     *
     * <p>
     * Inicialitza la data de creació amb el moment actual i estableix l'estat i
     * l'antiguitat per defecte.</p>
     */
    public Incidencia() {
        this.dataCreacio = LocalDateTime.now();
        this.estat = EstatIncidencia.Activa;
        this.antiguitat = Antiguitat.Nova;
    }

    /**
     * Retorna l'identificador intern de la incidència.
     *
     * @return id de la incidència
     */
    public Integer getIdIncidence() {
        return idIncidence;
    }

    /**
     * Assigna l'identificador intern de la incidència.
     *
     * @param idIncidence id de la incidència
     */
    public void setIdIncidence(Integer idIncidence) {
        this.idIncidence = idIncidence;
    }

    /**
     * Retorna el títol de la incidència.
     *
     * @return títol
     */
    public String getTitle() {
        return title;
    }

    /**
     * Assigna el títol de la incidència.
     *
     * @param title títol
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Retorna la descripció de la incidència.
     *
     * @return descripció
     */
    public String getDescription() {
        return description;
    }

    /**
     * Assigna la descripció de la incidència.
     *
     * @param description descripció
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Retorna el vehicle associat a la incidència.
     *
     * @return vehicle associat
     */
    public Vehicle getVehicle() {
        return vehicle;
    }

    /**
     * Assigna el vehicle associat a la incidència.
     *
     * @param vehicle vehicle associat
     */
    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    /**
     * Retorna la data de creació de la incidència.
     *
     * @return data de creació
     */
    public LocalDateTime getDataCreacio() {
        return dataCreacio;
    }

    /**
     * Assigna la data de creació de la incidència.
     *
     * @param dataCreacio nova data de creació
     */
    public void setDataCreacio(LocalDateTime dataCreacio) {
        this.dataCreacio = dataCreacio;
    }

    /**
     * Retorna l'estat actual de la incidència.
     *
     * @return estat de la incidència
     */
    public EstatIncidencia getEstat() {
        return estat;
    }

    /**
     * Assigna l'estat actual de la incidència.
     *
     * @param estat nou estat
     */
    public void setEstat(EstatIncidencia estat) {
        this.estat = estat;
    }

    /**
     * Retorna el cost estimat de la incidència.
     *
     * @return cost estimat
     */
    public BigDecimal getEstimatedCost() {
        return estimatedCost;
    }

    /**
     * Assigna el cost estimat de la incidència.
     *
     * @param estimatedCost cost estimat
     */
    public void setEstimatedCost(BigDecimal estimatedCost) {
        this.estimatedCost = estimatedCost;
    }

    /**
     * Retorna l'antiguitat de la incidència.
     *
     * @return antiguitat
     */
    public Antiguitat getAntiguitat() {
        return antiguitat;
    }

    /**
     * Assigna l'antiguitat de la incidència.
     *
     * @param antiguitat nova antiguitat
     */
    public void setAntiguitat(Antiguitat antiguitat) {
        this.antiguitat = antiguitat;
    }

    /**
     * Retorna l'usuari que ha creat la incidència.
     *
     * @return usuari creador
     */
    public String getCreadoPor() {
        return creadoPor;
    }

    /**
     * Assigna l'usuari que ha creat la incidència.
     *
     * @param creadoPor usuari creador
     */
    public void setCreadoPor(String creadoPor) {
        this.creadoPor = creadoPor;
    }

    /**
     * Retorna l'usuari al qual està assignada la gestió de la incidència.
     *
     * @return usuari assignat
     */
    public String getAssignadaA() {
        return assignadaA;
    }

    /**
     * Assigna l'usuari al qual està assignada la gestió de la incidència.
     *
     * @param assignadaA usuari assignat
     */
    public void setAssignadaA(String assignadaA) {
        this.assignadaA = assignadaA;
    }
}
