package cat.copernic.Projecte2_Grup4.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import cat.copernic.Projecte2_Grup4.model.DocumentacioIncidenciaNoSQL;

@Repository
/**
 * Repositori MongoDB per gestionar documents
 * {@link DocumentacioIncidenciaNoSQL}.
 *
 * <p>
 * Inclou consultes derivades per localitzar documentació d'incidències segons
 * quins fitxers s'han pujat (fotos, comunicats o informes).</p>
 */
public interface DocumentacioIncidenciaNoSQLRepository extends MongoRepository<DocumentacioIncidenciaNoSQL, String> {

    // Recupera tots els documents que tenen fotos del dany i informe de taller pujats
    /**
     * Recupera els documents que tenen informades les fotos de dany i l'informe
     * del taller.
     *
     * @return llista de documents que compleixen el criteri
     */
    List<DocumentacioIncidenciaNoSQL> findByFotosDanyIsNotNullAndInformeTallerIsNotNull();

    // Recupera tots els documents que tenen comunicat d'accident i fotos de reparació pujades
    /**
     * Recupera els documents que tenen informat el comunicat d'accident i les
     * fotos de reparació.
     *
     * @return llista de documents que compleixen el criteri
     */
    List<DocumentacioIncidenciaNoSQL> findByComunicatAccidentIsNotNullAndFotosReparacioIsNotNull();

    // Recupera tots els documents que tenen algun dels camps pujats (fotos del dany, comunicat o informe de taller)
    /**
     * Recupera els documents que tenen informat algun dels camps principals
     * (fotos de dany, comunicat d'accident o informe del taller).
     *
     * @return llista de documents que compleixen el criteri
     */
    List<DocumentacioIncidenciaNoSQL> findByFotosDanyIsNotNullOrComunicatAccidentIsNotNullOrInformeTallerIsNotNull();

    // Recupera tots els documents que tenen fotos del dany i comunicat d'accident però sense fotos de reparació
    /**
     * Recupera els documents que tenen informades les fotos de dany i el
     * comunicat d'accident, però no tenen informades les fotos de reparació.
     *
     * @return llista de documents que compleixen el criteri
     */
    List<DocumentacioIncidenciaNoSQL> findByFotosDanyIsNotNullAndComunicatAccidentIsNotNullAndFotosReparacioIsNull();
}
