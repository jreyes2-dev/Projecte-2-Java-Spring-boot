package cat.copernic.Projecte2_Grup4.security;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controlador web per a pàgines relacionades amb la seguretat de l'aplicació.
 *
 * <p>
 * Actualment, proporciona la pàgina d'accés denegat, utilitzada quan un usuari
 * autenticat intenta accedir a un recurs per al qual no té permisos.</p>
 */
@Controller
public class SecurityPagesController {

    /**
     * Mostra la vista d'accés denegat.
     *
     * @return nom de la vista Thymeleaf d'accés denegat
     */
    @GetMapping("/web/access-denied")
    public String accessDenied() {
        return "accesdenegat/acces-denegat";
    }
}
