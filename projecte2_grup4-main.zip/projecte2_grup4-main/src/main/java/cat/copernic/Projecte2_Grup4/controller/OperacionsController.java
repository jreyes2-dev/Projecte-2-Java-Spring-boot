package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.model.FotoLliurament;
import cat.copernic.Projecte2_Grup4.model.Reserva;
import cat.copernic.Projecte2_Grup4.model.User;
import cat.copernic.Projecte2_Grup4.model.enums.Rol;
import cat.copernic.Projecte2_Grup4.repository.FotoLliuramentRepository;
import cat.copernic.Projecte2_Grup4.repository.UserRepository;
import cat.copernic.Projecte2_Grup4.service.IncidenciaService;
import cat.copernic.Projecte2_Grup4.service.ReservaService;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/web/operacions")
/**
 * Controlador web per gestionar les operacions relacionades amb una reserva
 * durant el procés d'entrega i retorn del vehicle.
 *
 * <p>
 * Inclou:</p>
 * <ul>
 * <li>Cerca de reserves pendents de lliurament o retorn.</li>
 * <li>Confirmació del lliurament amb data/hora, descripció i fotografies
 * opcionals.</li>
 * <li>Confirmació del retorn i, si escau, creació d'una incidència
 * associada.</li>
 * <li>Servei binari de fotografies del lliurament per a la seva
 * visualització.</li>
 * </ul>
 *
 * <p>
 * L'accés a aquestes funcionalitats està restringit a usuaris amb rol d'agent o
 * administrador.</p>
 */
public class OperacionsController {

    private final ReservaService reservaService;
    private final IncidenciaService incidenciaService;
    private final UserRepository userRepository;
    private final FotoLliuramentRepository fotoLliuramentRepository;

    /**
     * Constructor amb injecció de dependències.
     *
     * @param reservaService servei de gestió de reserves i operacions de
     * lliurament/retorn
     * @param incidenciaService servei de gestió d'incidències
     * @param userRepository repositori d'usuaris per recuperar l'usuari
     * autenticat
     * @param fotoLliuramentRepository repositori de fotos de lliurament per
     * servir contingut binari
     */
    public OperacionsController(
            ReservaService reservaService,
            IncidenciaService incidenciaService,
            UserRepository userRepository,
            FotoLliuramentRepository fotoLliuramentRepository
    ) {
        this.reservaService = reservaService;
        this.incidenciaService = incidenciaService;
        this.userRepository = userRepository;
        this.fotoLliuramentRepository = fotoLliuramentRepository;
    }

    /**
     * Recupera l'usuari autenticat a partir del context de seguretat.
     *
     * @return l'usuari actual si existeix i està autenticat; en cas contrari
     * {@code null}
     */
    private User currentUserOrNull() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getName() == null) {
            return null;
        }
        return userRepository.findByNomUser(auth.getName()).orElse(null);
    }

    /**
     * Indica si un usuari té rol d'agent o d'administrador.
     *
     * @param u usuari a validar
     * @return {@code true} si el rol és {@link Rol#AGENT} o {@link Rol#ADMIN};
     * en cas contrari {@code false}
     */
    private boolean isAgentOrAdmin(User u) {
        return u != null && (u.getRol() == Rol.AGENT || u.getRol() == Rol.ADMIN);
    }

    // Lliurar vehicle
    /**
     * Cerca reserves susceptibles de ser lliurades, utilitzant criteris
     * opcionals.
     *
     * <p>
     * Permet filtrar per codi de reserva i/o per correu electrònic del
     * client.</p>
     *
     * @param codiReserva codi de reserva (opcional)
     * @param email correu electrònic del client (opcional)
     * @param model model de Spring per exposar resultats i filtres a la vista
     * @return vista de cerca de lliurament o redirecció a accés denegat si no
     * hi ha permisos
     */
    @GetMapping("/lliurament/cercar")
    public String cercarLliurament(
            @RequestParam(value = "codiReserva", required = false) String codiReserva,
            @RequestParam(value = "email", required = false) String email,
            Model model
    ) {
        User u = currentUserOrNull();
        if (!isAgentOrAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        List<Reserva> resultats = reservaService.cercarReservesPerLliurament(codiReserva, email);
        model.addAttribute("resultats", resultats);
        model.addAttribute("codiReserva", codiReserva);
        model.addAttribute("email", email);

        return "operacions/cercar-lliurament";
    }

    /**
     * Mostra el formulari per confirmar el lliurament d'una reserva concreta.
     *
     * @param id identificador intern de la reserva
     * @param model model de Spring per exposar la reserva a la vista
     * @return formulari de lliurament o redirecció a accés denegat si no hi ha
     * permisos
     */
    @GetMapping("/lliurament/{id}")
    public String formLliurament(@PathVariable("id") Long id, Model model) {
        User u = currentUserOrNull();
        if (!isAgentOrAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        Reserva r = reservaService.obtenirReservaPerId(id);
        model.addAttribute("reserva", r);

        return "operacions/form-lliurament";
    }

    /**
     * Confirma el lliurament d'un vehicle associat a una reserva.
     *
     * <p>
     * La data i hora es reben com a {@code datetime-local} i es parsegen a
     * {@link LocalDateTime}. També permet adjuntar fotografies de lliurament de
     * forma opcional.</p>
     *
     * @param id identificador intern de la reserva
     * @param dataHoraStr data i hora de lliurament en format ISO de
     * {@code datetime-local}
     * @param descripcio descripció o observacions del lliurament
     * @param fotos array de fitxers d'imatge (opcional)
     * @param redirect atributs flash per informar del resultat
     * @return redirecció a la cerca de lliuraments si tot va bé; en cas
     * d'error, torna al formulari
     */
    @PostMapping("/lliurament/{id}/confirmar")
    public String confirmarLliurament(
            @PathVariable("id") Long id,
            @RequestParam("dataHora") String dataHoraStr,
            @RequestParam("descripcio") String descripcio,
            @RequestParam(value = "fotos", required = false) MultipartFile[] fotos,
            RedirectAttributes redirect
    ) {
        User u = currentUserOrNull();
        if (!isAgentOrAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        try {
            // datetime-local -> "yyyy-MM-ddTHH:mm" (LocalDateTime.parse ho interpreta)
            LocalDateTime dataHora = LocalDateTime.parse(dataHoraStr);

            reservaService.confirmarLliurament(id, dataHora, descripcio, fotos);

            redirect.addFlashAttribute("missatge", "✅ Lliurament confirmat correctament.");
            redirect.addFlashAttribute("tipusMissatge", "success");
            return "redirect:/web/operacions/lliurament/cercar";

        } catch (Exception e) {
            redirect.addFlashAttribute("missatge", "❌ Error confirmant lliurament: " + e.getMessage());
            redirect.addFlashAttribute("tipusMissatge", "danger");
            return "redirect:/web/operacions/lliurament/" + id;
        }
    }

    // Retornar vehicle
    /**
     * Cerca reserves susceptibles de ser retornades, utilitzant criteris
     * opcionals.
     *
     * <p>
     * Permet filtrar per codi de reserva, correu electrònic del client i/o
     * matrícula.</p>
     *
     * @param codiReserva codi de reserva (opcional)
     * @param email correu electrònic del client (opcional)
     * @param matricula matrícula del vehicle (opcional)
     * @param model model de Spring per exposar resultats i filtres a la vista
     * @return vista de cerca de retorn o redirecció a accés denegat si no hi ha
     * permisos
     */
    @GetMapping("/retorn/cercar")
    public String cercarRetorn(
            @RequestParam(value = "codiReserva", required = false) String codiReserva,
            @RequestParam(value = "email", required = false) String email,
            @RequestParam(value = "matricula", required = false) String matricula,
            Model model
    ) {
        User u = currentUserOrNull();
        if (!isAgentOrAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        List<Reserva> resultats = reservaService.cercarReservesPerRetorn(codiReserva, email, matricula);

        model.addAttribute("resultats", resultats);
        model.addAttribute("codiReserva", codiReserva);
        model.addAttribute("email", email);
        model.addAttribute("matricula", matricula);

        return "operacions/cercar-retorn";
    }

    /**
     * Mostra el formulari per confirmar el retorn d'un vehicle d'una reserva.
     *
     * <p>
     * Inclou també la càrrega de les fotografies registrades en el moment del
     * lliurament per facilitar la comparació.</p>
     *
     * @param id identificador intern de la reserva
     * @param model model de Spring per exposar la reserva i les fotografies a
     * la vista
     * @return formulari de retorn o redirecció a accés denegat si no hi ha
     * permisos
     */
    @GetMapping("/retorn/{id}")
    public String formRetorn(@PathVariable("id") Long id, Model model) {
        User u = currentUserOrNull();
        if (!isAgentOrAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        Reserva r = reservaService.obtenirReservaPerId(id);
        List<FotoLliurament> fotos = reservaService.fotosLliurament(id);

        model.addAttribute("reserva", r);
        model.addAttribute("fotos", fotos);

        return "operacions/form-retorn";
    }

    /**
     * Confirma el retorn d'un vehicle i gestiona la possible creació d'una
     * incidència.
     *
     * <p>
     * Si s'indica que hi ha desperfectes, es requereix especificar si són
     * imputables al client. En cas de crear-se una incidència, s'assigna al
     * mateix usuari que confirma el retorn.</p>
     *
     * @param id identificador intern de la reserva
     * @param dataHoraStr data i hora de retorn en format ISO de
     * {@code datetime-local}
     * @param desperfectesStr indicador de desperfectes (pot arribar com "on" o
     * "true")
     * @param imputableStr valor del selector d'imputabilitat ("true", "false" o
     * buit)
     * @param titolIncidencia títol de la incidència (opcional)
     * @param descIncidencia descripció de la incidència (opcional)
     * @param redirect atributs flash per informar del resultat
     * @return redirecció a la cerca de retorns si tot va bé; en cas d'error,
     * torna al formulari
     */
    @PostMapping("/retorn/{id}/confirmar")
    public String confirmarRetorn(
            @PathVariable("id") Long id,
            @RequestParam("dataHoraRetorn") String dataHoraStr,
            @RequestParam(value = "desperfectes", required = false) String desperfectesStr,
            @RequestParam(value = "imputableClient", required = false) String imputableStr,
            @RequestParam(value = "titolIncidencia", required = false) String titolIncidencia,
            @RequestParam(value = "descIncidencia", required = false) String descIncidencia,
            RedirectAttributes redirect
    ) {
        User u = currentUserOrNull();
        if (!isAgentOrAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        try {
            LocalDateTime dataHoraRetorn = LocalDateTime.parse(dataHoraStr);

            boolean teDesperfectes = "on".equalsIgnoreCase(desperfectesStr) || "true".equalsIgnoreCase(desperfectesStr);

            Boolean imputable = null;
            if (teDesperfectes) {
                // el selector envia "true" o "false" o "".
                if (imputableStr != null && !imputableStr.isBlank()) {
                    imputable = Boolean.parseBoolean(imputableStr);
                } else {
                    throw new IllegalArgumentException("Has d'indicar si els desperfectes són imputables al client");
                }
            }

            String nomUser = (u != null && u.getNomUser() != null) ? u.getNomUser() : "ADMIN";

            reservaService.confirmarRetorn(
                    id,
                    dataHoraRetorn,
                    teDesperfectes,
                    imputable,
                    titolIncidencia,
                    descIncidencia,
                    (inc) -> {
                        inc.setCreadoPor(nomUser);
                        inc.setAssignadaA(nomUser);
                        incidenciaService.guardarIncidenciaIRetornar(inc);
                    }
            );

            redirect.addFlashAttribute("missatge", "✅ Retorn confirmat correctament.");
            redirect.addFlashAttribute("tipusMissatge", "success");
            return "redirect:/web/operacions/retorn/cercar";

        } catch (Exception e) {
            redirect.addFlashAttribute("missatge", "❌ Error confirmant retorn: " + e.getMessage());
            redirect.addFlashAttribute("tipusMissatge", "danger");
            return "redirect:/web/operacions/retorn/" + id;
        }
    }

    // Servir fotos lliurament (binari)
    /**
     * Retorna el contingut binari d'una fotografia de lliurament.
     *
     * <p>
     * L'accés està restringit a agent o administrador. Si la foto no existeix,
     * es retorna un {@code 404}. Si no hi ha permisos, un {@code 403}.</p>
     *
     * @param id identificador de la fotografia
     * @return resposta HTTP amb el contingut de la imatge i el
     * {@code Content-Type} corresponent
     */
    @GetMapping("/fotos/{id}")
    @ResponseBody
    public ResponseEntity<byte[]> veureFoto(@PathVariable("id") Long id) {
        User u = currentUserOrNull();
        if (!isAgentOrAdmin(u)) {
            return ResponseEntity.status(403).build();
        }

        FotoLliurament f = fotoLliuramentRepository.findById(id).orElse(null);
        if (f == null || f.getContingut() == null) {
            return ResponseEntity.notFound().build();
        }

        String ct = (f.getContentType() != null && !f.getContentType().isBlank())
                ? f.getContentType()
                : "application/octet-stream";

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_TYPE, ct)
                .body(f.getContingut());
    }
}
