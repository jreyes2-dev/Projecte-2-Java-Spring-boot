package cat.copernic.Projecte2_Grup4.repository;

import cat.copernic.Projecte2_Grup4.model.Localitzacio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import org.springframework.data.repository.query.Param;

@Repository
/**
 * Repositori JPA per gestionar la persistència d'entitats {@link Localitzacio}.
 *
 * <p>
 * Inclou consultes amb {@code FETCH JOIN} per recuperar localitzacions
 * juntament amb les seves relacions ({@code vehicles} i {@code agent}) i un
 * mètode de cerca per text.</p>
 */
public interface LocalitzacioRepository extends JpaRepository<Localitzacio, String> {

    /**
     * Recupera totes les localitzacions amb els seus vehicles i l'agent
     * associat, utilitzant {@code FETCH JOIN}.
     *
     * @return llista de localitzacions amb vehicles i agent carregats
     */
    @Query("""
        SELECT l
        FROM Localitzacio l
        LEFT JOIN FETCH l.vehicles
        LEFT JOIN FETCH l.agent
    """)
    List<Localitzacio> findAllWithVehiclesAndAgent();

    /**
     * Recupera una localització concreta (per codi postal) amb els seus
     * vehicles i l'agent associat.
     *
     * @param cp codi postal
     * @return localització trobada o {@code null} si no existeix
     */
    @Query("""
        SELECT l
        FROM Localitzacio l
        LEFT JOIN FETCH l.vehicles
        LEFT JOIN FETCH l.agent
        WHERE l.codiPostal = :cp
    """)
    Localitzacio findByCodiPostalWithVehiclesAndAgent(@Param("cp") String cp);

    /**
     * Cerca localitzacions per text (codi postal, nom o adreça) i carrega
     * vehicles i agent amb {@code FETCH JOIN}.
     *
     * <p>
     * Quan {@code q} és {@code null} o buit, el predicat permet retornar totes
     * les localitzacions.</p>
     *
     * @param q text de cerca (opcional)
     * @return llista de localitzacions que coincideixen amb el criteri
     */
    @Query("""
    SELECT DISTINCT l
    FROM Localitzacio l
    LEFT JOIN FETCH l.vehicles
    LEFT JOIN FETCH l.agent
    WHERE
        (:q IS NULL OR :q = '')
        OR LOWER(l.codiPostal) LIKE LOWER(CONCAT('%', :q, '%'))
        OR LOWER(l.nom) LIKE LOWER(CONCAT('%', :q, '%'))
        OR LOWER(l.adreça) LIKE LOWER(CONCAT('%', :q, '%'))
""")
    List<Localitzacio> searchWithVehiclesAndAgent(@Param("q") String q);

    /**
     * Recupera totes les localitzacions ordenades pel codi postal.
     *
     * @return llista de localitzacions ordenada
     */
    @Query("SELECT l FROM Localitzacio l ORDER BY l.codiPostal")
    List<Localitzacio> findAllOrderByCodiPostal();
}
