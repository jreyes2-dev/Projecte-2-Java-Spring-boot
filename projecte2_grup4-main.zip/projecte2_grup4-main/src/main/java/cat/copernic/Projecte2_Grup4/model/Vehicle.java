package cat.copernic.Projecte2_Grup4.model;

import cat.copernic.Projecte2_Grup4.model.enums.EstatVehicle;
import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

@Entity
@Table(name = "vehicle")
/**
 * Entitat JPA que representa un vehicle disponible per al sistema de lloguer.
 *
 * <p>
 * Un vehicle s'identifica de manera única per la seva matrícula
 * ({@code matricule}) i conté informació descriptiva (marca, model i color),
 * així com l'estat operatiu ({@link EstatVehicle}).</p>
 *
 * <p>
 * La classe incorpora camps per gestionar el cicle de vida del vehicle:</p>
 * <ul>
 * <li><strong>Disponibilitat</strong>: estat disponible o no disponible.</li>
 * <li><strong>Manteniment</strong>: data de l'últim manteniment.</li>
 * <li><strong>Baixa temporal</strong>: data de desactivació i data de fi
 * (opcional).</li>
 * <li><strong>Alta/reactivació</strong>: motiu i import associat
 * (opcionals).</li>
 * </ul>
 *
 * <p>
 * També permet associar el vehicle a una {@link Localitzacio} i consultar les
 * seves {@link Incidencia incidències}. Opcionalment, es pot emmagatzemar una
 * fotografia del vehicle en binari (LONGBLOB) juntament amb el seu
 * {@code contentType}.</p>
 */
public class Vehicle {

    @Id
    @Column(length = 10)
    private String matricule;

    @Column(length = 100)
    private String marca;

    @Column(length = 100)
    private String model;

    @Column(length = 100)
    private String color;

    @Enumerated(EnumType.STRING)
    @Column(length = 20, nullable = false)
    private EstatVehicle estat;

    private Integer kilometres;

    private LocalDateTime ultimManteniment;

    // Desactivar (baixa)
    private LocalDateTime dataDesactivacio; // data actual quan es desactiva
    private LocalDate dataFiDesactivacio;   // opcional

    // Activar (alta) - motiu/import opcional
    @Column(length = 255)
    private String motiuActivacio;

    private Double importActivacio;

    @Column(name = "cost_diari", nullable = false)
    private Double costDiari = 0.0;

    @ManyToOne
    @JoinColumn(name = "codiPostal")
    private Localitzacio localitzacio;

    @OneToMany(mappedBy = "vehicle")
    private List<Incidencia> incidencies = new ArrayList<>();

    //Foto del vehicle guardada en binari a la BD (MySQL LONGBLOB)
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "foto", columnDefinition = "LONGBLOB")
    private byte[] foto;

    //Content-Type per servir la foto correctament (image/jpeg, image/png, ...)
    @Column(name = "foto_content_type", length = 100)
    private String fotoContentType;

    // Constructors
    /**
     * Constructor per defecte.
     */
    public Vehicle() {
    }

    /**
     * Constructor complet amb les dades principals del vehicle.
     *
     * @param matricule matrícula del vehicle
     * @param marca marca del vehicle
     * @param model model del vehicle
     * @param color color del vehicle
     * @param estat estat del vehicle
     * @param kilometres quilometratge del vehicle
     * @param ultimManteniment data de l'últim manteniment
     * @param localitzacio localització associada (opcional)
     */
    public Vehicle(String matricule, String marca, String model, String color,
            EstatVehicle estat, Integer kilometres,
            LocalDateTime ultimManteniment, Localitzacio localitzacio) {

        this.matricule = matricule;
        this.marca = marca;
        this.model = model;
        this.color = color;
        this.estat = estat;
        this.kilometres = kilometres;
        this.ultimManteniment = ultimManteniment;
        this.localitzacio = localitzacio;
    }

    // Getters i Setters
    /**
     * Retorna la matrícula del vehicle.
     *
     * @return matrícula
     */
    public String getMatricule() {
        return matricule;
    }

    /**
     * Assigna la matrícula del vehicle.
     *
     * @param matricule matrícula
     */
    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    /**
     * Retorna la marca del vehicle.
     *
     * @return marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * Assigna la marca del vehicle.
     *
     * @param marca marca
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * Retorna el model del vehicle.
     *
     * @return model
     */
    public String getModel() {
        return model;
    }

    /**
     * Assigna el model del vehicle.
     *
     * @param model model
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * Retorna el color del vehicle.
     *
     * @return color
     */
    public String getColor() {
        return color;
    }

    /**
     * Assigna el color del vehicle.
     *
     * @param color color
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * Retorna l'estat del vehicle.
     *
     * @return estat del vehicle
     */
    public EstatVehicle getEstat() {
        return estat;
    }

    /**
     * Assigna l'estat del vehicle.
     *
     * @param estat estat del vehicle
     */
    public void setEstat(EstatVehicle estat) {
        this.estat = estat;
    }

    /**
     * Retorna els quilòmetres del vehicle.
     *
     * @return quilometratge
     */
    public Integer getKilometres() {
        return kilometres;
    }

    /**
     * Assigna els quilòmetres del vehicle.
     *
     * @param kilometres quilometratge
     */
    public void setKilometres(Integer kilometres) {
        this.kilometres = kilometres;
    }

    /**
     * Retorna la data de l'últim manteniment.
     *
     * @return data de l'últim manteniment
     */
    public LocalDateTime getUltimManteniment() {
        return ultimManteniment;
    }

    /**
     * Assigna la data de l'últim manteniment.
     *
     * @param ultimManteniment data de l'últim manteniment
     */
    public void setUltimManteniment(LocalDateTime ultimManteniment) {
        this.ultimManteniment = ultimManteniment;
    }

    /**
     * Retorna el cost diari del vehicle.
     *
     * @return cost diari
     */
    public Double getCostDiari() {
        return costDiari;
    }

    /**
     * Assigna el cost diari del vehicle.
     *
     * @param costDiari cost diari
     */
    public void setCostDiari(Double costDiari) {
        this.costDiari = costDiari;
    }

    /**
     * Retorna la localització associada al vehicle.
     *
     * @return localització (pot ser {@code null})
     */
    public Localitzacio getLocalitzacio() {
        return localitzacio;
    }

    /**
     * Assigna la localització associada al vehicle.
     *
     * @param localitzacio localització
     */
    public void setLocalitzacio(Localitzacio localitzacio) {
        this.localitzacio = localitzacio;
    }

    /**
     * Retorna la llista d'incidències associades al vehicle.
     *
     * @return incidències
     */
    public List<Incidencia> getIncidencies() {
        return incidencies;
    }

    /**
     * Assigna la llista d'incidències associades al vehicle.
     *
     * @param incidencies incidències
     */
    public void setIncidencies(List<Incidencia> incidencies) {
        this.incidencies = incidencies;
    }

    // getters/setters de la foto
    /**
     * Retorna la fotografia del vehicle en format binari.
     *
     * @return bytes de la foto (pot ser {@code null})
     */
    public byte[] getFoto() {
        return foto;
    }

    /**
     * Assigna la fotografia del vehicle en format binari.
     *
     * @param foto bytes de la foto
     */
    public void setFoto(byte[] foto) {
        this.foto = foto;
    }

    /**
     * Retorna el tipus de contingut (MIME) de la fotografia del vehicle.
     *
     * @return content type de la foto
     */
    public String getFotoContentType() {
        return fotoContentType;
    }

    /**
     * Assigna el tipus de contingut (MIME) de la fotografia del vehicle.
     *
     * @param fotoContentType content type de la foto
     */
    public void setFotoContentType(String fotoContentType) {
        this.fotoContentType = fotoContentType;
    }

    /**
     * Retorna la data i hora en què el vehicle es va desactivar.
     *
     * @return data de desactivació (pot ser {@code null})
     */
    public LocalDateTime getDataDesactivacio() {
        return dataDesactivacio;
    }

    /**
     * Assigna la data i hora en què el vehicle es va desactivar.
     *
     * @param dataDesactivacio data de desactivació
     */
    public void setDataDesactivacio(LocalDateTime dataDesactivacio) {
        this.dataDesactivacio = dataDesactivacio;
    }

    /**
     * Retorna la data de fi prevista de la desactivació (si s'ha informat).
     *
     * @return data de fi de desactivació (pot ser {@code null})
     */
    public LocalDate getDataFiDesactivacio() {
        return dataFiDesactivacio;
    }

    /**
     * Assigna la data de fi prevista de la desactivació.
     *
     * @param dataFiDesactivacio data de fi de desactivació
     */
    public void setDataFiDesactivacio(LocalDate dataFiDesactivacio) {
        this.dataFiDesactivacio = dataFiDesactivacio;
    }

    /**
     * Retorna el motiu de l'activació/reactivació del vehicle.
     *
     * @return motiu d'activació (pot ser {@code null})
     */
    public String getMotiuActivacio() {
        return motiuActivacio;
    }

    /**
     * Assigna el motiu de l'activació/reactivació del vehicle.
     *
     * @param motiuActivacio motiu d'activació
     */
    public void setMotiuActivacio(String motiuActivacio) {
        this.motiuActivacio = motiuActivacio;
    }

    /**
     * Retorna l'import associat a l'activació/reactivació del vehicle.
     *
     * @return import d'activació (pot ser {@code null})
     */
    public Double getImportActivacio() {
        return importActivacio;
    }

    /**
     * Assigna l'import associat a l'activació/reactivació del vehicle.
     *
     * @param importActivacio import d'activació
     */
    public void setImportActivacio(Double importActivacio) {
        this.importActivacio = importActivacio;
    }

}
