package cat.copernic.Projecte2_Grup4.repository;

import cat.copernic.Projecte2_Grup4.model.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
/**
 * Repositori JPA per gestionar la persistència d'entitats {@link Vehicle}.
 *
 * <p>
 * Proporciona operacions CRUD estàndard mitjançant {@link JpaRepository}.</p>
 */
public interface VehicleRepository extends JpaRepository<Vehicle, String> {

}
