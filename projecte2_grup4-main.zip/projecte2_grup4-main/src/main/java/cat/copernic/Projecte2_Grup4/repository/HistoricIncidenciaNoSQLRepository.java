package cat.copernic.Projecte2_Grup4.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import cat.copernic.Projecte2_Grup4.model.HistoricIncidenciaNoSQL;
import cat.copernic.Projecte2_Grup4.model.enums.AccioIncidenciaNoSQL;

@Repository
/**
 * Repositori MongoDB per gestionar documents {@link HistoricIncidenciaNoSQL}.
 *
 * <p>
 * Proporciona operacions CRUD mitjançant {@link MongoRepository} i consultes
 * derivades per recuperar registres d'històric d'incidències amb criteris
 * habituals (per incidència, acció, matrícula i ordenacions temporals).</p>
 */
public interface HistoricIncidenciaNoSQLRepository extends MongoRepository<HistoricIncidenciaNoSQL, String> {

    // Recupera tot l'històric d'una incidència per ID, ordenat cronològicament de l'antiga a la més recent
    /**
     * Recupera tot l'històric d'una incidència, ordenat cronològicament de més
     * antic a més recent.
     *
     * @param idIncidencia identificador de la incidència (SQL)
     * @return llista de registres de l'històric
     */
    List<HistoricIncidenciaNoSQL> findAllByIdIncidenciaOrderByDataCanviAsc(String idIncidencia);

    // Recupera només l'últim canvi registrat d'una incidència
    /**
     * Recupera l'últim canvi registrat d'una incidència (el més recent).
     *
     * @param idIncidencia identificador de la incidència (SQL)
     * @return registre més recent o {@code null} si no n'hi ha cap
     */
    HistoricIncidenciaNoSQL findTopByIdIncidenciaOrderByDataCanviDesc(String idIncidencia);

    // Recupera tots els logs d'una incidència amb una acció específica
    /**
     * Recupera els registres d'històric d'una incidència filtrant per una acció
     * concreta, ordenats cronològicament de més antic a més recent.
     *
     * @param idIncidencia identificador de la incidència (SQL)
     * @param accio acció a filtrar
     * @return llista de registres que compleixen el criteri
     */
    List<HistoricIncidenciaNoSQL> findAllByIdIncidenciaAndAccioOrderByDataCanviAsc(String idIncidencia, AccioIncidenciaNoSQL accio);

    /**
     * Recupera tots els registres d'històric associats a una matrícula,
     * ordenats de més recent a més antic.
     *
     * @param matricula matrícula del vehicle
     * @return llista de registres ordenada descendentment per data de canvi
     */
    List<HistoricIncidenciaNoSQL> findAllByMatriculaOrderByDataCanviDesc(String matricula);

    /**
     * Recupera tots els registres d'històric, ordenats de més recent a més
     * antic.
     *
     * @return llista de registres ordenada descendentment per data de canvi
     */
    List<HistoricIncidenciaNoSQL> findAllByOrderByDataCanviDesc();
}
