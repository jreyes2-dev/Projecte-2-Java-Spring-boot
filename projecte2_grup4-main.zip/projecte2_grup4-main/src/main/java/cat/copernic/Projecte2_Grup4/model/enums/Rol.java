package cat.copernic.Projecte2_Grup4.model.enums;

/**
 * Enumeració de rols d'usuari dins l'aplicació.
 *
 * <p>
 * Determina els permisos i l'accés a funcionalitats segons si l'usuari és
 * agent, administrador o client.</p>
 */
public enum Rol {
    AGENT, ADMIN, CLIENT
}
