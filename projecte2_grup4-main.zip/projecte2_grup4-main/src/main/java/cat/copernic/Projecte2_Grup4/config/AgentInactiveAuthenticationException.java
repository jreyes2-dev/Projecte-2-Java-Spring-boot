package cat.copernic.Projecte2_Grup4.config;

import org.springframework.security.core.AuthenticationException;

/**
 *
 * Excepció d'autenticació específica.
 *
 */
public class AgentInactiveAuthenticationException extends AuthenticationException {

    public AgentInactiveAuthenticationException(String msg) {
        super(msg);
    }
}
