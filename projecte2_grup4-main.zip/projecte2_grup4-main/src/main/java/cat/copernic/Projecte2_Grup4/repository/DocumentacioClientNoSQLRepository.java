package cat.copernic.Projecte2_Grup4.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import cat.copernic.Projecte2_Grup4.model.DocumentacioClientNoSQL;

@Repository
/**
 * Repositori MongoDB per gestionar documents {@link DocumentacioClientNoSQL}.
 *
 * <p>
 * Proporciona operacions CRUD mitjançant {@link MongoRepository} i consultes
 * derivades per recuperar documentació segons el tipus de document pujat.</p>
 */
public interface DocumentacioClientNoSQLRepository extends MongoRepository<DocumentacioClientNoSQL, String> {

    // Recupera un client pel seu DNI (ID de la col·lecció)
    /**
     * Recupera la documentació d'un client pel seu DNI.
     *
     * @param dni DNI del client
     * @return {@link Optional} amb el document si existeix, o buit en cas
     * contrari
     */
    Optional<DocumentacioClientNoSQL> findByDni(String dni);

    // Comprova si existeix un client amb un DNI concret
    /**
     * Comprova si existeix documentació per a un DNI concret.
     *
     * @param dni DNI del client
     * @return {@code true} si existeix; {@code false} en cas contrari
     */
    boolean existsByDni(String dni);

    // Recupera tots els clients que tenen DNI pujat
    /**
     * Recupera tots els documents que tenen el DNI informat.
     *
     * @return llista de documents amb {@code documentDNI} no nul
     */
    List<DocumentacioClientNoSQL> findByDocumentDNIIsNotNull();

    // Recupera tots els clients que tenen passaport pujat
    /**
     * Recupera tots els documents que tenen el passaport informat.
     *
     * @return llista de documents amb {@code documentPassaport} no nul
     */
    List<DocumentacioClientNoSQL> findByDocumentPassaportIsNotNull();

    // Recupera tots els clients que tenen carnet de conduir pujat
    /**
     * Recupera tots els documents que tenen el carnet de conduir informat.
     *
     * @return llista de documents amb {@code carnetConduir} no nul
     */
    List<DocumentacioClientNoSQL> findByCarnetConduirIsNotNull();

    // Recupera tots els clients que tenen DNI i carnet de conduir pujats
    /**
     * Recupera tots els documents que tenen el DNI i el carnet de conduir
     * informats.
     *
     * @return llista de documents amb {@code documentDNI} i
     * {@code carnetConduir} no nuls
     */
    List<DocumentacioClientNoSQL> findByDocumentDNIIsNotNullAndCarnetConduirIsNotNull();

    // Recupera tots els clients que tenen algun document pujat (DNI, passaport o carnet de conduir)
    /**
     * Recupera tots els documents que tenen almenys un document informat (DNI,
     * passaport o carnet de conduir).
     *
     * @return llista de documents amb algun dels camps binaris no nul
     */
    List<DocumentacioClientNoSQL> findByDocumentDNIIsNotNullOrDocumentPassaportIsNotNullOrCarnetConduirIsNotNull();
}
