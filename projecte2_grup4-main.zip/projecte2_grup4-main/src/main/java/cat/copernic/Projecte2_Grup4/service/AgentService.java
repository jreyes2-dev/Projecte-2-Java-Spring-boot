package cat.copernic.Projecte2_Grup4.service;

import cat.copernic.Projecte2_Grup4.model.Agent;
import cat.copernic.Projecte2_Grup4.model.enums.EstatAgent;
import cat.copernic.Projecte2_Grup4.repository.AgentRepository;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
/**
 * Servei d'aplicació per gestionar els {@link Agent agents}.
 *
 * <p>
 * Centralitza la lògica d'accés a dades i validació relacionada amb agents:
 * llistats, obtenció per diferents claus, comprovacions d'unicitat i validació
 * per a creació i edició.</p>
 *
 * <p>
 * Quan es guarda un agent, si la contrasenya sembla estar en text pla, es
 * codifica mitjançant {@link PasswordEncoder} abans de persistir-la.</p>
 */
public class AgentService {

    private final AgentRepository agentRepository;
    private final PasswordEncoder passwordEncoder;

    /**
     * Constructor amb injecció de dependències.
     *
     * @param agentRepository repositori d'agents
     * @param passwordEncoder codificador de contrasenyes
     */
    public AgentService(AgentRepository agentRepository, PasswordEncoder passwordEncoder) {
        this.agentRepository = agentRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Llista tots els agents registrats.
     *
     * @return llista completa d'agents
     */
    public List<Agent> llistarTotsAgents() {
        return agentRepository.findAll();
    }

    /**
     * Llista tots els agents que es troben en estat {@link EstatAgent#ACTIU}.
     *
     * @return llista d'agents actius
     */
    public List<Agent> llistarAgentsActius() {
        return agentRepository.findAll().stream()
                .filter(a -> a.getEstatAgent() == EstatAgent.ACTIU)
                .toList();
    }

    /**
     * Obté un agent a partir del seu DNI.
     *
     * @param dni DNI de l'agent
     * @return agent trobat o {@code null} si no existeix
     */
    public Agent obtenirAgentPerDni(String dni) {
        return agentRepository.findById(dni).orElse(null);
    }

    /**
     * Obté un agent a partir del seu correu electrònic (ignorant
     * majúscules/minúscules).
     *
     * @param email correu electrònic
     * @return agent trobat o {@code null} si no existeix
     */
    public Agent obtenirAgentPerEmail(String email) {
        if (agentRepository.existsByEmail(email)) {
            return agentRepository.findAll().stream()
                    .filter(a -> a.getEmail() != null && a.getEmail().equalsIgnoreCase(email))
                    .findFirst()
                    .orElse(null);
        }
        return null;
    }

    /**
     * Obté un agent a partir del seu nom d'usuari.
     *
     * @param nomUser nom d'usuari
     * @return agent trobat o {@code null} si no existeix
     */
    public Agent obtenirAgentPerNomUser(String nomUser) {
        return agentRepository.findByNomUser(nomUser).orElse(null);
    }

    /**
     * Desa un agent (alta o actualització).
     *
     * <p>
     * Si la contrasenya no és buida i no sembla un hash BCrypt, es codifica
     * abans de desar.</p>
     *
     * @param agent agent a persistir
     */
    public void guardarAgent(Agent agent) {
        if (agent.getContrasenya() != null && !agent.getContrasenya().isBlank()
                && !semblaBcrypt(agent.getContrasenya())) {
            agent.setContrasenya(passwordEncoder.encode(agent.getContrasenya()));
        }
        agentRepository.save(agent);
    }

    /**
     * Determina si una cadena sembla un hash BCrypt (p. ex. {@code $2a$},
     * {@code $2b$}, {@code $2y$}).
     *
     * @param value valor a comprovar
     * @return {@code true} si sembla BCrypt; {@code false} altrament
     */
    private boolean semblaBcrypt(String value) {
        // Hash BCrypt típic: $2a$..., $2b$..., $2y$...
        return value != null && value.startsWith("$2");
    }

    /**
     * Comprova si existeix un agent amb el DNI indicat.
     *
     * @param dni DNI a comprovar
     * @return {@code true} si existeix; {@code false} en cas contrari
     */
    public boolean existeixDni(String dni) {
        return agentRepository.existsById(dni);
    }

    /**
     * Comprova si existeix un altre agent amb el mateix correu electrònic.
     *
     * <p>
     * Si {@code dniActual} està informat, s'exclou del control d'unicitat.</p>
     *
     * @param email correu electrònic a validar
     * @param dniActual DNI de l'agent que s'està editant (opcional)
     * @return {@code true} si el correu ja està registrat per un altre agent;
     * {@code false} si és únic
     */
    public boolean existeixEmail(String email, String dniActual) {
        if (dniActual != null && !dniActual.trim().isEmpty()) {
            return agentRepository.existsByEmailAndDniNot(email, dniActual);
        } else {
            return agentRepository.existsByEmail(email);
        }
    }

    /**
     * Comprova si existeix un altre agent amb el mateix nom d'usuari.
     *
     * <p>
     * Si {@code dniActual} està informat, permet que l'agent actual mantingui
     * el seu propi {@code nomUser}.</p>
     *
     * @param nomUser nom d'usuari a validar
     * @param dniActual DNI de l'agent que s'està editant (opcional)
     * @return {@code true} si el nom d'usuari ja està ocupat per un altre
     * agent; {@code false} si és únic
     */
    public boolean existeixNomUser(String nomUser, String dniActual) {
        Agent agentAmbNomUser = obtenirAgentPerNomUser(nomUser);
        if (agentAmbNomUser == null) {
            return false;
        }
        if (dniActual != null && !dniActual.trim().isEmpty()) {
            return !agentAmbNomUser.getDni().equals(dniActual);
        }
        return true;
    }

    /**
     * Valida les dades necessàries per crear un agent.
     *
     * <p>
     * Retorna un mapa amb errors per camp (clau = nom del camp, valor =
     * missatge d'error). Si el mapa és buit, la validació s'ha superat.</p>
     *
     * @param agent agent a validar
     * @return mapa d'errors per camp
     */
    public Map<String, String> validarAgentCreacio(Agent agent) {
        Map<String, String> errors = new HashMap<>();

        if (agent.getDni() == null || agent.getDni().trim().isEmpty()) {
            errors.put("dni", "El DNI és obligatori");
        } else if (!agent.getDni().matches("[0-9]{8}[A-Za-z]")) {
            errors.put("dni", "DNI invàlid. Format: 8 números + lletra");
        } else if (existeixDni(agent.getDni())) {
            errors.put("dni", "Aquest DNI ja està registrat");
        }

        if (agent.getEmail() == null || agent.getEmail().trim().isEmpty()) {
            errors.put("email", "L'email és obligatori");
        } else if (!agent.getEmail().matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")) {
            errors.put("email", "Email invàlid. Format: usuari@domini.extensió");
        } else if (existeixEmail(agent.getEmail(), null)) {
            errors.put("email", "Aquest email ja està registrat");
        }

        if (agent.getNomUser() == null || agent.getNomUser().trim().isEmpty()) {
            errors.put("nomUser", "El nom d'usuari és obligatori");
        } else if (agent.getNomUser().length() < 3 || agent.getNomUser().length() > 20) {
            errors.put("nomUser", "El nom d'usuari ha de tenir entre 3 i 20 caràcters");
        } else if (!agent.getNomUser().matches("[a-zA-Z0-9._-]+")) {
            errors.put("nomUser", "Només pots utilitzar: lletres, números, punt, guió i guió baix");
        } else if (existeixNomUser(agent.getNomUser(), null)) {
            errors.put("nomUser", "Aquest nom d'usuari ja està en ús");
        }

        if (agent.getNom() == null || agent.getNom().trim().isEmpty()) {
            errors.put("nom", "El nom és obligatori");
        } else if (agent.getNom().length() < 2 || agent.getNom().length() > 50) {
            errors.put("nom", "El nom ha de tenir entre 2 i 50 caràcters");
        }

        if (agent.getCognom1() == null || agent.getCognom1().trim().isEmpty()) {
            errors.put("cognom1", "El primer cognom és obligatori");
        } else if (agent.getCognom1().length() < 2 || agent.getCognom1().length() > 50) {
            errors.put("cognom1", "El primer cognom ha de tenir entre 2 i 50 caràcters");
        }

        if (agent.getContrasenya() == null || agent.getContrasenya().trim().isEmpty()) {
            errors.put("contrasenya", "La contrasenya és obligatòria");
        } else if (agent.getContrasenya().length() < 4 || agent.getContrasenya().length() > 20) {
            errors.put("contrasenya", "La contrasenya ha de tenir entre 4 i 20 caràcters");
        }

        return errors;
    }

    /**
     * Valida les dades necessàries per editar un agent existent.
     *
     * <p>
     * Retorna un mapa amb errors per camp (clau = nom del camp, valor =
     * missatge d'error). Si el mapa és buit, la validació s'ha superat.</p>
     *
     * @param agent agent amb les dades noves
     * @param dniActual DNI de l'agent que s'està editant
     * @return mapa d'errors per camp
     */
    public Map<String, String> validarAgentEdicio(Agent agent, String dniActual) {
        Map<String, String> errors = new HashMap<>();

        Agent agentActual = obtenirAgentPerDni(dniActual);
        if (agentActual == null) {
            errors.put("general", "L'agent no existeix");
            return errors;
        }

        if (!agent.getDni().equals(dniActual) && existeixDni(agent.getDni())) {
            errors.put("dni", "Aquest DNI ja està registrat per un altre agent!");
        }

        if (!agent.getEmail().equals(agentActual.getEmail())) {
            if (existeixEmail(agent.getEmail(), dniActual)) {
                errors.put("email", "Aquest email ja està registrat per un altre agent!");
            }
        }

        if (!agent.getNomUser().equals(agentActual.getNomUser())) {
            if (existeixNomUser(agent.getNomUser(), dniActual)) {
                errors.put("nomUser", "Aquest nom d'usuari ja està en ús per un altre agent!");
            }
        }

        if (agent.getNom() == null || agent.getNom().trim().isEmpty()) {
            errors.put("nom", "El nom és obligatori");
        } else if (agent.getNom().length() < 2 || agent.getNom().length() > 50) {
            errors.put("nom", "El nom ha de tenir entre 2 i 50 caràcters");
        }

        if (agent.getCognom1() == null || agent.getCognom1().trim().isEmpty()) {
            errors.put("cognom1", "El primer cognom és obligatori");
        } else if (agent.getCognom1().length() < 2 || agent.getCognom1().length() > 50) {
            errors.put("cognom1", "El primer cognom ha de tenir entre 2 i 50 caràcters");
        }

        if (agent.getContrasenya() != null && !agent.getContrasenya().trim().isEmpty()) {
            if (agent.getContrasenya().length() < 4 || agent.getContrasenya().length() > 20) {
                errors.put("contrasenya", "La contrasenya ha de tenir entre 4 i 20 caràcters");
            }
        }

        return errors;
    }
}
