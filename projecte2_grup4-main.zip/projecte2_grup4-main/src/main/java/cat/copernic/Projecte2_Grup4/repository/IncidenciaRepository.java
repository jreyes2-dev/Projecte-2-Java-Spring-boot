package cat.copernic.Projecte2_Grup4.repository;

import cat.copernic.Projecte2_Grup4.model.Incidencia;
import cat.copernic.Projecte2_Grup4.model.enums.Antiguitat;
import cat.copernic.Projecte2_Grup4.model.enums.EstatIncidencia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
/**
 * Repositori JPA per gestionar la persistència d'entitats {@link Incidencia}.
 *
 * <p>
 * Inclou consultes derivades per filtrar incidències per estat, antiguitat,
 * vehicle, creador i usuari assignat.</p>
 */
public interface IncidenciaRepository extends JpaRepository<Incidencia, Integer> {

    /**
     * Recupera les incidències segons l'estat indicat.
     *
     * @param estat estat de la incidència
     * @return llista d'incidències amb l'estat indicat
     */
    List<Incidencia> findByEstat(EstatIncidencia estat);

    /**
     * Recupera les incidències segons l'antiguitat indicada.
     *
     * @param antiguitat antiguitat de la incidència
     * @return llista d'incidències amb l'antiguitat indicada
     */
    List<Incidencia> findByAntiguitat(Antiguitat antiguitat);

    /**
     * Recupera les incidències associades a una matrícula de vehicle.
     *
     * @param matricule matrícula del vehicle
     * @return llista d'incidències del vehicle
     */
    List<Incidencia> findByVehicleMatricule(String matricule);

    /**
     * Recupera les incidències creades per un usuari concret.
     *
     * @param creadoPor usuari creador (p. ex. "ADMIN" o nom d'usuari)
     * @return llista d'incidències creades per l'usuari
     */
    List<Incidencia> findByCreadoPor(String creadoPor);

    /**
     * Recupera les incidències assignades a un usuari concret.
     *
     * @param assignadaA usuari assignat
     * @return llista d'incidències assignades
     */
    List<Incidencia> findByAssignadaA(String assignadaA);

    /**
     * Recupera les incidències creades per un usuari i assignades a un altre
     * usuari concret.
     *
     * @param creadoPor usuari creador
     * @param assignadaA usuari assignat
     * @return llista d'incidències que compleixen ambdós criteris
     */
    List<Incidencia> findByCreadoPorAndAssignadaA(String creadoPor, String assignadaA);

    /**
     * Recupera les incidències d'un vehicle filtrant per estat.
     *
     * @param matricule matrícula del vehicle
     * @param estat estat de la incidència
     * @return llista d'incidències del vehicle amb l'estat indicat
     */
    List<Incidencia> findByVehicleMatriculeAndEstat(String matricule, EstatIncidencia estat);
}
