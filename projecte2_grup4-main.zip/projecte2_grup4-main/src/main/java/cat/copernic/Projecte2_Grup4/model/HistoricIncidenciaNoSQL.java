package cat.copernic.Projecte2_Grup4.model;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import cat.copernic.Projecte2_Grup4.model.enums.AccioIncidenciaNoSQL;

@Document(collection = "historic_incidencies")
/**
 * Document NoSQL que registra l'històric de canvis d'una incidència.
 *
 * <p>
 * La col·lecció {@code historic_incidencies} s'utilitza per emmagatzemar un
 * registre d'auditoria dels canvis relacionats amb una incidència (persistida a
 * SQL), incloent-hi:</p>
 * <ul>
 * <li>L'acció efectuada ({@link AccioIncidenciaNoSQL}).</li>
 * <li>Les dates rellevants del procés (inici, fi i moment del canvi).</li>
 * <li>Dades descriptives (matrícula, títol, descripció, comentari).</li>
 * <li>Cost associat, si n'hi ha.</li>
 * <li>L'usuari responsable del canvi.</li>
 * </ul>
 *
 * <p>
 * Per defecte, la data del canvi ({@code dataCanvi}) s'inicialitza amb l'hora
 * actual.</p>
 */
public class HistoricIncidenciaNoSQL {

    @Id
    private String id;

    /**
     * Identificador de la incidència (SQL) de la qual enregistrem el canvi.
     */
    private String idIncidencia;

    private AccioIncidenciaNoSQL accio;
    private LocalDateTime dataCanvi;
    private LocalDateTime dataInici;
    private LocalDateTime dataFi;
    private String matricula;
    private String titol;
    private String descripcio;
    private BigDecimal cost;
    private String userResponsable;
    private String comentari;

    // ============================ CONSTRUCTORS ===============================
    /**
     * Constructor per defecte.
     *
     * <p>
     * Inicialitza {@code dataCanvi} amb el moment actual.</p>
     */
    public HistoricIncidenciaNoSQL() {
        this.dataCanvi = LocalDateTime.now();
    }

    /**
     * Constructor mínim per registrar un canvi bàsic d'una incidència.
     *
     * @param idIncidencia identificador de la incidència (SQL)
     * @param accio acció registrada a l'històric
     * @param userResponsable usuari que ha realitzat el canvi
     * @param comentari comentari associat al canvi (opcional)
     */
    public HistoricIncidenciaNoSQL(String idIncidencia, AccioIncidenciaNoSQL accio,
            String userResponsable, String comentari) {
        this.idIncidencia = idIncidencia;
        this.accio = accio;
        this.userResponsable = userResponsable;
        this.comentari = comentari;
        this.dataCanvi = LocalDateTime.now();
    }

    /**
     * Constructor complet per registrar un canvi amb informació detallada.
     *
     * @param idIncidencia identificador de la incidència (SQL)
     * @param accio acció registrada a l'històric
     * @param dataInici data d'inici (si aplica)
     * @param dataFi data de fi (si aplica)
     * @param matricula matrícula del vehicle associat
     * @param titol títol de la incidència
     * @param descripcio descripció de la incidència
     * @param cost cost associat (si aplica)
     * @param userResponsable usuari que ha realitzat el canvi
     * @param comentari comentari associat al canvi (opcional)
     */
    public HistoricIncidenciaNoSQL(String idIncidencia, AccioIncidenciaNoSQL accio,
            LocalDateTime dataInici, LocalDateTime dataFi,
            String matricula, String titol, String descripcio, BigDecimal cost,
            String userResponsable, String comentari) {
        this.idIncidencia = idIncidencia;
        this.accio = accio;
        this.dataInici = dataInici;
        this.dataFi = dataFi;
        this.matricula = matricula;
        this.titol = titol;
        this.descripcio = descripcio;
        this.cost = cost;
        this.userResponsable = userResponsable;
        this.comentari = comentari;
        this.dataCanvi = LocalDateTime.now();
    }

    // ============================ GETTERS & SETTERS ===============================
    /**
     * Retorna l'identificador del document.
     *
     * @return id del document
     */
    public String getId() {
        return id;
    }

    /**
     * Assigna l'identificador del document.
     *
     * @param id id del document
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Retorna l'identificador de la incidència (SQL) associada al registre.
     *
     * @return id de la incidència
     */
    public String getIdIncidencia() {
        return idIncidencia;
    }

    /**
     * Assigna l'identificador de la incidència (SQL) associada al registre.
     *
     * @param idIncidencia id de la incidència
     */
    public void setIdIncidencia(String idIncidencia) {
        this.idIncidencia = idIncidencia;
    }

    /**
     * Retorna l'acció registrada a l'històric.
     *
     * @return acció registrada
     */
    public AccioIncidenciaNoSQL getAccio() {
        return accio;
    }

    /**
     * Assigna l'acció registrada a l'històric.
     *
     * @param accio acció registrada
     */
    public void setAccio(AccioIncidenciaNoSQL accio) {
        this.accio = accio;
    }

    /**
     * Retorna la data i hora en què s'ha registrat el canvi.
     *
     * @return data del canvi
     */
    public LocalDateTime getDataCanvi() {
        return dataCanvi;
    }

    /**
     * Assigna la data i hora en què s'ha registrat el canvi.
     *
     * @param dataCanvi nova data del canvi
     */
    public void setDataCanvi(LocalDateTime dataCanvi) {
        this.dataCanvi = dataCanvi;
    }

    /**
     * Retorna la data d'inici associada al registre (si aplica).
     *
     * @return data d'inici
     */
    public LocalDateTime getDataInici() {
        return dataInici;
    }

    /**
     * Assigna la data d'inici associada al registre (si aplica).
     *
     * @param dataInici nova data d'inici
     */
    public void setDataInici(LocalDateTime dataInici) {
        this.dataInici = dataInici;
    }

    /**
     * Retorna la data de fi associada al registre (si aplica).
     *
     * @return data de fi
     */
    public LocalDateTime getDataFi() {
        return dataFi;
    }

    /**
     * Assigna la data de fi associada al registre (si aplica).
     *
     * @param dataFi nova data de fi
     */
    public void setDataFi(LocalDateTime dataFi) {
        this.dataFi = dataFi;
    }

    /**
     * Retorna la matrícula del vehicle associat a la incidència.
     *
     * @return matrícula del vehicle
     */
    public String getMatricula() {
        return matricula;
    }

    /**
     * Assigna la matrícula del vehicle associat a la incidència.
     *
     * @param matricula matrícula del vehicle
     */
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    /**
     * Retorna el títol de la incidència.
     *
     * @return títol de la incidència
     */
    public String getTitol() {
        return titol;
    }

    /**
     * Assigna el títol de la incidència.
     *
     * @param titol títol de la incidència
     */
    public void setTitol(String titol) {
        this.titol = titol;
    }

    /**
     * Retorna la descripció de la incidència.
     *
     * @return descripció
     */
    public String getDescripcio() {
        return descripcio;
    }

    /**
     * Assigna la descripció de la incidència.
     *
     * @param descripcio descripció
     */
    public void setDescripcio(String descripcio) {
        this.descripcio = descripcio;
    }

    /**
     * Retorna el cost associat a la incidència (si n'hi ha).
     *
     * @return cost de la incidència
     */
    public BigDecimal getCost() {
        return cost;
    }

    /**
     * Assigna el cost associat a la incidència.
     *
     * @param cost cost de la incidència
     */
    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    /**
     * Retorna l'usuari responsable del canvi.
     *
     * @return usuari responsable
     */
    public String getUserResponsable() {
        return userResponsable;
    }

    /**
     * Assigna l'usuari responsable del canvi.
     *
     * @param userResponsable usuari responsable
     */
    public void setUserResponsable(String userResponsable) {
        this.userResponsable = userResponsable;
    }

    /**
     * Retorna el comentari associat al canvi.
     *
     * @return comentari
     */
    public String getComentari() {
        return comentari;
    }

    /**
     * Assigna el comentari associat al canvi.
     *
     * @param comentari comentari
     */
    public void setComentari(String comentari) {
        this.comentari = comentari;
    }
}
