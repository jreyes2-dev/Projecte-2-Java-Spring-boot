package cat.copernic.Projecte2_Grup4.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "foto_lliurament")
/**
 * Entitat JPA que representa una fotografia presa durant el lliurament d'un
 * vehicle.
 *
 * <p>
 * Les fotografies queden associades a una {@link Reserva} i s'emmagatzemen en
 * format binari (LONGBLOB). També es guarda el {@code contentType} per poder
 * servir correctament el fitxer i la data de creació com a traçabilitat.</p>
 */
public class FotoLliurament {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "reserva_id")
    private Reserva reserva;

    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "contingut", columnDefinition = "LONGBLOB", nullable = false)
    private byte[] contingut;

    @Column(name = "content_type", length = 100)
    private String contentType;

    @Column(name = "data_creacio", nullable = false)
    private LocalDateTime dataCreacio = LocalDateTime.now();

    /**
     * Constructor per defecte.
     */
    public FotoLliurament() {
    }

    /**
     * Retorna l'identificador de la fotografia.
     *
     * @return id de la foto
     */
    public Long getId() {
        return id;
    }

    /**
     * Retorna la reserva a la qual pertany aquesta fotografia.
     *
     * @return reserva associada
     */
    public Reserva getReserva() {
        return reserva;
    }

    /**
     * Assigna la reserva a la qual pertany aquesta fotografia.
     *
     * @param reserva reserva associada
     */
    public void setReserva(Reserva reserva) {
        this.reserva = reserva;
    }

    /**
     * Retorna el contingut binari de la fotografia.
     *
     * @return contingut de la foto
     */
    public byte[] getContingut() {
        return contingut;
    }

    /**
     * Assigna el contingut binari de la fotografia.
     *
     * @param contingut contingut de la foto
     */
    public void setContingut(byte[] contingut) {
        this.contingut = contingut;
    }

    /**
     * Retorna el tipus de contingut (MIME) de la fotografia.
     *
     * @return content type de la foto
     */
    public String getContentType() {
        return contentType;
    }

    /**
     * Assigna el tipus de contingut (MIME) de la fotografia.
     *
     * @param contentType content type de la foto
     */
    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    /**
     * Retorna la data de creació del registre de fotografia.
     *
     * @return data de creació
     */
    public LocalDateTime getDataCreacio() {
        return dataCreacio;
    }

    /**
     * Assigna la data de creació del registre de fotografia.
     *
     * @param dataCreacio nova data de creació
     */
    public void setDataCreacio(LocalDateTime dataCreacio) {
        this.dataCreacio = dataCreacio;
    }
}
