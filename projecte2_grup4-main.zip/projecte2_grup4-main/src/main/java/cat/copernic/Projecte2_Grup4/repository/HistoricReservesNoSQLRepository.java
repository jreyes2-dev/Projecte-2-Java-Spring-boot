package cat.copernic.Projecte2_Grup4.repository;

import java.util.List;
import cat.copernic.Projecte2_Grup4.model.HistoricReservesNoSQL;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * Repositori MongoDB per gestionar documents {@link HistoricReservesNoSQL}.
 *
 * <p>
 * Permet recuperar l'històric de canvis d'una reserva per identificador, per
 * usuari responsable o per estat anterior/nou.</p>
 *
 * @author sopor
 */
@Repository
public interface HistoricReservesNoSQLRepository extends MongoRepository<HistoricReservesNoSQL, String> {

    // Buscar todos los historial por idReserva
    /**
     * Recupera tots els registres d'històric associats a una reserva.
     *
     * @param idReserva identificador de la reserva
     * @return llista de registres d'històric
     */
    List<HistoricReservesNoSQL> findByIdReserva(Integer idReserva);

    // Buscar por usuario responsable
    /**
     * Recupera els registres d'històric filtrant per l'usuari responsable.
     *
     * @param userResponsable usuari responsable
     * @return llista de registres d'històric
     */
    List<HistoricReservesNoSQL> findByUserResponsable(String userResponsable);

    // Buscar por estado anterior o nuevo
    /**
     * Recupera els registres d'històric filtrant per l'estat anterior.
     *
     * @param estatAnterior estat anterior
     * @return llista de registres d'històric
     */
    List<HistoricReservesNoSQL> findByEstatAnterior(HistoricReservesNoSQL.EstatReserva estatAnterior);

    /**
     * Recupera els registres d'històric filtrant pel nou estat.
     *
     * @param estatNou nou estat
     * @return llista de registres d'històric
     */
    List<HistoricReservesNoSQL> findByEstatNou(HistoricReservesNoSQL.EstatReserva estatNou);
}
