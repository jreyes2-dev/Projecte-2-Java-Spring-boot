package cat.copernic.Projecte2_Grup4.service;

import cat.copernic.Projecte2_Grup4.model.Agent;
import cat.copernic.Projecte2_Grup4.model.Localitzacio;
import cat.copernic.Projecte2_Grup4.model.Vehicle;
import cat.copernic.Projecte2_Grup4.repository.AgentRepository;
import cat.copernic.Projecte2_Grup4.repository.LocalitzacioRepository;
import cat.copernic.Projecte2_Grup4.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Servei de negoci per gestionar les {@link Localitzacio} del sistema.
 *
 * <p>
 * Proporciona operacions de consulta i persistència de localitzacions (p. ex.
 * per codi postal), així com funcionalitats d'assignació i desassignació
 * d'entitats relacionades:
 * <ul>
 * <li>Assignar un {@link Vehicle} a una localització.</li>
 * <li>Assignar o desassignar un {@link Agent} responsable d'una
 * localització.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Les consultes principals utilitzen mètodes del repositori que recuperen també
 * les relacions amb vehicles i agent per disposar de la informació completa en
 * una sola crida.</p>
 */
@Service
public class LocalitzacioService {

    /**
     * Repositori d'accés a dades de {@link Localitzacio}.
     */
    @Autowired
    private LocalitzacioRepository localitzacioRepository;

    /**
     * Repositori d'accés a dades de {@link Vehicle}.
     */
    @Autowired
    private VehicleRepository vehicleRepository;

    /**
     * Repositori d'accés a dades de {@link Agent}.
     */
    @Autowired
    private AgentRepository agentRepository;

    /**
     * Retorna totes les localitzacions, incloent els vehicles i l'agent
     * associats.
     *
     * @return llista de localitzacions amb relacions carregades
     */
    public List<Localitzacio> llistarTotesLocalitzacions() {
        return localitzacioRepository.findAllWithVehiclesAndAgent();
    }

    /**
     * Desa una localització al repositori.
     *
     * @param localitzacio localització a persistir
     */
    public void guardarLocalitzacio(Localitzacio localitzacio) {
        localitzacioRepository.save(localitzacio);
    }

    /**
     * Obté una localització pel seu codi postal, incloent vehicles i agent
     * associats.
     *
     * @param codiPostal codi postal identificador de la localització
     * @return localització trobada o {@code null} si no existeix
     */
    public Localitzacio obtenirLocalitzacioPerId(String codiPostal) {
        return localitzacioRepository.findByCodiPostalWithVehiclesAndAgent(codiPostal);
    }

    /**
     * Elimina una localització pel seu codi postal.
     *
     * @param codiPostal codi postal identificador de la localització
     */
    public void eliminarLocalitzacio(String codiPostal) {
        localitzacioRepository.deleteById(codiPostal);
    }

    // --- Assignacions ---
    /**
     * Assigna un vehicle a una localització.
     *
     * <p>
     * Primer valida l'existència de la localització i del vehicle. Si
     * existeixen, estableix la localització al vehicle i el desa.</p>
     *
     * @param codiPostal codi postal de la localització
     * @param matricule matrícula del vehicle
     * @return {@code true} si s'ha pogut assignar; {@code false} si no existeix
     * la localització o el vehicle
     */
    public boolean assignarVehicle(String codiPostal, String matricule) {
        Localitzacio loc = obtenirLocalitzacioPerId(codiPostal);
        if (loc == null) {
            return false;
        }

        Vehicle vehicle = vehicleRepository.findById(matricule).orElse(null);
        if (vehicle == null) {
            return false;
        }

        vehicle.setLocalitzacio(loc);
        vehicleRepository.save(vehicle);
        return true;
    }

    /**
     * Assigna un agent a una localització.
     *
     * <p>
     * Primer valida l'existència de la localització i de l'agent. Si
     * existeixen, associa l'agent a la localització i la desa.</p>
     *
     * @param codiPostal codi postal de la localització
     * @param dni DNI de l'agent
     * @return {@code true} si s'ha pogut assignar; {@code false} si no existeix
     * la localització o l'agent
     */
    public boolean assignarAgent(String codiPostal, String dni) {
        Localitzacio loc = obtenirLocalitzacioPerId(codiPostal);
        if (loc == null) {
            return false;
        }

        Agent agent = agentRepository.findById(dni).orElse(null);
        if (agent == null) {
            return false;
        }

        loc.setAgent(agent);
        localitzacioRepository.save(loc);
        return true;
    }

    /**
     * Desassigna l'agent d'una localització (estableix l'agent a {@code null}).
     *
     * @param codiPostal codi postal de la localització
     * @return {@code true} si la localització existeix i s'ha desassignat;
     * {@code false} si no existeix
     */
    public boolean desassignarAgent(String codiPostal) {
        Localitzacio loc = obtenirLocalitzacioPerId(codiPostal);
        if (loc == null) {
            return false;
        }

        loc.setAgent(null);
        localitzacioRepository.save(loc);
        return true;
    }

    /**
     * Obté una localització pel seu codi postal.
     *
     * <p>
     * Mètode delegat a {@link #obtenirLocalitzacioPerId(String)} per mantenir
     * compatibilitat amb possibles crides des d'altres capes.</p>
     *
     * @param codiPostal codi postal identificador de la localització
     * @return localització trobada o {@code null} si no existeix
     */
    public Localitzacio obtenirLocalitzacioPerCodiPostal(String codiPostal) {
        return obtenirLocalitzacioPerId(codiPostal);
    }

    /**
     * Cerca localitzacions mitjançant un text lliure.
     *
     * <p>
     * La implementació concreta depèn del repositori (p. ex. coincidències en
     * codi postal, ciutat, adreça o altres camps). Les relacions amb vehicles i
     * agent es retornen carregades.</p>
     *
     * @param q text de cerca
     * @return llista de localitzacions que compleixen el criteri
     */
    public List<Localitzacio> cercarLocalitzacions(String q) {
        return localitzacioRepository.searchWithVehiclesAndAgent(q);
    }

    /**
     * Retorna totes les localitzacions ordenades pel codi postal, pensat per a
     * l'ús en selectors o desplegables.
     *
     * @return llista ordenada de localitzacions
     */
    public List<Localitzacio> llistarLocalitzacionsPerSelector() {
        return localitzacioRepository.findAllOrderByCodiPostal();
    }

}
