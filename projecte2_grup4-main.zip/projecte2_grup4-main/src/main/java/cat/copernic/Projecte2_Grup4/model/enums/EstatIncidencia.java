package cat.copernic.Projecte2_Grup4.model.enums;

/**
 * Enumeració que representa l'estat d'una incidència.
 *
 * <p>
 * Permet identificar si una incidència està activa o inactiva.</p>
 */
public enum EstatIncidencia {
    Activa,
    Inactiva
}
