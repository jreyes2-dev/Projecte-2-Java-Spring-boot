package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.model.Client;
import cat.copernic.Projecte2_Grup4.model.User;
import cat.copernic.Projecte2_Grup4.model.enums.Estat;
import cat.copernic.Projecte2_Grup4.model.enums.Rol;
import cat.copernic.Projecte2_Grup4.repository.ClientRepository;
import cat.copernic.Projecte2_Grup4.repository.UserRepository;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Controlador MVC per a la gestió de clients (CRUD) des de la part web.
 *
 * <p>
 * <b>Seguretat per rols:</b>
 * <ul>
 * <li><b>AGENT</b> o <b>ADMIN</b>: poden llistar i filtrar clients.</li>
 * <li><b>ADMIN</b>: pot crear, editar, guardar i eliminar clients.</li>
 * </ul>
 *
 * <p>
 * Aquesta classe evidencia control d'accés a
 * nivell de controlador, reutilització de repositoris i una regla crítica: la
 * contrasenya no es desa mai en clar.</p>
 */
@Controller
@RequestMapping("/web/clients")
public class ClientController {

    /**
     * Repositori de clients (accés a dades).
     */
    @Autowired
    private ClientRepository clientRepository;

    /**
     * Repositori d'usuaris (per obtenir l'usuari autenticat a partir del
     * username).
     */
    @Autowired
    private UserRepository userRepository;

    /**
     * Encoder de contrasenyes per garantir que no es desen en text pla.
     */
    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * Retorna l'usuari actual autenticat o {@code null} si no hi ha sessió
     * vàlida.
     *
     * @return usuari autenticat o null
     */
    private User currentUserOrNull() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getName() == null) {
            return null;
        }
        return userRepository.findByNomUser(auth.getName()).orElse(null);
    }

    /**
     * Indica si un usuari té rol d'administrador.
     *
     * @param u usuari
     * @return {@code true} si és ADMIN
     */
    private boolean isAdmin(User u) {
        return u != null && u.getRol() == Rol.ADMIN;
    }

    /**
     * Indica si un usuari és agent o administrador.
     *
     * @param u usuari
     * @return {@code true} si és AGENT o ADMIN
     */
    private boolean isAgentOrAdmin(User u) {
        return u != null && (u.getRol() == Rol.AGENT || u.getRol() == Rol.ADMIN);
    }

    /**
     * Redirecció d'entrada cap al llistat de clients.
     *
     * @return redirecció a /llistar
     */
    @GetMapping({"", "/"})
    public String redirectToLlistar() {
        return "redirect:/web/clients/llistar";
    }

    @GetMapping("/llistar")
    public String llistarClients(
            Model model,
            @RequestParam(value = "email", required = false) String email,
            @RequestParam(value = "nacionalitat", required = false) String nacionalitat,
            @RequestParam(value = "cognom", required = false) String cognom,
            @RequestParam(value = "telefon", required = false) String telefon
    ) {
        User u = currentUserOrNull();
        if (!isAgentOrAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        List<Client> resultats;

        if (email != null && !email.trim().isEmpty()) {
            resultats = clientRepository.findByEmailIgnoreCase(email.trim())
                    .map(List::of)
                    .orElse(List.of());

            if (resultats.isEmpty()) {
                model.addAttribute("missatge", "No s'ha trobat cap client amb l'email indicat.");
                model.addAttribute("tipusMissatge", "danger");
            }
        } else {
            boolean hiHaFiltres = (nacionalitat != null && !nacionalitat.trim().isEmpty())
                    || (cognom != null && !cognom.trim().isEmpty())
                    || (telefon != null && !telefon.trim().isEmpty());

            if (hiHaFiltres) {
                resultats = clientRepository.filtrarClients(
                        nacionalitat != null ? nacionalitat.trim() : null,
                        cognom != null ? cognom.trim() : null,
                        telefon != null ? telefon.trim() : null
                );
            } else {
                resultats = clientRepository.findAll();
            }
        }

        model.addAttribute("email", email);
        model.addAttribute("nacionalitat", nacionalitat);
        model.addAttribute("cognom", cognom);
        model.addAttribute("telefon", telefon);

        model.addAttribute("llistaClients", resultats);
        return "client/llistar-client";
    }

    @GetMapping("/crear")
    public String crearClient(Model model) {
        User u = currentUserOrNull();
        if (!isAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        Client client = new Client();
        client.setEstat(Estat.ACEPTAT);
        client.setPuntsRecolectats(0);
        // Quan un ADMIN crea un client manualment, aquest registre ha de tenir rol CLIENT.
        // Si queda null, després el login i/o les vistes poden fallar.
        client.setRol(cat.copernic.Projecte2_Grup4.model.enums.Rol.CLIENT);

        model.addAttribute("client", client);
        model.addAttribute("estats", Estat.values());
        return "client/crear-client";
    }

    @PostMapping("/guardar")
    public String guardarClient(@ModelAttribute Client client,
            RedirectAttributes redirect) {
        User u = currentUserOrNull();
        if (!isAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        // --- Proteccions per evitar sobreescriure camps crítics amb NULL/BLANK ---
        // IMPORTANT: El formulari d'ADMIN (crear/editar) pot no enviar contrasenya
        // (o es deixa en blanc per no canviar-la). En eixe cas, hem de conservar
        // la contrasenya anterior (hash) i el nom d'usuari.
        Client existing = null;
        if (client.getDni() != null && clientRepository.existsById(client.getDni())) {
            existing = clientRepository.findById(client.getDni()).orElse(null);
        }

        // Si és un ALTA nova, exigim nom d'usuari i contrasenya.
        // (Si no, es crea a la BD amb nom_user/contrasenya NULL i després no podrà fer login.)
        if (existing == null) {
            if (client.getNomUser() == null || client.getNomUser().isBlank()) {
                redirect.addFlashAttribute("missatge", "Has d'indicar un nom d'usuari per al login");
                redirect.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/clients/crear";
            }
            if (client.getContrasenya() == null || client.getContrasenya().isBlank()) {
                redirect.addFlashAttribute("missatge", "Has d'indicar una contrasenya per al login");
                redirect.addFlashAttribute("tipusMissatge", "danger");
                return "redirect:/web/clients/crear";
            }
        }

        // Rol per defecte
        if (client.getRol() == null) {
            client.setRol(cat.copernic.Projecte2_Grup4.model.enums.Rol.CLIENT);
        }

        // Nom d'usuari: si ve buit en edició, mantenim el que ja hi havia
        if (existing != null && (client.getNomUser() == null || client.getNomUser().isBlank())) {
            client.setNomUser(existing.getNomUser());
        }

        // Contrasenya: si ve buida en edició, mantenim el hash anterior
        if (existing != null && (client.getContrasenya() == null || client.getContrasenya().isBlank())) {
            client.setContrasenya(existing.getContrasenya());
        }

        // RN52: el password mai s'ha de guardar en clar (si arriba en text)
        if (client.getContrasenya() != null && !client.getContrasenya().isBlank()
                && !client.getContrasenya().startsWith("$2")) {
            client.setContrasenya(passwordEncoder.encode(client.getContrasenya()));
        }

        clientRepository.save(client);

        redirect.addFlashAttribute("missatge", "Client guardat correctament");
        redirect.addFlashAttribute("tipusMissatge", "success");
        return "redirect:/web/clients/llistar";
    }

    @GetMapping("/editar/{dni}")
    public String editarClient(@PathVariable String dni,
            Model model,
            RedirectAttributes redirect) {
        User u = currentUserOrNull();
        if (!isAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        Client client = clientRepository.findById(dni).orElse(null);
        if (client == null) {
            redirect.addFlashAttribute("missatge", "Client no trobat");
            redirect.addFlashAttribute("tipusMissatge", "danger");
            return "redirect:/web/clients/llistar";
        }

        model.addAttribute("client", client);
        model.addAttribute("estats", Estat.values());
        return "client/crear-client";
    }

    @PostMapping("/eliminar/{dni}")
    public String eliminarClient(@PathVariable String dni,
            RedirectAttributes redirect) {
        User u = currentUserOrNull();
        if (!isAdmin(u)) {
            return "redirect:/web/access-denied";
        }

        if (clientRepository.existsById(dni)) {
            clientRepository.deleteById(dni);
            redirect.addFlashAttribute("missatge", "Client eliminat correctament");
            redirect.addFlashAttribute("tipusMissatge", "success");
        } else {
            redirect.addFlashAttribute("missatge", "Client no trobat");
            redirect.addFlashAttribute("tipusMissatge", "danger");
        }

        return "redirect:/web/clients/llistar";
    }
}
