package cat.copernic.Projecte2_Grup4.model;

import cat.copernic.Projecte2_Grup4.model.enums.Estat;
import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import java.time.LocalDate;

@Entity
@DiscriminatorValue("CLIENT")
/**
 * Entitat que representa un client del sistema.
 *
 * <p>
 * Un client és un tipus d'usuari ({@link User}) que incorpora informació
 * addicional relacionada amb el seu perfil dins de l'aplicació, com ara:</p>
 * <ul>
 * <li>Punts acumulats (per a fidelització o mètriques internes).</li>
 * <li>Estat del compte ({@link Estat}) per controlar l'acceptació o situació
 * administrativa.</li>
 * <li>Dades de contacte opcionals com el telèfon i la data de naixement.</li>
 * </ul>
 *
 * <p>
 * La classe utilitza herència amb discriminador JPA, per la qual cosa es
 * persisteix dins la jerarquia d'usuaris.</p>
 */
public class Client extends User {

    @Column(nullable = true)
    private Integer puntsRecolectats;

    @Column(nullable = false)
    private Estat estat;

    @Column(nullable = true)
    private String telefon;

    @Column(nullable = true)
    private LocalDate dataNaixement;

    /**
     * Constructor per defecte.
     */
    public Client() {
        // Constructor buit
    }

    /**
     * Constructor amb dades bàsiques d'usuari per a un client.
     *
     * @param dni DNI del client
     * @param nom nom
     * @param cognom1 primer cognom
     * @param cognom2 segon cognom
     * @param adreca adreça
     * @param nomUser nom d'usuari
     * @param email correu electrònic
     * @param contrasenya contrasenya
     * @param tipusLlicenciaConduir tipus de llicència de conduir
     * @param numeroTargetaCredit número de targeta de crèdit
     * @param dataCaducitatIdentificacio data de caducitat del document
     * d'identificació
     * @param dataCaducitatLlicencia data de caducitat de la llicència de
     * conduir
     */
    public Client(String dni, String nom, String cognom1, String cognom2, String adreca, String nomUser,
            String email, String contrasenya, String tipusLlicenciaConduir, String numeroTargetaCredit,
            LocalDate dataCaducitatIdentificacio, LocalDate dataCaducitatLlicencia) {
        super(dni, nom, cognom1, cognom2, adreca, nomUser, email, contrasenya, tipusLlicenciaConduir,
                numeroTargetaCredit, dataCaducitatIdentificacio, dataCaducitatLlicencia);
    }

    /**
     * Constructor complet que inclou atributs específics del client.
     *
     * @param puntsRecolectats punts acumulats del client
     * @param estat estat del compte del client
     * @param telefon telèfon (opcional)
     * @param dataNaixement data de naixement (opcional)
     * @param dni DNI del client
     * @param nom nom
     * @param cognom1 primer cognom
     * @param cognom2 segon cognom
     * @param adreca adreça
     * @param nomUser nom d'usuari
     * @param email correu electrònic
     * @param contrasenya contrasenya
     * @param tipusLlicenciaConduir tipus de llicència de conduir
     * @param numeroTargetaCredit número de targeta de crèdit
     * @param dataCaducitatIdentificacio data de caducitat del document
     * d'identificació
     * @param dataCaducitatLlicencia data de caducitat de la llicència de
     * conduir
     */
    public Client(Integer puntsRecolectats, Estat estat, String telefon, LocalDate dataNaixement,
            String dni, String nom, String cognom1, String cognom2, String adreca, String nomUser,
            String email, String contrasenya, String tipusLlicenciaConduir, String numeroTargetaCredit,
            LocalDate dataCaducitatIdentificacio, LocalDate dataCaducitatLlicencia) {
        super(dni, nom, cognom1, cognom2, adreca, nomUser, email, contrasenya, tipusLlicenciaConduir,
                numeroTargetaCredit, dataCaducitatIdentificacio, dataCaducitatLlicencia);
        this.puntsRecolectats = puntsRecolectats;
        this.estat = estat;
        this.telefon = telefon;
        this.dataNaixement = dataNaixement;
    }

    // GETTERS I SETTERS
    /**
     * Retorna els punts acumulats del client.
     *
     * @return punts acumulats (pot ser {@code null})
     */
    public Integer getPuntsRecolectats() {
        return puntsRecolectats;
    }

    /**
     * Assigna els punts acumulats del client.
     *
     * @param puntsRecolectats nous punts acumulats
     */
    public void setPuntsRecolectats(Integer puntsRecolectats) {
        this.puntsRecolectats = puntsRecolectats;
    }

    /**
     * Retorna l'estat del compte del client.
     *
     * @return estat del compte
     */
    public Estat getEstat() {
        return estat;
    }

    /**
     * Assigna l'estat del compte del client.
     *
     * @param estat nou estat del compte
     */
    public void setEstat(Estat estat) {
        this.estat = estat;
    }

    /**
     * Retorna el telèfon del client.
     *
     * @return telèfon (pot ser {@code null})
     */
    public String getTelefon() {
        return telefon;
    }

    /**
     * Assigna el telèfon del client.
     *
     * @param telefon nou telèfon
     */
    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    /**
     * Retorna la data de naixement del client.
     *
     * @return data de naixement (pot ser {@code null})
     */
    public LocalDate getDataNaixement() {
        return dataNaixement;
    }

    /**
     * Assigna la data de naixement del client.
     *
     * @param dataNaixement nova data de naixement
     */
    public void setDataNaixement(LocalDate dataNaixement) {
        this.dataNaixement = dataNaixement;
    }

    /**
     * Retorna els cognoms concatenats (primer cognom + segon cognom).
     *
     * @return cadena amb els cognoms separats per un espai
     */
    public String getCognoms() {
        return getCognom1() + " " + getCognom2();
    }

    /**
     * Assigna els cognoms a partir d'una cadena.
     *
     * <p>
     * Divideix el text en dues parts com a màxim: el primer token com a primer
     * cognom i la resta com a segon cognom. Si només s'informa una part, el
     * segon cognom queda buit.</p>
     *
     * @param cognoms cadena amb un o dos cognoms
     */
    public void setCognoms(String cognoms) {
        String[] parts = cognoms.split(" ", 2);
        setCognom1(parts[0]);
        if (parts.length > 1) {
            setCognom2(parts[1]);
        } else {
            setCognom2("");
        }
    }
}
