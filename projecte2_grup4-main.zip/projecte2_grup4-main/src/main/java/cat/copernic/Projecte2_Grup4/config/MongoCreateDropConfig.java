/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cat.copernic.Projecte2_Grup4.config;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;

/**
 * Configuració d'arrencada per a MongoDB que emula el comportament de
 * {@code spring.jpa.hibernate.ddl-auto=create-drop} però en entorns Mongo.
 *
 * <p>
 * <b>Funció principal:</b> esborrar (drop) la base de dades de MongoDB cada
 * vegada que s'inicia l'aplicació.</p>
 *
 * <p>
 * <b>Ús habitual:</b> entorns de desenvolupament i proves, on interessa
 * començar sempre d'un estat net per validar fluxos (p. ex. alta d'usuaris,
 * creació de vehicles, reserves, etc.).</p>
 *
 */
/**
 * Inicialitza dades en arrencar l'aplicació.
 */
@Configuration
public class MongoCreateDropConfig implements ApplicationRunner {

    /**
     * Plantilla de Mongo per executar operacions directes sobre la base de
     * dades.
     */
    private final MongoTemplate mongoTemplate;

    /**
     * Constructor amb injecció de {@link MongoTemplate}.
     *
     * @param mongoTemplate plantilla per interactuar amb MongoDB
     */
    public MongoCreateDropConfig(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    /**
     * Acció executada automàticament en acabar d'arrencar l'aplicació.
     *
     * <p>
     * Es fa un {@code drop()} de la base de dades activa. S'imprimeix un
     * missatge informatiu per deixar evidència durant l'execució</p>
     *
     * @param args arguments d'arrencada proporcionats per Spring Boot
     */
    /**
     * Executa l'operació.
     *
     * @param args paràmetre
     */
    @Override
    public void run(ApplicationArguments args) {
        System.out.println("🧨 MongoDB: esborrant base de dades (create-drop equivalent)");
        mongoTemplate.getDb().drop();
    }
}
