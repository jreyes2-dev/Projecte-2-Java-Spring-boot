package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.model.Agent;
import cat.copernic.Projecte2_Grup4.model.enums.EstatAgent;
import cat.copernic.Projecte2_Grup4.service.AgentService;
import cat.copernic.Projecte2_Grup4.service.IncidenciaService;
import cat.copernic.Projecte2_Grup4.service.LocalitzacioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class AgentControllerTest {

    private MockMvc mockMvc;

    @Mock
    private AgentService agentService;

    @Mock
    private LocalitzacioService localitzacioService;

    @Mock
    private IncidenciaService incidenciaService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        AgentController controller = new AgentController(agentService, localitzacioService, incidenciaService);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void llistarAgents_quanRolNoAdmin_retornaVistaLlista() throws Exception {
        // En standaloneSetup no s'executa Spring Security,
        // així que el controller renderitza la vista normal.
        when(agentService.llistarTotsAgents()).thenReturn(List.of());

        mockMvc.perform(get("/web/agents/llistar").param("rol", "AGENT"))
                .andExpect(status().isOk())
                .andExpect(view().name("agent/llistar-agents"))
                .andExpect(model().attributeExists("agents"))
                .andExpect(model().attributeExists("rolActual"))
                .andExpect(model().attributeExists("totalAgents"))
                .andExpect(model().attributeExists("agentsActius"))
                .andExpect(model().attributeExists("agentsInactius"));
    }

    @Test
    void llistarAgents_quanAdmin_senseCerca_retornaVistaLlista() throws Exception {
        Agent a1 = new Agent();
        a1.setEstatAgent(EstatAgent.ACTIU);
        Agent a2 = new Agent();
        a2.setEstatAgent(EstatAgent.INACTIU);

        when(agentService.llistarTotsAgents()).thenReturn(List.of(a1, a2));

        mockMvc.perform(get("/web/agents/llistar"))
                .andExpect(status().isOk())
                .andExpect(view().name("agent/llistar-agents"))
                .andExpect(model().attributeExists("agents"))
                .andExpect(model().attributeExists("rolActual"))
                .andExpect(model().attributeExists("totalAgents"))
                .andExpect(model().attributeExists("agentsActius"))
                .andExpect(model().attributeExists("agentsInactius"));
    }

    @Test
    void mostrarFormulariCreacio_quanAdmin_retornaVistaCrear() throws Exception {
        when(localitzacioService.llistarTotesLocalitzacions()).thenReturn(List.of());

        mockMvc.perform(get("/web/agents/crear"))
                .andExpect(status().isOk())
                .andExpect(view().name("agent/crear-agents"))
                .andExpect(model().attributeExists("agent"))
                .andExpect(model().attributeExists("rolActual"))
                .andExpect(model().attributeExists("localitzacions"))
                .andExpect(model().attributeExists("estatsAgent"));
    }

    @Test
    void verificarEmail_retornaRespostaAmbExisteTrue() throws Exception {
        when(agentService.existeixEmail("a@b.com", null)).thenReturn(true);

        mockMvc.perform(get("/web/agents/verificar-email").param("email", "a@b.com"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("true")));
    }

    @Test
    void verificarUsername_retornaRespostaAmbExisteFalse() throws Exception {
        when(agentService.existeixNomUser("pepito", null)).thenReturn(false);

        mockMvc.perform(get("/web/agents/verificar-username").param("username", "pepito"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("false")));
    }

    @Test
    void verificarDni_retornaRespostaAmbExisteTrue() throws Exception {
        when(agentService.existeixDni("12345678A")).thenReturn(true);

        mockMvc.perform(get("/web/agents/verificar-dni").param("dni", "12345678A"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("true")));
    }
}
