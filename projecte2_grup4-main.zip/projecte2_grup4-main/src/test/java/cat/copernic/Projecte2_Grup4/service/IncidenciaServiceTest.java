package cat.copernic.Projecte2_Grup4.service;

import cat.copernic.Projecte2_Grup4.model.Incidencia;
import cat.copernic.Projecte2_Grup4.model.Vehicle;
import cat.copernic.Projecte2_Grup4.model.enums.Antiguitat;
import cat.copernic.Projecte2_Grup4.model.enums.EstatIncidencia;
import cat.copernic.Projecte2_Grup4.repository.IncidenciaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IncidenciaServiceTest {

    @Mock
    private IncidenciaRepository incidenciaRepository;

    // ✅ NECESARIO: IncidenciaService usa historicService y si no lo mockeas queda null
    @Mock
    private HistoricIncidenciaNoSQLService historicService;

    @InjectMocks
    private IncidenciaService incidenciaService;

    @Captor
    private ArgumentCaptor<Incidencia> incidenciaCaptor;

    @Test
    void desactivarIncidencia_passaAInactivaIAntiga() {
        Incidencia i = new Incidencia();
        i.setIdIncidence(10);
        i.setEstat(EstatIncidencia.Activa);
        i.setAntiguitat(Antiguitat.Nova);

        i.setAssignadaA("agent1");
        when(incidenciaRepository.findById(10)).thenReturn(java.util.Optional.of(i));

        incidenciaService.desactivarIncidencia(10);

        verify(incidenciaRepository).save(incidenciaCaptor.capture());
        Incidencia guardada = incidenciaCaptor.getValue();

        assertEquals(EstatIncidencia.Inactiva, guardada.getEstat());
        assertEquals(Antiguitat.Antiga, guardada.getAntiguitat());
    }

    @Test
    void guardarIncidencia_siTeMesDe24Hores_passaAAntiga() {
        Incidencia i = new Incidencia();
        i.setIdIncidence(5);
        i.setEstat(EstatIncidencia.Activa);
        i.setAntiguitat(Antiguitat.Nova);
        i.setDataCreacio(LocalDateTime.now().minusHours(25));
        i.setTitle("Prova");
        i.setCreadoPor("agent1");
        i.setAssignadaA("agent1");

        when(incidenciaRepository.save(any(Incidencia.class))).thenAnswer(inv -> inv.getArgument(0));

        incidenciaService.guardarIncidencia(i);

        verify(incidenciaRepository).save(incidenciaCaptor.capture());
        assertEquals(Antiguitat.Antiga, incidenciaCaptor.getValue().getAntiguitat());
    }

    @Test
    void actualitzarAntiguitatDiaria_canviaLesNovesAntigues() {
        Incidencia i1 = new Incidencia();
        i1.setIdIncidence(1);
        i1.setTitle("I1");
        i1.setAntiguitat(Antiguitat.Nova);
        i1.setDataCreacio(LocalDateTime.now().minusHours(30));

        Incidencia i2 = new Incidencia();
        i2.setIdIncidence(2);
        i2.setTitle("I2");
        i2.setAntiguitat(Antiguitat.Nova);
        i2.setDataCreacio(LocalDateTime.now().minusHours(10));

        when(incidenciaRepository.findByAntiguitat(Antiguitat.Nova)).thenReturn(List.of(i1, i2));

        incidenciaService.actualitzarAntiguitatDiaria();

        verify(incidenciaRepository, times(1)).save(incidenciaCaptor.capture());
        assertEquals(1, incidenciaCaptor.getValue().getIdIncidence());
        assertEquals(Antiguitat.Antiga, incidenciaCaptor.getValue().getAntiguitat());
    }

    @Test
    void reassignarIncidenciesAssignadesDeAgentAAdmin_canviaAssignacio() {
        Incidencia i1 = new Incidencia();
        i1.setIdIncidence(1);
        i1.setTitle("I1");
        i1.setCreadoPor("agent1");
        i1.setAssignadaA("agent1");

        Incidencia i2 = new Incidencia();
        i2.setIdIncidence(2);
        i2.setTitle("I2");
        i2.setCreadoPor("agent1");
        i2.setAssignadaA("agent1");

        when(incidenciaRepository.findByAssignadaA("agent1")).thenReturn(List.of(i1, i2));
        when(incidenciaRepository.save(any(Incidencia.class))).thenAnswer(inv -> inv.getArgument(0));

        int count = incidenciaService.reassignarIncidenciesAssignadesDeAgentAAdmin("agent1");

        assertEquals(2, count);
        assertEquals("agent1", i1.getCreadoPor());
        assertEquals("agent1", i2.getCreadoPor());
        assertEquals("ADMIN", i1.getAssignadaA());
        assertEquals("ADMIN", i2.getAssignadaA());
        verify(incidenciaRepository, times(2)).save(any(Incidencia.class));
    }

    @Test
    void restaurarIncidenciesDeAgentQuanReactivat_retornaAssignacio() {
        Incidencia i1 = new Incidencia();
        i1.setIdIncidence(1);
        i1.setTitle("I1");
        i1.setCreadoPor("agent1");
        i1.setAssignadaA("ADMIN");

        when(incidenciaRepository.findByCreadoPorAndAssignadaA("agent1", "ADMIN")).thenReturn(List.of(i1));
        when(incidenciaRepository.save(any(Incidencia.class))).thenAnswer(inv -> inv.getArgument(0));

        int count = incidenciaService.restaurarIncidenciesDeAgentQuanReactivat("agent1");

        assertEquals(1, count);
        assertEquals("agent1", i1.getAssignadaA());
        verify(incidenciaRepository, times(1)).save(any(Incidencia.class));
    }

    @Test
    void guardarIncidencia_noPermetNovaSiVehicleJaTeIncidenciaActiva() {
        Vehicle v = new Vehicle();
        v.setMatricule("ABC123");

        Incidencia existent = new Incidencia();
        existent.setIdIncidence(99);
        existent.setTitle("Ja oberta");
        existent.setEstat(EstatIncidencia.Activa);

        Incidencia nova = new Incidencia();
        nova.setTitle("Nova");
        nova.setVehicle(v);
        nova.setCreadoPor("agent1");
        nova.setAssignadaA("agent1");

        when(incidenciaRepository.findByVehicleMatriculeAndEstat("ABC123", EstatIncidencia.Activa))
                .thenReturn(List.of(existent));

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> incidenciaService.guardarIncidencia(nova));

        assertTrue(ex.getMessage().toLowerCase().contains("ja té una incidència activa"));
        verify(incidenciaRepository, never()).save(any(Incidencia.class));
    }
}
