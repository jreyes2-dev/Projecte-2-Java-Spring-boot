package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.repository.ClientRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class ClientControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ClientRepository clientRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        ClientController controller = new ClientController();
        ReflectionTestUtils.setField(controller, "clientRepository", clientRepository);

        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void arrelClients_redirigeixALlistar() throws Exception {
        mockMvc.perform(get("/web/clients/"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/web/clients/llistar"));
    }

    @Test
    void llistarClients_senseFiltres_redirigeixPerSeguretat() throws Exception {
        when(clientRepository.findAll()).thenReturn(List.of());

        mockMvc.perform(get("/web/clients/llistar"))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    void llistarClients_ambEmail_quanNoExisteix_redirigeixPerSeguretat() throws Exception {
        when(clientRepository.findByEmailIgnoreCase("no@existeix.com")).thenReturn(Optional.empty());

        mockMvc.perform(get("/web/clients/llistar").param("email", "no@existeix.com"))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    void crearClient_redirigeixPerSeguretat() throws Exception {
        mockMvc.perform(get("/web/clients/crear"))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    void editarClient_quanNoExisteix_redirigeixAccessDenied() throws Exception {
        when(clientRepository.findById("12345678A")).thenReturn(Optional.empty());

        mockMvc.perform(get("/web/clients/editar/12345678A"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/web/access-denied"));
    }

    @Test
    void eliminarClient_quanNoExisteix_redirigeixAccessDenied() throws Exception {
        when(clientRepository.existsById("12345678A")).thenReturn(false);

        mockMvc.perform(post("/web/clients/eliminar/12345678A"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/web/access-denied"));
    }
}
