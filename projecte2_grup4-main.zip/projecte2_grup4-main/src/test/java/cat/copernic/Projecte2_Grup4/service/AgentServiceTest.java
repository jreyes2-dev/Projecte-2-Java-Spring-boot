package cat.copernic.Projecte2_Grup4.service;

import cat.copernic.Projecte2_Grup4.model.Agent;
import cat.copernic.Projecte2_Grup4.repository.AgentRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AgentServiceTest {

    @Mock
    private AgentRepository agentRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private AgentService agentService;

    @Test
    void llistarTotsAgents_retornaElFindAllDelRepositori() {
        when(agentRepository.findAll()).thenReturn(List.of(new Agent(), new Agent()));

        List<Agent> result = agentService.llistarTotsAgents();

        assertNotNull(result);
        assertEquals(2, result.size());
        verify(agentRepository).findAll();
    }

    @Test
    void obtenirAgentPerDni_quanExisteix_retornaAgent() {
        when(agentRepository.findById("12345678A")).thenReturn(Optional.of(new Agent()));

        Agent result = agentService.obtenirAgentPerDni("12345678A");

        assertNotNull(result);
        verify(agentRepository).findById("12345678A");
    }

    @Test
    void obtenirAgentPerDni_quanNoExisteix_retornaNull() {
        when(agentRepository.findById("00000000Z")).thenReturn(Optional.empty());

        Agent result = agentService.obtenirAgentPerDni("00000000Z");

        assertNull(result);
        verify(agentRepository).findById("00000000Z");
    }

    @Test
    void obtenirAgentPerEmail_quanNoExisteixEmail_retornaNull_iNoCridaFindAll() {
        when(agentRepository.existsByEmail("x@y.com")).thenReturn(false);

        Agent result = agentService.obtenirAgentPerEmail("x@y.com");

        assertNull(result);
        verify(agentRepository).existsByEmail("x@y.com");
        verify(agentRepository, never()).findAll();
    }

    @Test
    void obtenirAgentPerEmail_quanExisteixEmail_buscaEnFindAll_ignorantMajuscules() {
        Agent a = new Agent();
        a.setEmail("TEST@MAIL.COM");

        when(agentRepository.existsByEmail("test@mail.com")).thenReturn(true);
        when(agentRepository.findAll()).thenReturn(List.of(a));

        Agent result = agentService.obtenirAgentPerEmail("test@mail.com");

        assertNotNull(result);
        assertEquals("TEST@MAIL.COM", result.getEmail());
        verify(agentRepository).existsByEmail("test@mail.com");
        verify(agentRepository).findAll();
    }

    @Test
    void obtenirAgentPerNomUser_retornaElDelRepositori() {
        when(agentRepository.findByNomUser("pepito")).thenReturn(Optional.of(new Agent()));

        Agent result = agentService.obtenirAgentPerNomUser("pepito");

        assertNotNull(result);
        verify(agentRepository).findByNomUser("pepito");
    }

    @Test
    void guardarAgent_cridaSave() {
        Agent a = new Agent();

        agentService.guardarAgent(a);

        verify(agentRepository).save(a);
    }

    @Test
    void existeixDni_retornaExistsById() {
        when(agentRepository.existsById("12345678A")).thenReturn(true);

        assertTrue(agentService.existeixDni("12345678A"));
        verify(agentRepository).existsById("12345678A");
    }

    @Test
    void existeixEmail_quanHiHaDniActual_usaExistsByEmailAndDniNot() {
        when(agentRepository.existsByEmailAndDniNot("a@b.com", "12345678A")).thenReturn(true);

        boolean result = agentService.existeixEmail("a@b.com", "12345678A");

        assertTrue(result);
        verify(agentRepository).existsByEmailAndDniNot("a@b.com", "12345678A");
        verify(agentRepository, never()).existsByEmail(anyString());
    }

    @Test
    void existeixEmail_quanNoHiHaDniActual_usaExistsByEmail() {
        when(agentRepository.existsByEmail("a@b.com")).thenReturn(true);

        boolean result = agentService.existeixEmail("a@b.com", null);

        assertTrue(result);
        verify(agentRepository).existsByEmail("a@b.com");
        verify(agentRepository, never()).existsByEmailAndDniNot(anyString(), anyString());
    }

    @Test
    void existeixNomUser_quanNoExisteix_retornaFalse() {
        when(agentRepository.findByNomUser("nou")).thenReturn(Optional.empty());

        assertFalse(agentService.existeixNomUser("nou", null));
    }

    @Test
    void existeixNomUser_quanExisteix_iDniActualEsElMateix_retornaFalse() {
        Agent a = new Agent();
        a.setDni("12345678A");
        when(agentRepository.findByNomUser("pepito")).thenReturn(Optional.of(a));

        assertFalse(agentService.existeixNomUser("pepito", "12345678A"));
    }

    @Test
    void existeixNomUser_quanExisteix_iDniActualEsDiferent_retornaTrue() {
        Agent a = new Agent();
        a.setDni("99999999Z");
        when(agentRepository.findByNomUser("pepito")).thenReturn(Optional.of(a));

        assertTrue(agentService.existeixNomUser("pepito", "12345678A"));
    }

    @Test
    void validarAgentCreacio_quanTotCorrecte_noHiHaErrors() {
        Agent a = new Agent();
        a.setDni("12345678A");
        a.setEmail("test@mail.com");
        a.setNomUser("user_ok");
        a.setNom("Nom");
        a.setCognom1("Cognom");
        a.setContrasenya("1234");

        when(agentRepository.existsById("12345678A")).thenReturn(false);
        when(agentRepository.existsByEmail("test@mail.com")).thenReturn(false);
        when(agentRepository.findByNomUser("user_ok")).thenReturn(Optional.empty());

        Map<String, String> errors = agentService.validarAgentCreacio(a);

        assertTrue(errors.isEmpty(), "No hauria d'haver errors: " + errors);
    }

    @Test
    void validarAgentCreacio_quanDniBuit_donaErrorDni() {
        Agent a = new Agent();
        a.setDni(" ");
        a.setEmail("test@mail.com");
        a.setNomUser("user_ok");
        a.setNom("Nom");
        a.setCognom1("Cognom");
        a.setContrasenya("1234");

        Map<String, String> errors = agentService.validarAgentCreacio(a);

        assertTrue(errors.containsKey("dni"));
    }

    @Test
    void validarAgentCreacio_quanEmailInvalid_donaErrorEmail() {
        Agent a = new Agent();
        a.setDni("12345678A");
        a.setEmail("no-es-email");
        a.setNomUser("user_ok");
        a.setNom("Nom");
        a.setCognom1("Cognom");
        a.setContrasenya("1234");

        when(agentRepository.existsById("12345678A")).thenReturn(false);
        when(agentRepository.findByNomUser("user_ok")).thenReturn(Optional.empty());

        Map<String, String> errors = agentService.validarAgentCreacio(a);

        assertTrue(errors.containsKey("email"));
    }

    @Test
    void validarAgentEdicio_quanAgentActualNoExisteix_retornaErrorGeneral() {
        when(agentRepository.findById("12345678A")).thenReturn(Optional.empty());

        Agent nou = new Agent();
        nou.setDni("12345678A");

        Map<String, String> errors = agentService.validarAgentEdicio(nou, "12345678A");

        assertTrue(errors.containsKey("general"));
    }

    @Test
    void validarAgentEdicio_quanCanviaEmail_iEmailJaExisteix_donaErrorEmail() {
        Agent actual = new Agent();
        actual.setDni("12345678A");
        actual.setEmail("antic@mail.com");
        actual.setNomUser("anticUser");

        when(agentRepository.findById("12345678A")).thenReturn(Optional.of(actual));
        when(agentRepository.existsByEmailAndDniNot("nou@mail.com", "12345678A")).thenReturn(true);

        Agent nou = new Agent();
        nou.setDni("12345678A");
        nou.setEmail("nou@mail.com");
        nou.setNomUser("anticUser");

        Map<String, String> errors = agentService.validarAgentEdicio(nou, "12345678A");

        assertTrue(errors.containsKey("email"));
    }

    @Test
    void validarAgentEdicio_quanCanviaNomUser_iNomUserJaExisteix_donaErrorNomUser() {
        Agent actual = new Agent();
        actual.setDni("12345678A");
        actual.setEmail("a@a.com");
        actual.setNomUser("anticUser");

        when(agentRepository.findById("12345678A")).thenReturn(Optional.of(actual));

        Agent altre = new Agent();
        altre.setDni("99999999Z");
        when(agentRepository.findByNomUser("nouUser")).thenReturn(Optional.of(altre));

        Agent nou = new Agent();
        nou.setDni("12345678A");
        nou.setEmail("a@a.com");
        nou.setNomUser("nouUser");

        Map<String, String> errors = agentService.validarAgentEdicio(nou, "12345678A");

        assertTrue(errors.containsKey("nomUser"));
    }
}
