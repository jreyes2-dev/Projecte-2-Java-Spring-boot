package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.model.Vehicle;
import cat.copernic.Projecte2_Grup4.repository.VehicleRepository;
import cat.copernic.Projecte2_Grup4.service.LocalitzacioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class VehicleControllerTest {

    private MockMvc mockMvc;

    @Mock
    private VehicleRepository vehicleRepository;

    @Mock
    private LocalitzacioService localitzacioService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        VehicleController controller = new VehicleController();

        ReflectionTestUtils.setField(controller, "vehicleRepository", vehicleRepository);
        ReflectionTestUtils.setField(controller, "localitzacioService", localitzacioService);

        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void llistarVehicles_retornaVistaLlistar() throws Exception {
        when(vehicleRepository.findAll()).thenReturn(List.of());

        mockMvc.perform(get("/web/vehicles/llistar"))
                .andExpect(status().isOk())
                .andExpect(view().name("vehicle/llistar-vehicles"))
                .andExpect(model().attributeExists("llistaVehicles"));
    }

    @Test
    void crearVehicle_redirigeixPerSeguretat() throws Exception {
        when(localitzacioService.llistarTotesLocalitzacions()).thenReturn(List.of());

        mockMvc.perform(get("/web/vehicles/crear"))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    void veureFoto_quanNoExisteix_retorna404() throws Exception {
        when(vehicleRepository.findById("NOEXISTE")).thenReturn(Optional.empty());

        mockMvc.perform(get("/web/vehicles/NOEXISTE/foto"))
                .andExpect(status().isNotFound());
    }

    @Test
    void editarVehicle_quanNoExisteix_redirigeixAccessDenied() throws Exception {
        when(vehicleRepository.findById("1234ABC")).thenReturn(Optional.empty());

        mockMvc.perform(get("/web/vehicles/editar/1234ABC"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/web/access-denied"));
    }

    @Test
    void eliminarVehicle_quanNoExisteix_redirigeixAccessDenied() throws Exception {
        when(vehicleRepository.existsById("NOEXISTE")).thenReturn(false);

        mockMvc.perform(post("/web/vehicles/eliminar/NOEXISTE"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/web/access-denied"));
    }

    @Test
    void guardarVehicle_quanEstatInvalid_retornaClientError() throws Exception {
        MockMultipartFile buit = new MockMultipartFile(
                "fotoFile", "foto.jpg", "image/jpeg", new byte[0]
        );

        mockMvc.perform(multipart("/web/vehicles/guardar")
                        .file(buit)
                        .param("estat", "NO_VALID")
                        .flashAttr("vehicle", new Vehicle()))
                .andExpect(status().is4xxClientError());
    }
}
