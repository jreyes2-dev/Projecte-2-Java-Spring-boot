package cat.copernic.Projecte2_Grup4.controller;

import cat.copernic.Projecte2_Grup4.model.Agent;
import cat.copernic.Projecte2_Grup4.model.Incidencia;
import cat.copernic.Projecte2_Grup4.model.enums.Rol;
import cat.copernic.Projecte2_Grup4.service.AgentService;
import cat.copernic.Projecte2_Grup4.service.DocumentacioIncidenciaNoSQLService;
import cat.copernic.Projecte2_Grup4.service.IncidenciaService;
import cat.copernic.Projecte2_Grup4.service.VehicleService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class IncidenciaControllerTest {

    private MockMvc mockMvc;

    @Mock
    private IncidenciaService incidenciaService;

    @Mock
    private AgentService agentService;

    @Mock
    private VehicleService vehicleService;

    @Mock
    private DocumentacioIncidenciaNoSQLService documentacioIncidenciaNoSQLService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        IncidenciaController controller = new IncidenciaController();

        ReflectionTestUtils.setField(controller, "incidenciaService", incidenciaService);
        ReflectionTestUtils.setField(controller, "agentService", agentService);
        ReflectionTestUtils.setField(controller, "vehicleService", vehicleService);
        ReflectionTestUtils.setField(controller, "documentacioIncidenciaNoSQLService", documentacioIncidenciaNoSQLService);

        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void llistarIncidencies_retornaVistaILlista() throws Exception {
        Agent a = new Agent();
        a.setRol(Rol.AGENT);
        a.setNomUser("agent1");

        when(agentService.llistarTotsAgents()).thenReturn(List.of(a));
        when(incidenciaService.llistarTotesIncidencies()).thenReturn(List.of());
        when(vehicleService.llistarTotsVehicles()).thenReturn(List.of());

        mockMvc.perform(get("/web/incidencies/llistar"))
                .andExpect(status().isOk())
                .andExpect(view().name("incidencies/llistar-incidencies"))
                .andExpect(model().attributeExists("llistaIncidencias"))
                .andExpect(model().attributeExists("rolActual"))
                // abans: .andExpect(model().attributeExists("nomsAgents"))
                .andExpect(model().attributeExists("proximold"))
                .andExpect(model().attributeExists("totalIncidencias"));
    }

    @Test
    void crearNovaIncidencia_retornaVistaCrear() throws Exception {
        when(agentService.llistarTotsAgents()).thenReturn(List.of());
        when(incidenciaService.llistarTotesIncidencies()).thenReturn(List.of());
        when(vehicleService.llistarTotsVehicles()).thenReturn(List.of());

        mockMvc.perform(get("/web/incidencies/crear-nova-incidencia"))
                .andExpect(status().isOk())
                .andExpect(view().name("incidencies/crear-incidencies"))
                .andExpect(model().attributeExists("incidencia"))
                .andExpect(model().attributeExists("vehicles"))
                .andExpect(model().attributeExists("rolActual"))
                .andExpect(model().attributeExists("proximold"));
                // abans: .andExpect(model().attributeExists("nomsAgents"));
    }

    @Test
    void editarIncidencia_quanNoExisteix_redirigeixALlistar() throws Exception {
        when(agentService.llistarTotsAgents()).thenReturn(List.of());
        when(incidenciaService.obtenirIncidenciaPerld(99)).thenReturn(null);

        mockMvc.perform(get("/web/incidencies/editar/99"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/web/incidencies/llistar*"));
    }

    @Test
    void guardarIncidencia_quanValidacioTornaErrors_redirigeixACrear() throws Exception {
        when(agentService.llistarTotsAgents()).thenReturn(List.of());
        when(incidenciaService.validarIncidencia(any())).thenReturn(Map.of("title", "El títol és obligatori"));

        mockMvc.perform(post("/web/incidencies/guardar").param("rol", "ADMIN"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/web/incidencies/crear-nova-incidencia*"));
    }

    @Test
    void desactivarIncidencia_quanExisteix_redirigeixALlistar() throws Exception {
        Incidencia i = new Incidencia();
        i.setCreadoPor("ADMIN");

        when(agentService.llistarTotsAgents()).thenReturn(List.of());
        when(incidenciaService.obtenirIncidenciaPerld(1)).thenReturn(i);

        mockMvc.perform(post("/web/incidencies/desactivar/1").param("rol", "ADMIN"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/web/incidencies/llistar*"));
    }

    @Test
    void activarIncidencia_quanExisteix_redirigeixALlistar() throws Exception {
        Incidencia i = new Incidencia();
        i.setCreadoPor("ADMIN");

        when(agentService.llistarTotsAgents()).thenReturn(List.of());
        when(incidenciaService.obtenirIncidenciaPerld(1)).thenReturn(i);

        mockMvc.perform(post("/web/incidencies/activar/1").param("rol", "ADMIN"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("/web/incidencies/llistar*"));
    }
}
