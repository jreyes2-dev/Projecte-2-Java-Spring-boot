package cat.copernic.Projecte2_Grup4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projecte2Grup4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
