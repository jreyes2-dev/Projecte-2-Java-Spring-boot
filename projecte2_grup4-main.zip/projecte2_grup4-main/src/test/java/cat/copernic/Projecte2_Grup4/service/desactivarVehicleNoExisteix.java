package cat.copernic.Projecte2_Grup4.service;

import cat.copernic.Projecte2_Grup4.repository.ReservaRepository;
import cat.copernic.Projecte2_Grup4.repository.VehicleRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VehicleServiceTest {

    @Mock
    VehicleRepository vehicleRepository;

    @Mock
    ReservaRepository reservaRepository;

    @InjectMocks
    VehicleService vehicleService;

    /**
     * Verifica que el mètode {@link VehicleService#desactivarVehicle(String, java.time.LocalDate)}
     * llança una excepció quan el vehicle no existeix al sistema.
     *
     * <p>
     * En aquest cas:
     * <ul>
     *   <li>No s'ha de consultar el repositori de reserves.</li>
     *   <li>No s'ha de persistir cap vehicle.</li>
     * </ul>
     * </p>
     */
    @Test
    void desactivarVehicle_noExisteix() {
        // Arrange
        String matricula = "NOEXISTE";
        when(vehicleRepository.findById(matricula)).thenReturn(Optional.empty());

        // Act + Assert
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> vehicleService.desactivarVehicle(matricula, LocalDate.now().plusDays(1)));

        assertEquals("Vehicle no trobat", ex.getMessage());

        verify(reservaRepository, never()).countReservesNoCanceladesEnCursOFutures(any(), any(), any());
        verify(vehicleRepository, never()).save(any());
    }
}
